/**
 * Database Configuration - Sequelize + MySQL2
 */

const { Sequelize } = require('sequelize');
const logger = require('../utils/logger');

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host:     process.env.DB_HOST    || 'localhost',
    port:     parseInt(process.env.DB_PORT) || 3306,
    dialect:  'mysql',
    logging:  (msg) => process.env.NODE_ENV === 'development' && logger.debug(msg),
    pool: {
      max:     parseInt(process.env.DB_POOL_MAX) || 10,
      min:     parseInt(process.env.DB_POOL_MIN) || 2,
      acquire: 30000,
      idle:    10000,
    },
    dialectOptions: {
      charset: 'utf8mb4',
      dateStrings: true,
      typeCast: true,
    },
    define: {
      charset: 'utf8mb4',
      collate: 'utf8mb4_unicode_ci',
      underscored: true,
      timestamps: true,
    },
    timezone: '+05:30', // IST
  }
);

module.exports = { sequelize };
