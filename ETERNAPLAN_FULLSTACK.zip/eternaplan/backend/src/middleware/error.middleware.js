// error.middleware.js
const logger = require('../utils/logger');

exports.errorHandler = (err, req, res, next) => {
  let { statusCode = 500, message, errors } = err;
  if (process.env.NODE_ENV === 'development') logger.error(err.stack);
  if (err.name === 'SequelizeValidationError')    { statusCode = 422; message = err.errors?.map(e=>e.message).join(', '); }
  if (err.name === 'SequelizeUniqueConstraintError') { statusCode = 409; message = 'Duplicate entry. Record already exists.'; }
  if (err.code === 'ER_DUP_ENTRY')               { statusCode = 409; message = 'Duplicate entry.'; }
  res.status(statusCode).json({ success: false, message, ...(errors && { errors }), ...(process.env.NODE_ENV === 'development' && { stack: err.stack }) });
};

exports.notFoundHandler = (req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.method} ${req.originalUrl} not found.` });
};
