/**
 * Auth Middleware
 */
const jwt = require('jsonwebtoken');
const { sequelize } = require('../config/database');
const AppError = require('../utils/AppError');

exports.authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) throw new AppError('Authentication required.', 401);
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const [user] = await sequelize.query(
      `SELECT u.id, u.company_id, u.first_name, u.last_name, u.email, u.status,
              r.name AS role, r.permissions
       FROM users u LEFT JOIN roles r ON u.role_id = r.id
       WHERE u.id = ? AND u.status = 'active' LIMIT 1`,
      { replacements: [decoded.id], type: sequelize.QueryTypes.SELECT }
    );
    if (!user) throw new AppError('User not found or inactive.', 401);

    req.user = { ...user, permissions: JSON.parse(user.permissions || '{}') };
    next();
  } catch (err) {
    if (err.name === 'JsonWebTokenError')  return next(new AppError('Invalid token.', 401));
    if (err.name === 'TokenExpiredError')  return next(new AppError('Token expired.', 401));
    next(err);
  }
};

exports.authorize = (...roles) => (req, res, next) => {
  if (!req.user) return next(new AppError('Authentication required.', 401));
  if (req.user.permissions?.all) return next(); // super admin bypass
  if (!roles.includes(req.user.role)) {
    return next(new AppError('Insufficient permissions.', 403));
  }
  next();
};
