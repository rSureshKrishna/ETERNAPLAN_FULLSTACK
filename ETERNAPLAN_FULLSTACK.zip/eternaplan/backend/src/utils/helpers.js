// utils/helpers.js
const QRCode = require('qrcode');

exports.generateQRCode = async (text) => {
  try { return await QRCode.toDataURL(text); }
  catch { return null; }
};

exports.paginate = (page, limit) => ({
  limit: Math.min(parseInt(limit) || 20, 100),
  offset: ((parseInt(page) || 1) - 1) * (Math.min(parseInt(limit) || 20, 100)),
});

exports.formatCurrency = (amount, currency = 'INR') =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency }).format(amount || 0);

exports.generateCode = (prefix, num, pad = 4) =>
  `${prefix}-${new Date().getFullYear()}-${String(num).padStart(pad, '0')}`;
