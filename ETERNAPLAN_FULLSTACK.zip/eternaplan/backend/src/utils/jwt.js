// utils/jwt.js
const jwt = require('jsonwebtoken');
exports.generateTokens = (user) => ({
  accessToken:  jwt.sign({ id: user.id, role: user.role_name || user.role, company_id: user.company_id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }),
  refreshToken: jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }),
});
exports.verifyRefreshToken = (token) => jwt.verify(token, process.env.JWT_REFRESH_SECRET);
