// utils/logger.js
const { createLogger, format, transports } = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');
const path = require('path');

const logDir = process.env.LOG_DIR || './logs';
const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.errors({ stack: true }),
    format.json()
  ),
  transports: [
    new transports.Console({
      format: format.combine(format.colorize(), format.simple()),
      silent: process.env.NODE_ENV === 'test',
    }),
    new DailyRotateFile({ filename: path.join(logDir, 'error-%DATE%.log'),   datePattern: 'YYYY-MM-DD', level: 'error', maxFiles: '30d' }),
    new DailyRotateFile({ filename: path.join(logDir, 'combined-%DATE%.log'), datePattern: 'YYYY-MM-DD', maxFiles: '14d' }),
  ],
});
module.exports = logger;
