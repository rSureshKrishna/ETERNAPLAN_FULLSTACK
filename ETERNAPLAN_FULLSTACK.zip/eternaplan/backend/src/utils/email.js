// utils/email.js
const nodemailer = require('nodemailer');
const logger = require('./logger');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

const templates = {
  otp: (ctx) => `
    <div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;background:#0a0e1a;color:#f8f5f0;padding:40px;border-radius:12px">
      <h1 style="color:#c9a96e;font-size:28px;margin-bottom:8px">EternaPlaan</h1>
      <p style="color:#9ca3af">Wedding & Event Management</p>
      <hr style="border-color:#1e2433;margin:24px 0">
      <h2 style="color:#f8f5f0">Hello ${ctx.name},</h2>
      <p>Your verification code is:</p>
      <div style="background:#1e2433;border:2px solid #c9a96e;border-radius:8px;padding:24px;text-align:center;margin:24px 0">
        <span style="font-size:42px;font-weight:bold;letter-spacing:12px;color:#c9a96e">${ctx.otp}</span>
      </div>
      <p style="color:#9ca3af;font-size:14px">This code expires in 10 minutes. Do not share with anyone.</p>
    </div>`,
  'reset-password': (ctx) => `
    <div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;background:#0a0e1a;color:#f8f5f0;padding:40px;border-radius:12px">
      <h1 style="color:#c9a96e">EternaPlaan</h1>
      <h2>Hello ${ctx.name},</h2>
      <p>Click the button below to reset your password. This link expires in 30 minutes.</p>
      <a href="${ctx.resetUrl}" style="display:inline-block;background:#c9a96e;color:#0a0e1a;padding:14px 32px;border-radius:6px;text-decoration:none;font-weight:bold;margin:20px 0">Reset Password</a>
      <p style="color:#9ca3af;font-size:13px">If you didn't request this, ignore this email.</p>
    </div>`,
};

exports.sendEmail = async ({ to, subject, template, context, html }) => {
  try {
    const emailHtml = html || (templates[template] ? templates[template](context) : context?.body || '');
    const info = await transporter.sendMail({
      from: `"${process.env.EMAIL_FROM_NAME}" <${process.env.EMAIL_FROM}>`,
      to, subject, html: emailHtml,
    });
    logger.info(`Email sent to ${to}: ${info.messageId}`);
    return info;
  } catch (err) {
    logger.error('Email send failed:', err.message);
    throw err;
  }
};
