// utils/sms.js
const logger = require('./logger');
let client;
try {
  if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
    client = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  }
} catch { logger.warn('Twilio not configured'); }

exports.sendSMS = async ({ to, message }) => {
  if (!client) { logger.info(`[SMS STUB] To: ${to} | Msg: ${message}`); return { stub: true }; }
  try {
    const result = await client.messages.create({ body: message, from: process.env.TWILIO_FROM_NUMBER, to });
    logger.info(`SMS sent to ${to}: ${result.sid}`);
    return result;
  } catch (err) { logger.error('SMS failed:', err.message); throw err; }
};
