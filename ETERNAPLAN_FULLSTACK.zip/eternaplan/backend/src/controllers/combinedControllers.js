/**
 * Combined Controllers: customers, vendors, bookings, guests, finance
 */
const { sequelize } = require('../config/database');
const AppError = require('../utils/AppError');
const { generateQRCode } = require('../utils/helpers');
const logger = require('../utils/logger');

const raw = (sql, opts) => sequelize.query(sql, { type: sequelize.QueryTypes.SELECT, ...opts });
const exec = (sql, reps, t) => sequelize.query(sql, { replacements: reps, type: sequelize.QueryTypes.INSERT, transaction: t });

// ═══════════════════════════════════════════════════════════
//  CUSTOMERS
// ═══════════════════════════════════════════════════════════
exports.customers = {
  list: async (req, res, next) => {
    try {
      const { page=1, limit=20, search, lead_status, priority, assigned_to, source } = req.query;
      const offset = (page-1)*limit;
      const cid = req.user.company_id;
      let where = 'c.company_id = ?'; const params = [cid];
      if (search)      { where += ' AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ? OR c.phone LIKE ?)'; params.push(...Array(4).fill(`%${search}%`)); }
      if (lead_status) { where += ' AND c.lead_status = ?'; params.push(lead_status); }
      if (priority)    { where += ' AND c.priority = ?';    params.push(priority); }
      if (assigned_to) { where += ' AND c.assigned_to = ?'; params.push(assigned_to); }
      if (source)      { where += ' AND c.source = ?';      params.push(source); }

      const [{ total }] = await raw(`SELECT COUNT(*) AS total FROM customers c WHERE ${where}`, { replacements: params });
      const customers = await raw(`
        SELECT c.id, c.first_name, c.last_name, c.email, c.phone, c.whatsapp,
          c.lead_status, c.priority, c.source, c.total_events,
          fn_get_customer_ltv(c.id) AS lifetime_value,
          CONCAT(u.first_name,' ',u.last_name) AS assigned_to_name,
          c.created_at, c.city, c.tags
        FROM customers c LEFT JOIN users u ON c.assigned_to=u.id
        WHERE ${where} ORDER BY c.priority DESC, c.created_at DESC LIMIT ? OFFSET ?
      `, { replacements: [...params, +limit, offset] });

      res.json({ success:true, data:{ customers, pagination:{ page:+page,limit:+limit,total:+total,pages:Math.ceil(total/limit) } } });
    } catch(err) { next(err); }
  },

  get: async (req, res, next) => {
    try {
      const [c] = await raw(
        `SELECT c.*, CONCAT(u.first_name,' ',u.last_name) AS assigned_manager,
          fn_get_customer_ltv(c.id) AS lifetime_value
         FROM customers c LEFT JOIN users u ON c.assigned_to=u.id
         WHERE c.id=? AND c.company_id=?`,
        { replacements: [req.params.id, req.user.company_id] }
      );
      if (!c) throw new AppError('Customer not found.', 404);
      const events = await raw(`SELECT id,event_code,event_name,event_date,status,budget_total FROM events WHERE customer_id=? ORDER BY event_date DESC`, { replacements:[c.id] });
      const notes  = await raw(`SELECT cn.*,CONCAT(u.first_name,' ',u.last_name) AS added_by FROM customer_notes cn JOIN users u ON cn.user_id=u.id WHERE cn.customer_id=? ORDER BY cn.created_at DESC`, { replacements:[c.id] });
      res.json({ success:true, data:{ customer:{ ...c, tags:tryParse(c.tags) }, events, notes } });
    } catch(err) { next(err); }
  },

  create: async (req, res, next) => {
    try {
      const { first_name,last_name,email,phone,whatsapp,source,lead_status,priority,assigned_to,notes,city,state,address,anniversary_date } = req.body;
      const [id] = await sequelize.query(
        `INSERT INTO customers (company_id,first_name,last_name,email,phone,whatsapp,source,lead_status,priority,assigned_to,notes,city,state,address,anniversary_date)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        { replacements:[req.user.company_id,first_name,last_name,email||null,phone,whatsapp||null,source||'walk_in',lead_status||'new',priority||'medium',assigned_to||req.user.id,notes||null,city||null,state||null,address||null,anniversary_date||null], type:sequelize.QueryTypes.INSERT }
      );
      res.status(201).json({ success:true, message:'Customer created.', data:{ id } });
    } catch(err) { next(err); }
  },

  update: async (req, res, next) => {
    try {
      const allowed = ['first_name','last_name','email','phone','whatsapp','lead_status','priority','source','assigned_to','notes','city','state','address','anniversary_date','tags'];
      const fields = Object.keys(req.body).filter(k=>allowed.includes(k));
      if (!fields.length) throw new AppError('No fields to update.',400);
      const sets = fields.map(f=>`${f}=?`).join(',');
      const vals = fields.map(f=>typeof req.body[f]==='object'?JSON.stringify(req.body[f]):req.body[f]);
      await sequelize.query(`UPDATE customers SET ${sets} WHERE id=? AND company_id=?`, { replacements:[...vals,req.params.id,req.user.company_id], type:sequelize.QueryTypes.UPDATE });
      res.json({ success:true, message:'Customer updated.' });
    } catch(err) { next(err); }
  },

  addNote: async (req, res, next) => {
    try {
      const { note, note_type, followup_at } = req.body;
      const [id] = await sequelize.query(
        'INSERT INTO customer_notes (customer_id,user_id,note,note_type,followup_at) VALUES (?,?,?,?,?)',
        { replacements:[req.params.id,req.user.id,note,note_type||'general',followup_at||null], type:sequelize.QueryTypes.INSERT }
      );
      res.status(201).json({ success:true, message:'Note added.', data:{ id } });
    } catch(err) { next(err); }
  },
};

// ═══════════════════════════════════════════════════════════
//  VENDORS
// ═══════════════════════════════════════════════════════════
exports.vendors = {
  list: async (req, res, next) => {
    try {
      const { page=1,limit=20,search,category_id,city,approval_status,rating_min } = req.query;
      const offset = (page-1)*limit;
      let where='1=1'; const params=[];
      if (req.user.company_id) { where+=' AND (v.company_id=? OR v.company_id IS NULL)'; params.push(req.user.company_id); }
      if (search)          { where+=' AND (v.business_name LIKE ? OR v.contact_name LIKE ?)'; params.push(`%${search}%`,`%${search}%`); }
      if (category_id)     { where+=' AND v.category_id=?';       params.push(category_id); }
      if (city)            { where+=' AND v.city LIKE ?';          params.push(`%${city}%`); }
      if (approval_status) { where+=' AND v.approval_status=?';    params.push(approval_status); }
      if (rating_min)      { where+=' AND v.rating>=?';            params.push(rating_min); }

      const [{ total }] = await raw(`SELECT COUNT(*) AS total FROM vendors v WHERE ${where}`, { replacements:params });
      const vendors = await raw(`
        SELECT v.id,v.business_name,v.contact_name,v.email,v.phone,v.city,
          v.min_price,v.max_price,v.rating,v.total_reviews,v.total_events,
          v.approval_status,v.is_featured,vc.name AS category,vc.icon,vc.id AS category_id,
          v.portfolio_images
        FROM vendors v JOIN vendor_categories vc ON v.category_id=vc.id
        WHERE ${where} ORDER BY v.is_featured DESC,v.rating DESC LIMIT ? OFFSET ?
      `, { replacements:[...params,+limit,offset] });

      res.json({ success:true, data:{ vendors, pagination:{ page:+page,limit:+limit,total:+total,pages:Math.ceil(total/limit) } } });
    } catch(err) { next(err); }
  },

  get: async (req, res, next) => {
    try {
      const [v] = await raw(
        `SELECT v.*,vc.name AS category,vc.icon FROM vendors v JOIN vendor_categories vc ON v.category_id=vc.id WHERE v.id=?`,
        { replacements:[req.params.id] }
      );
      if (!v) throw new AppError('Vendor not found.',404);
      const packages = await raw('SELECT * FROM vendor_packages WHERE vendor_id=? AND is_active=1 ORDER BY price', { replacements:[v.id] });
      const reviews  = await raw(`SELECT vr.*,CONCAT(c.first_name,' ',c.last_name) AS reviewer FROM vendor_reviews vr JOIN customers c ON vr.customer_id=c.id WHERE vr.vendor_id=? AND vr.is_approved=1 ORDER BY vr.created_at DESC LIMIT 20`, { replacements:[v.id] });
      res.json({ success:true, data:{ vendor:{ ...v, portfolio_images:tryParse(v.portfolio_images), social_media:tryParse(v.social_media), specializations:tryParse(v.specializations) }, packages, reviews } });
    } catch(err) { next(err); }
  },

  approve: async (req, res, next) => {
    try {
      const { approval_status, notes } = req.body;
      await sequelize.query(
        'UPDATE vendors SET approval_status=? WHERE id=?',
        { replacements:[approval_status,req.params.id], type:sequelize.QueryTypes.UPDATE }
      );
      res.json({ success:true, message:`Vendor ${approval_status}.` });
    } catch(err) { next(err); }
  },
};

// ═══════════════════════════════════════════════════════════
//  BOOKINGS
// ═══════════════════════════════════════════════════════════
exports.bookings = {
  list: async (req, res, next) => {
    try {
      const { page=1,limit=20,event_id,vendor_id,status,from_date,to_date } = req.query;
      const offset=(page-1)*limit; const cid=req.user.company_id;
      let where='b.company_id=?'; const params=[cid];
      if (event_id)  { where+=' AND b.event_id=?';       params.push(event_id); }
      if (vendor_id) { where+=' AND b.vendor_id=?';      params.push(vendor_id); }
      if (status)    { where+=' AND b.status=?';         params.push(status); }
      if (from_date) { where+=' AND b.booking_date>=?';  params.push(from_date); }
      if (to_date)   { where+=' AND b.booking_date<=?';  params.push(to_date); }

      const [{ total }] = await raw(`SELECT COUNT(*) AS total FROM bookings b WHERE ${where}`, { replacements:params });
      const bookings = await raw(`
        SELECT b.*,v.business_name AS vendor_name,vc.name AS vendor_category,
          ve.name AS venue_name,e.event_name,e.event_code,
          CONCAT(c.first_name,' ',c.last_name) AS customer_name
        FROM bookings b
        LEFT JOIN vendors v ON b.vendor_id=v.id
        LEFT JOIN vendor_categories vc ON v.category_id=vc.id
        LEFT JOIN venues ve ON b.venue_id=ve.id
        LEFT JOIN events e ON b.event_id=e.id
        LEFT JOIN customers c ON e.customer_id=c.id
        WHERE ${where} ORDER BY b.booking_date DESC LIMIT ? OFFSET ?
      `, { replacements:[...params,+limit,offset] });

      res.json({ success:true, data:{ bookings, pagination:{ page:+page,limit:+limit,total:+total,pages:Math.ceil(total/limit) } } });
    } catch(err) { next(err); }
  },

  create: async (req, res, next) => {
    const t = await sequelize.transaction();
    try {
      const { event_id,vendor_id,venue_id,package_id,booking_date,start_time,end_time,quoted_price,agreed_price,advance_amount,special_requirements,notes,booking_type } = req.body;

      // Conflict detection for venue bookings
      if (booking_type==='venue' && venue_id) {
        const [conflict] = await raw(
          `SELECT id FROM venue_bookings WHERE venue_id=? AND booked_date=? AND status IN('reserved','confirmed')
           AND ((start_time<?  AND end_time>?) OR (start_time>=? AND start_time<?))`,
          { replacements:[venue_id,booking_date,end_time,start_time,start_time,end_time] }
        );
        if (conflict) throw new AppError('Venue already booked for this time slot.',409);
      }

      const [cnt] = await raw('SELECT COUNT(*)+1 AS n FROM bookings WHERE company_id=?', { replacements:[req.user.company_id] });
      const booking_code = `BK-${new Date().getFullYear()}-${String(cnt.n).padStart(4,'0')}`;

      const [id] = await sequelize.query(
        `INSERT INTO bookings (company_id,event_id,vendor_id,venue_id,package_id,booking_code,booking_type,booking_date,start_time,end_time,quoted_price,agreed_price,advance_amount,balance_amount,special_requirements,notes,status,created_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?)`,
        { replacements:[req.user.company_id,event_id,vendor_id||null,venue_id||null,package_id||null,booking_code,booking_type||'vendor',booking_date,start_time||null,end_time||null,quoted_price||0,agreed_price||0,advance_amount||0,(agreed_price||0)-(advance_amount||0),special_requirements||null,notes||null,req.user.id], type:sequelize.QueryTypes.INSERT, transaction:t }
      );

      await t.commit();
      res.status(201).json({ success:true, message:'Booking created.', data:{ id, booking_code } });
    } catch(err) { await t.rollback(); next(err); }
  },

  updateStatus: async (req, res, next) => {
    try {
      const { status, cancellation_reason } = req.body;
      const cancelled_at = status==='cancelled' ? new Date() : null;
      await sequelize.query(
        'UPDATE bookings SET status=?,cancellation_reason=?,cancelled_at=? WHERE id=? AND company_id=?',
        { replacements:[status,cancellation_reason||null,cancelled_at,req.params.id,req.user.company_id], type:sequelize.QueryTypes.UPDATE }
      );
      res.json({ success:true, message:'Booking status updated.' });
    } catch(err) { next(err); }
  },
};

// ═══════════════════════════════════════════════════════════
//  GUESTS
// ═══════════════════════════════════════════════════════════
exports.guests = {
  list: async (req, res, next) => {
    try {
      const { event_id,rsvp_status,side,category,search,page=1,limit=50 } = req.query;
      const offset=(page-1)*limit;
      let where='g.event_id=?'; const params=[event_id];
      if (rsvp_status) { where+=' AND g.rsvp_status=?'; params.push(rsvp_status); }
      if (side)        { where+=' AND g.side=?';         params.push(side); }
      if (category)    { where+=' AND g.category=?';     params.push(category); }
      if (search)      { where+=` AND (g.first_name LIKE ? OR g.last_name LIKE ? OR g.email LIKE ? OR g.phone LIKE ?)`; params.push(...Array(4).fill(`%${search}%`)); }

      const [{ total }] = await raw(`SELECT COUNT(*) AS total FROM guests g WHERE ${where}`, { replacements:params });
      const guests = await raw(`SELECT g.*,gg.name AS group_name FROM guests g LEFT JOIN guest_groups gg ON g.group_id=gg.id WHERE ${where} ORDER BY g.table_number,g.first_name LIMIT ? OFFSET ?`, { replacements:[...params,+limit,offset] });

      const stats = await raw(`
        SELECT
          COUNT(*) AS total, SUM(rsvp_status='attending') AS attending,
          SUM(rsvp_status='not_attending') AS not_attending, SUM(rsvp_status='maybe') AS maybe,
          SUM(rsvp_status='pending') AS pending, SUM(checked_in=1) AS checked_in
        FROM guests WHERE event_id=?
      `, { replacements:[event_id] });

      res.json({ success:true, data:{ guests, stats:stats[0], pagination:{ page:+page,limit:+limit,total:+total,pages:Math.ceil(total/limit) } } });
    } catch(err) { next(err); }
  },

  create: async (req, res, next) => {
    try {
      const { event_id,first_name,last_name,email,phone,relation,side,category,meal_preference,table_number,seat_number,has_plus_one,plus_one_name,notes } = req.body;
      const invitation_code = `INV-${event_id}-${Math.random().toString(36).substring(2,8).toUpperCase()}`;
      const qr_url = await generateQRCode(`${process.env.APP_URL}/rsvp/${invitation_code}`);

      const [id] = await sequelize.query(
        `INSERT INTO guests (event_id,first_name,last_name,email,phone,relation,side,category,invitation_code,qr_code,meal_preference,table_number,seat_number,has_plus_one,plus_one_name,notes)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        { replacements:[event_id,first_name,last_name||null,email||null,phone||null,relation||null,side||'mutual',category||'friend',invitation_code,qr_url||null,meal_preference||'no_preference',table_number||null,seat_number||null,has_plus_one||0,plus_one_name||null,notes||null], type:sequelize.QueryTypes.INSERT }
      );
      res.status(201).json({ success:true, message:'Guest added.', data:{ id, invitation_code, qr_url } });
    } catch(err) { next(err); }
  },

  updateRSVP: async (req, res, next) => {
    try {
      const { rsvp_status, meal_preference } = req.body;
      await sequelize.query(
        'UPDATE guests SET rsvp_status=?,meal_preference=COALESCE(?,meal_preference),rsvp_date=NOW() WHERE invitation_code=?',
        { replacements:[rsvp_status,meal_preference||null,req.params.code], type:sequelize.QueryTypes.UPDATE }
      );
      res.json({ success:true, message:'RSVP updated. Thank you!' });
    } catch(err) { next(err); }
  },

  checkIn: async (req, res, next) => {
    try {
      const [guest] = await raw('SELECT id,first_name,last_name,checked_in FROM guests WHERE id=?', { replacements:[req.params.id] });
      if (!guest) throw new AppError('Guest not found.',404);
      if (guest.checked_in) return res.json({ success:true, message:`${guest.first_name} already checked in.`, data:guest });
      await sequelize.query('UPDATE guests SET checked_in=1,checked_in_at=NOW() WHERE id=?', { replacements:[guest.id], type:sequelize.QueryTypes.UPDATE });
      res.json({ success:true, message:`${guest.first_name} ${guest.last_name} checked in successfully.` });
    } catch(err) { next(err); }
  },

  bulkImport: async (req, res, next) => {
    const t = await sequelize.transaction();
    try {
      const { event_id, guests } = req.body;
      let created=0, skipped=0;
      for (const g of guests) {
        const code = `INV-${event_id}-${Math.random().toString(36).substring(2,8).toUpperCase()}`;
        await sequelize.query(
          `INSERT IGNORE INTO guests (event_id,first_name,last_name,email,phone,relation,side,category,invitation_code) VALUES (?,?,?,?,?,?,?,?,?)`,
          { replacements:[event_id,g.first_name,g.last_name||null,g.email||null,g.phone||null,g.relation||null,g.side||'mutual',g.category||'friend',code], type:sequelize.QueryTypes.INSERT, transaction:t }
        );
        created++;
      }
      await t.commit();
      res.json({ success:true, message:`${created} guests imported.`, data:{ created, skipped } });
    } catch(err) { await t.rollback(); next(err); }
  },
};

// ═══════════════════════════════════════════════════════════
//  FINANCE
// ═══════════════════════════════════════════════════════════
exports.finance = {
  invoices: async (req, res, next) => {
    try {
      const { page=1,limit=20,status,event_id,customer_id } = req.query;
      const offset=(page-1)*limit; const cid=req.user.company_id;
      let where='i.company_id=?'; const params=[cid];
      if (status)      { where+=' AND i.status=?';      params.push(status); }
      if (event_id)    { where+=' AND i.event_id=?';    params.push(event_id); }
      if (customer_id) { where+=' AND i.customer_id=?'; params.push(customer_id); }

      const invoices = await raw(`
        SELECT i.*,e.event_name,e.event_code,CONCAT(c.first_name,' ',c.last_name) AS customer_name,c.phone AS customer_phone
        FROM invoices i JOIN events e ON i.event_id=e.id JOIN customers c ON i.customer_id=c.id
        WHERE ${where} ORDER BY i.invoice_date DESC LIMIT ? OFFSET ?
      `, { replacements:[...params,+limit,offset] });

      res.json({ success:true, data:{ invoices } });
    } catch(err) { next(err); }
  },

  getInvoice: async (req, res, next) => {
    try {
      const [inv] = await raw(
        `SELECT i.*,e.event_name,e.event_date,CONCAT(c.first_name,' ',c.last_name) AS customer_name,c.phone,c.email,c.address
         FROM invoices i JOIN events e ON i.event_id=e.id JOIN customers c ON i.customer_id=c.id
         WHERE i.id=? AND i.company_id=?`,
        { replacements:[req.params.id, req.user.company_id] }
      );
      if (!inv) throw new AppError('Invoice not found.',404);
      const items = await raw('SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY sort_order', { replacements:[inv.id] });
      const payments = await raw('SELECT * FROM payments WHERE invoice_id=? ORDER BY payment_date', { replacements:[inv.id] });
      res.json({ success:true, data:{ invoice:inv, items, payments } });
    } catch(err) { next(err); }
  },

  recordPayment: async (req, res, next) => {
    try {
      const { invoice_id,booking_id,customer_id,amount,payment_date,payment_method,payment_ref,payment_type,notes } = req.body;
      const [cnt] = await raw('SELECT COUNT(*)+1 AS n FROM payments WHERE company_id=?', { replacements:[req.user.company_id] });
      const payment_code = `PAY-${new Date().getFullYear()}-${String(cnt.n).padStart(4,'0')}`;
      const [id] = await sequelize.query(
        `INSERT INTO payments (company_id,invoice_id,booking_id,customer_id,payment_code,amount,payment_date,payment_method,payment_ref,status,payment_type,notes)
         VALUES (?,?,?,?,?,?,?,?,?,'completed',?,?)`,
        { replacements:[req.user.company_id,invoice_id||null,booking_id||null,customer_id,payment_code,amount,payment_date,payment_method,payment_ref||null,payment_type||'full',notes||null], type:sequelize.QueryTypes.INSERT }
      );
      res.status(201).json({ success:true, message:'Payment recorded.', data:{ id, payment_code } });
    } catch(err) { next(err); }
  },

  expenses: async (req, res, next) => {
    try {
      const { event_id,page=1,limit=20,category } = req.query;
      const offset=(page-1)*limit; const cid=req.user.company_id;
      let where='e.company_id=?'; const params=[cid];
      if (event_id) { where+=' AND e.event_id=?';   params.push(event_id); }
      if (category) { where+=' AND e.category=?';   params.push(category); }

      const expenses = await raw(`
        SELECT e.*,ev.event_name,ev.event_code,v.business_name AS vendor_name
        FROM expenses e LEFT JOIN events ev ON e.event_id=ev.id LEFT JOIN vendors v ON e.vendor_id=v.id
        WHERE ${where} ORDER BY e.expense_date DESC LIMIT ? OFFSET ?
      `, { replacements:[...params,+limit,offset] });

      const [summary] = await raw(`
        SELECT COALESCE(SUM(amount),0) AS total, COUNT(*) AS count,
          SUM(status='pending') AS pending_count, SUM(status='paid') AS paid_count
        FROM expenses WHERE company_id=?
      `, { replacements:[cid] });

      res.json({ success:true, data:{ expenses, summary } });
    } catch(err) { next(err); }
  },

  addExpense: async (req, res, next) => {
    try {
      const { event_id,vendor_id,category,description,amount,expense_date,payment_method,notes } = req.body;
      const [id] = await sequelize.query(
        'INSERT INTO expenses (company_id,event_id,vendor_id,category,description,amount,expense_date,payment_method,notes,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        { replacements:[req.user.company_id,event_id||null,vendor_id||null,category,description,amount,expense_date,payment_method||'cash',notes||null,'pending',req.user.id], type:sequelize.QueryTypes.INSERT }
      );
      res.status(201).json({ success:true, message:'Expense recorded.', data:{ id } });
    } catch(err) { next(err); }
  },
};

const tryParse = v => { try { return JSON.parse(v); } catch { return v; } };

// ─── Extra vendor methods ─────────────────────────────────────────────────
exports.vendors.create = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    const { business_name, category_id, contact_name, email, phone, whatsapp,
            address, city, state, description, min_price, max_price, gst_number, pan_number } = req.body;
    if (!business_name || !phone) return res.status(400).json({ success: false, message: 'business_name and phone required' });
    const [result] = await sequelize.query(
      `INSERT INTO vendors (company_id, category_id, business_name, contact_name, email, phone, whatsapp,
       address, city, state, description, min_price, max_price, gst_number, pan_number, approval_status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending')`,
      { replacements: [req.user.company_id, category_id||1, business_name, contact_name||'', email||'', phone, whatsapp||'',
                       address||'', city||'', state||'', description||'', min_price||0, max_price||0, gst_number||'', pan_number||''] }
    );
    res.status(201).json({ success: true, message: 'Vendor added', data: { id: result } });
  } catch (err) { next(err); }
};

exports.vendors.update = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    const fields = ['business_name','contact_name','email','phone','city','description','min_price','max_price'];
    const updates = fields.filter(f => req.body[f] !== undefined).map(f => `${f}=?`).join(',');
    const vals = fields.filter(f => req.body[f] !== undefined).map(f => req.body[f]);
    if (!updates) return res.status(400).json({ success: false, message: 'No fields to update' });
    await sequelize.query(`UPDATE vendors SET ${updates} WHERE id=? AND company_id=?`,
      { replacements: [...vals, req.params.id, req.user.company_id] });
    res.json({ success: true, message: 'Vendor updated' });
  } catch (err) { next(err); }
};

exports.vendors.delete = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    await sequelize.query('DELETE FROM vendors WHERE id=? AND company_id=?',
      { replacements: [req.params.id, req.user.company_id] });
    res.json({ success: true, message: 'Vendor deleted' });
  } catch (err) { next(err); }
};

// ─── Extra customer methods ───────────────────────────────────────────────
exports.customers.delete = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    await sequelize.query('DELETE FROM customers WHERE id=? AND company_id=?',
      { replacements: [req.params.id, req.user.company_id] });
    res.json({ success: true, message: 'Customer deleted' });
  } catch (err) { next(err); }
};

// ─── Extra finance methods ────────────────────────────────────────────────
exports.finance.createInvoice = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    const { event_id, customer_id, invoice_date, due_date, subtotal, tax_rate, notes } = req.body;
    if (!event_id || !customer_id || !subtotal) return res.status(400).json({ success: false, message: 'event_id, customer_id, subtotal required' });
    const tax = req.body.tax_rate || 18;
    const tax_amount = Math.round(subtotal * tax / 100);
    const grand_total = subtotal + tax_amount;
    // Get next invoice number
    const [rows] = await sequelize.query("SELECT COUNT(*)+1 AS num FROM invoices WHERE company_id=?", { replacements:[req.user.company_id] });
    const inv_number = `INV-${new Date().getFullYear()}-${String(rows[0].num).padStart(5,'0')}`;
    const [result] = await sequelize.query(
      `INSERT INTO invoices (company_id, event_id, customer_id, invoice_number, invoice_date, due_date,
       subtotal, tax_rate, tax_amount, grand_total, amount_paid, balance_due, status, notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,0,?,\'sent\',?)`,
      { replacements: [req.user.company_id, event_id, customer_id, inv_number,
          invoice_date||new Date().toISOString().split('T')[0],
          due_date||new Date(Date.now()+864e6*15).toISOString().split('T')[0],
          subtotal, tax, tax_amount, grand_total, grand_total, notes||''] }
    );
    res.status(201).json({ success: true, message: 'Invoice created', data: { id: result, invoice_number: inv_number, grand_total } });
  } catch (err) { next(err); }
};

exports.finance.deleteExpense = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    await sequelize.query('DELETE FROM expenses WHERE id=? AND company_id=?',
      { replacements: [req.params.id, req.user.company_id] });
    res.json({ success: true, message: 'Expense deleted' });
  } catch (err) { next(err); }
};

// ─── Extra guest methods ──────────────────────────────────────────────────
exports.guests.getRSVPInfo = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    const [rows] = await sequelize.query(
      `SELECT g.*, e.event_name, e.event_date, e.event_time, v.name AS venue_name
       FROM guests g
       JOIN events e ON g.event_id = e.id
       LEFT JOIN venues v ON e.venue_id = v.id
       WHERE g.invitation_code=? LIMIT 1`,
      { replacements: [req.params.code] }
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Invitation not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) { next(err); }
};

exports.guests.update = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');
    const { rsvp_status, meal_preference, table_number, seat_number } = req.body;
    await sequelize.query(
      'UPDATE guests SET rsvp_status=COALESCE(?,rsvp_status), meal_preference=COALESCE(?,meal_preference), table_number=COALESCE(?,table_number) WHERE id=?',
      { replacements: [rsvp_status||null, meal_preference||null, table_number||null, req.params.id] }
    );
    res.json({ success: true, message: 'Guest updated' });
  } catch (err) { next(err); }
};
