/**
 * Events Controller
 * Full CRUD for Event Management + Tasks + Timeline
 */

const { sequelize } = require('../config/database');
const AppError = require('../utils/AppError');
const logger = require('../utils/logger');

const Q = sequelize.QueryTypes;
const raw = (sql, opts) => sequelize.query(sql, { type: Q.SELECT, ...opts });

/** GET /events - List events with filters, pagination */
exports.getEvents = async (req, res, next) => {
  try {
    const {
      page = 1, limit = 20, status, category_id, assigned_to,
      search, from_date, to_date, sort = 'event_date', order = 'ASC'
    } = req.query;
    const offset = (page - 1) * limit;
    const company_id = req.user.company_id;

    let where = 'e.company_id = ?';
    const params = [company_id];

    if (status)      { where += ' AND e.status = ?';          params.push(status); }
    if (category_id) { where += ' AND e.category_id = ?';     params.push(category_id); }
    if (assigned_to) { where += ' AND e.assigned_to = ?';     params.push(assigned_to); }
    if (from_date)   { where += ' AND e.event_date >= ?';     params.push(from_date); }
    if (to_date)     { where += ' AND e.event_date <= ?';     params.push(to_date); }
    if (search)      { where += ' AND (e.event_name LIKE ? OR e.event_code LIKE ? OR CONCAT(c.first_name," ",c.last_name) LIKE ?)';
                       params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

    // Restrict to own events for customer role
    if (req.user.role === 'customer') {
      where += ' AND c.user_id = ?'; params.push(req.user.id);
    }

    const sortAllowed = { event_date: 'e.event_date', created_at: 'e.created_at', event_name: 'e.event_name', budget_total: 'e.budget_total' };
    const sortCol = sortAllowed[sort] || 'e.event_date';
    const sortDir = order === 'DESC' ? 'DESC' : 'ASC';

    const [{ total }] = await raw(
      `SELECT COUNT(*) AS total FROM events e LEFT JOIN customers c ON e.customer_id = c.id WHERE ${where}`,
      { replacements: params }
    );

    const events = await raw(
      `SELECT e.id, e.event_code, e.event_name, e.event_date, e.event_time, e.end_date,
              e.status, e.guest_count_estimate, e.guest_count_actual, e.theme,
              e.budget_total, e.budget_spent, e.advance_paid, e.balance_due,
              CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
              c.phone AS customer_phone, c.email AS customer_email,
              ec.name AS category, ec.color AS category_color, ec.icon AS category_icon,
              v.name AS venue_name, v.city AS venue_city,
              CONCAT(u.first_name, ' ', u.last_name) AS assigned_to_name,
              fn_event_completion_pct(e.id) AS completion_pct,
              e.created_at
       FROM events e
       LEFT JOIN customers c  ON e.customer_id  = c.id
       LEFT JOIN event_categories ec ON e.category_id = ec.id
       LEFT JOIN venues v     ON e.venue_id     = v.id
       LEFT JOIN users u      ON e.assigned_to  = u.id
       WHERE ${where}
       ORDER BY ${sortCol} ${sortDir}
       LIMIT ? OFFSET ?`,
      { replacements: [...params, parseInt(limit), offset] }
    );

    res.json({
      success: true,
      data: {
        events,
        pagination: { page: parseInt(page), limit: parseInt(limit), total: parseInt(total), pages: Math.ceil(total / limit) },
      },
    });
  } catch (err) { next(err); }
};

/** GET /events/:id */
exports.getEvent = async (req, res, next) => {
  try {
    const [event] = await raw(
      `SELECT e.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name,
              c.phone AS customer_phone, c.email AS customer_email, c.whatsapp,
              ec.name AS category, ec.color, v.name AS venue_name,
              v.address AS venue_address, v.capacity_max,
              CONCAT(u.first_name,' ',u.last_name) AS assigned_to_name
       FROM events e
       LEFT JOIN customers c ON e.customer_id = c.id
       LEFT JOIN event_categories ec ON e.category_id = ec.id
       LEFT JOIN venues v ON e.venue_id = v.id
       LEFT JOIN users u ON e.assigned_to = u.id
       WHERE e.id = ? AND e.company_id = ?`,
      { replacements: [req.params.id, req.user.company_id] }
    );
    if (!event) throw new AppError('Event not found.', 404);

    // Fetch related data
    const tasks = await raw(
      `SELECT et.*, CONCAT(u.first_name,' ',u.last_name) AS assignee_name
       FROM event_tasks et LEFT JOIN users u ON et.assigned_to = u.id
       WHERE et.event_id = ? ORDER BY et.sort_order, et.due_date`,
      { replacements: [req.params.id] }
    );

    const bookings = await raw(
      `SELECT b.*, v.business_name AS vendor_name, vc.name AS vendor_category,
              ve.name AS venue_name
       FROM bookings b
       LEFT JOIN vendors v ON b.vendor_id = v.id
       LEFT JOIN vendor_categories vc ON v.category_id = vc.id
       LEFT JOIN venues ve ON b.venue_id = ve.id
       WHERE b.event_id = ?`,
      { replacements: [req.params.id] }
    );

    const guestStats = await raw(
      `SELECT rsvp_status, COUNT(*) AS count
       FROM guests WHERE event_id = ? GROUP BY rsvp_status`,
      { replacements: [req.params.id] }
    );

    const financials = await raw(
      `SELECT * FROM vw_event_financials WHERE event_id = ?`,
      { replacements: [req.params.id] }
    );

    res.json({
      success: true,
      data: {
        event: { ...event, checklist: tryParse(event.checklist), timeline: tryParse(event.timeline) },
        tasks,
        bookings,
        guest_summary: guestStats,
        financials: financials[0] || {},
      },
    });
  } catch (err) { next(err); }
};

/** POST /events */
exports.createEvent = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const {
      customer_id, category_id, venue_id, event_name, event_date, event_time,
      end_date, end_time, guest_count_estimate, theme, color_scheme, dress_code,
      special_requirements, budget_total, notes, assigned_to,
    } = req.body;

    // Generate event code
    const [{ cnt }] = await raw(
      'SELECT COUNT(*) + 1 AS cnt FROM events WHERE company_id = ? AND YEAR(created_at) = YEAR(NOW())',
      { replacements: [req.user.company_id] }
    );
    const event_code = `EVT-${new Date().getFullYear()}-${String(cnt).padStart(4,'0')}`;

    const [eventId] = await sequelize.query(
      `INSERT INTO events (company_id, customer_id, category_id, venue_id, assigned_to, event_name, event_code,
        event_date, event_time, end_date, end_time, guest_count_estimate, theme, color_scheme, dress_code,
        special_requirements, budget_total, notes, status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'inquiry')`,
      { replacements: [
          req.user.company_id, customer_id, category_id||null, venue_id||null,
          assigned_to||req.user.id, event_name, event_code,
          event_date, event_time||null, end_date||null, end_time||null,
          guest_count_estimate||0, theme||null, color_scheme||null, dress_code||null,
          special_requirements||null, budget_total||0, notes||null,
        ], type: sequelize.QueryTypes.INSERT, transaction: t }
    );

    // Reserve venue if provided
    if (venue_id && event_date) {
      await sequelize.query(
        'INSERT INTO venue_bookings (venue_id, event_id, booked_date, start_time, end_time, status) VALUES (?,?,?,?,?,?)',
        { replacements: [venue_id, eventId, event_date, event_time||'00:00:00', end_time||'23:59:59', 'reserved'],
          type: sequelize.QueryTypes.INSERT, transaction: t }
      );
    }

    await t.commit();
    logger.info(`Event created: ${event_code} by user ${req.user.id}`);

    res.status(201).json({
      success: true,
      message: 'Event created successfully.',
      data: { id: eventId, event_code },
    });
  } catch (err) { await t.rollback(); next(err); }
};

/** PUT /events/:id */
exports.updateEvent = async (req, res, next) => {
  try {
    const allowed = [
      'event_name','event_date','event_time','end_date','end_time',
      'category_id','venue_id','assigned_to','guest_count_estimate','guest_count_actual',
      'theme','color_scheme','dress_code','special_requirements','budget_total',
      'status','notes','internal_notes','checklist','timeline',
    ];
    const fields = Object.keys(req.body).filter(k => allowed.includes(k));
    if (!fields.length) throw new AppError('No valid fields to update.', 400);

    const sets = fields.map(f => `${f} = ?`).join(', ');
    const vals = fields.map(f => {
      const v = req.body[f];
      return typeof v === 'object' ? JSON.stringify(v) : v;
    });

    const [affected] = await sequelize.query(
      `UPDATE events SET ${sets} WHERE id = ? AND company_id = ?`,
      { replacements: [...vals, req.params.id, req.user.company_id], type: sequelize.QueryTypes.UPDATE }
    );
    if (affected === 0) throw new AppError('Event not found or no changes made.', 404);

    res.json({ success: true, message: 'Event updated.' });
  } catch (err) { next(err); }
};

/** DELETE /events/:id */
exports.deleteEvent = async (req, res, next) => {
  try {
    const [event] = await raw(
      'SELECT id, status FROM events WHERE id = ? AND company_id = ?',
      { replacements: [req.params.id, req.user.company_id] }
    );
    if (!event) throw new AppError('Event not found.', 404);
    if (['completed','in_progress'].includes(event.status)) {
      throw new AppError('Cannot delete a completed or in-progress event.', 400);
    }
    await sequelize.query('DELETE FROM events WHERE id = ?', {
      replacements: [req.params.id], type: sequelize.QueryTypes.DELETE
    });
    res.json({ success: true, message: 'Event deleted.' });
  } catch (err) { next(err); }
};

/** GET /events/upcoming */
exports.getUpcomingEvents = async (req, res, next) => {
  try {
    const events = await raw(
      `SELECT e.id, e.event_code, e.event_name, e.event_date, e.event_time, e.status,
              ec.name AS category, ec.color,
              CONCAT(c.first_name,' ',c.last_name) AS customer,
              v.name AS venue,
              DATEDIFF(e.event_date, CURDATE()) AS days_remaining,
              fn_event_completion_pct(e.id) AS completion_pct
       FROM events e
       LEFT JOIN customers c ON e.customer_id = c.id
       LEFT JOIN event_categories ec ON e.category_id = ec.id
       LEFT JOIN venues v ON e.venue_id = v.id
       WHERE e.company_id = ? AND e.event_date >= CURDATE()
         AND e.status NOT IN ('cancelled','completed')
       ORDER BY e.event_date ASC LIMIT 10`,
      { replacements: [req.user.company_id] }
    );
    res.json({ success: true, data: events });
  } catch (err) { next(err); }
};

/** POST /events/:id/tasks */
exports.createTask = async (req, res, next) => {
  try {
    const { title, description, category, priority, assigned_to, due_date, due_time, parent_task_id } = req.body;
    const [id] = await sequelize.query(
      `INSERT INTO event_tasks (event_id, parent_task_id, assigned_to, title, description, category, priority, due_date, due_time, created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      { replacements: [req.params.id, parent_task_id||null, assigned_to||null, title, description||null, category||null, priority||'medium', due_date||null, due_time||null, req.user.id],
        type: sequelize.QueryTypes.INSERT }
    );
    res.status(201).json({ success: true, message: 'Task created.', data: { id } });
  } catch (err) { next(err); }
};

/** PATCH /events/:id/tasks/:taskId */
exports.updateTask = async (req, res, next) => {
  try {
    const { status, assigned_to, due_date, priority, title } = req.body;
    const completed_at = status === 'completed' ? new Date() : null;
    await sequelize.query(
      `UPDATE event_tasks SET status = COALESCE(?,status), assigned_to = COALESCE(?,assigned_to),
       due_date = COALESCE(?,due_date), priority = COALESCE(?,priority), title = COALESCE(?,title),
       completed_at = ? WHERE id = ? AND event_id = ?`,
      { replacements: [status||null, assigned_to||null, due_date||null, priority||null, title||null, completed_at, req.params.taskId, req.params.id],
        type: sequelize.QueryTypes.UPDATE }
    );
    res.json({ success: true, message: 'Task updated.' });
  } catch (err) { next(err); }
};

const tryParse = (v) => { try { return JSON.parse(v); } catch { return v; } };
