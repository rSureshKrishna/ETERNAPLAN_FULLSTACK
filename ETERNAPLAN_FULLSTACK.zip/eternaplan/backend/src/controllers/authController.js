/**
 * Auth Controller
 * Handles: Login, Register, Refresh Token, Forgot Password, OTP, Logout
 */

const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const crypto   = require('crypto');
const { Op }   = require('sequelize');
const { sequelize } = require('../config/database');
const { generateTokens, verifyRefreshToken } = require('../utils/jwt');
const { sendEmail }  = require('../utils/email');
const { sendSMS }    = require('../utils/sms');
const logger         = require('../utils/logger');
const AppError       = require('../utils/AppError');

// ── Inline model query helpers (using raw SQL for performance) ──────────────
const rawQuery = (sql, opts) => sequelize.query(sql, { type: sequelize.QueryTypes.SELECT, ...opts });

/** POST /auth/register */
exports.register = async (req, res, next) => {
  try {
    const { first_name, last_name, email, phone, password, company_name } = req.body;

    // Check duplicate email
    const [existing] = await rawQuery('SELECT id FROM users WHERE email = ? LIMIT 1', { replacements: [email] });
    if (existing) throw new AppError('Email already registered.', 409);

    const password_hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    const otp_code      = Math.floor(100000 + Math.random() * 900000).toString();
    const otp_expires   = new Date(Date.now() + 10 * 60 * 1000);

    // Create company first if provided
    let company_id = null;
    if (company_name) {
      const slug = company_name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      const [comp] = await sequelize.query(
        'INSERT INTO companies (name, slug, email) VALUES (?, ?, ?)',
        { replacements: [company_name, slug + '-' + Date.now(), email], type: sequelize.QueryTypes.INSERT }
      );
      company_id = comp;
    }

    const [userId] = await sequelize.query(
      `INSERT INTO users (company_id, role_id, first_name, last_name, email, phone, password_hash, otp_code, otp_expires_at, status)
       VALUES (?, 2, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      { replacements: [company_id, first_name, last_name, email, phone, password_hash, otp_code, otp_expires], type: sequelize.QueryTypes.INSERT }
    );

    // Send OTP email
    await sendEmail({
      to: email,
      subject: 'Verify Your EternaPlaan Account',
      template: 'otp',
      context: { name: first_name, otp: otp_code },
    });

    logger.info(`New user registered: ${email}`);
    res.status(201).json({
      success: true,
      message: 'Registration successful. OTP sent to your email.',
      data: { user_id: userId, email },
    });
  } catch (err) { next(err); }
};

/** POST /auth/verify-otp */
exports.verifyOTP = async (req, res, next) => {
  try {
    const { email, otp } = req.body;
    const [user] = await rawQuery(
      'SELECT id, otp_code, otp_expires_at FROM users WHERE email = ? LIMIT 1',
      { replacements: [email] }
    );
    if (!user) throw new AppError('User not found.', 404);
    if (user.otp_code !== otp) throw new AppError('Invalid OTP.', 400);
    if (new Date(user.otp_expires_at) < new Date()) throw new AppError('OTP expired.', 400);

    await sequelize.query(
      'UPDATE users SET email_verified = 1, status = "active", otp_code = NULL, otp_expires_at = NULL WHERE id = ?',
      { replacements: [user.id], type: sequelize.QueryTypes.UPDATE }
    );
    res.json({ success: true, message: 'Email verified successfully.' });
  } catch (err) { next(err); }
};

/** POST /auth/login */
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const [user] = await rawQuery(
      `SELECT u.*, r.name AS role_name, r.permissions, c.name AS company_name, c.slug AS company_slug
       FROM users u
       LEFT JOIN roles r ON u.role_id = r.id
       LEFT JOIN companies c ON u.company_id = c.id
       WHERE u.email = ? LIMIT 1`,
      { replacements: [email] }
    );

    if (!user) throw new AppError('Invalid credentials.', 401);
    if (user.status === 'suspended') throw new AppError('Account suspended. Contact support.', 403);
    if (user.status === 'inactive') throw new AppError('Account inactive.', 403);
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      throw new AppError(`Account locked. Try after ${new Date(user.locked_until).toLocaleTimeString()}.`, 423);
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      const attempts = (user.failed_attempts || 0) + 1;
      const locked_until = attempts >= 5 ? new Date(Date.now() + 30 * 60 * 1000) : null;
      await sequelize.query(
        'UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?',
        { replacements: [attempts, locked_until, user.id], type: sequelize.QueryTypes.UPDATE }
      );
      throw new AppError(`Invalid credentials. ${5 - attempts} attempts remaining.`, 401);
    }

    // Reset failed attempts
    const { accessToken, refreshToken } = generateTokens(user);
    await sequelize.query(
      'UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login = NOW(), refresh_token = ? WHERE id = ?',
      { replacements: [refreshToken, user.id], type: sequelize.QueryTypes.UPDATE }
    );

    // Set refresh token in httpOnly cookie
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    logger.info(`User logged in: ${email}`);
    res.json({
      success: true,
      message: 'Login successful.',
      data: {
        token: accessToken,
        user: {
          id: user.id,
          name: `${user.first_name} ${user.last_name}`,
          email: user.email,
          phone: user.phone,
          role: user.role_name,
          permissions: JSON.parse(user.permissions || '{}'),
          company: { id: user.company_id, name: user.company_name, slug: user.company_slug },
          avatar: user.avatar_url,
        },
      },
    });
  } catch (err) { next(err); }
};

/** POST /auth/refresh */
exports.refreshToken = async (req, res, next) => {
  try {
    const token = req.cookies.refreshToken || req.body.refreshToken;
    if (!token) throw new AppError('Refresh token required.', 401);

    const decoded = verifyRefreshToken(token);
    const [user] = await rawQuery(
      'SELECT id, refresh_token, status FROM users WHERE id = ? LIMIT 1',
      { replacements: [decoded.id] }
    );
    if (!user || user.refresh_token !== token || user.status !== 'active') {
      throw new AppError('Invalid or expired refresh token.', 401);
    }

    const { accessToken, refreshToken: newRefresh } = generateTokens(user);
    await sequelize.query(
      'UPDATE users SET refresh_token = ? WHERE id = ?',
      { replacements: [newRefresh, user.id], type: sequelize.QueryTypes.UPDATE }
    );
    res.cookie('refreshToken', newRefresh, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 7*24*60*60*1000 });
    res.json({ success: true, data: { token: accessToken } });
  } catch (err) { next(err); }
};

/** POST /auth/forgot-password */
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    const [user] = await rawQuery('SELECT id, first_name FROM users WHERE email = ? LIMIT 1', { replacements: [email] });
    // Always return success to prevent email enumeration
    if (!user) return res.json({ success: true, message: 'If your email is registered, you will receive a reset link.' });

    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    const expires = new Date(Date.now() + 30 * 60 * 1000);

    await sequelize.query(
      'UPDATE users SET password_reset_token = ?, password_reset_expires = ? WHERE id = ?',
      { replacements: [hashedToken, expires, user.id], type: sequelize.QueryTypes.UPDATE }
    );

    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;
    await sendEmail({
      to: email,
      subject: 'Reset Your EternaPlaan Password',
      template: 'reset-password',
      context: { name: user.first_name, resetUrl },
    });

    res.json({ success: true, message: 'Password reset link sent to your email.' });
  } catch (err) { next(err); }
};

/** POST /auth/reset-password */
exports.resetPassword = async (req, res, next) => {
  try {
    const { token, password } = req.body;
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const [user] = await rawQuery(
      'SELECT id FROM users WHERE password_reset_token = ? AND password_reset_expires > NOW() LIMIT 1',
      { replacements: [hashedToken] }
    );
    if (!user) throw new AppError('Reset token invalid or expired.', 400);

    const password_hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    await sequelize.query(
      'UPDATE users SET password_hash = ?, password_reset_token = NULL, password_reset_expires = NULL WHERE id = ?',
      { replacements: [password_hash, user.id], type: sequelize.QueryTypes.UPDATE }
    );
    res.json({ success: true, message: 'Password reset successfully. Please login.' });
  } catch (err) { next(err); }
};

/** POST /auth/logout */
exports.logout = async (req, res, next) => {
  try {
    await sequelize.query(
      'UPDATE users SET refresh_token = NULL WHERE id = ?',
      { replacements: [req.user.id], type: sequelize.QueryTypes.UPDATE }
    );
    res.clearCookie('refreshToken');
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (err) { next(err); }
};

/** GET /auth/me */
exports.getProfile = async (req, res, next) => {
  try {
    const [user] = await rawQuery(
      `SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.avatar_url,
              u.last_login, u.created_at, r.name AS role, r.permissions,
              c.id AS company_id, c.name AS company_name
       FROM users u
       LEFT JOIN roles r ON u.role_id = r.id
       LEFT JOIN companies c ON u.company_id = c.id
       WHERE u.id = ? AND u.status = 'active'`,
      { replacements: [req.user.id] }
    );
    if (!user) throw new AppError('User not found.', 404);
    res.json({ success: true, data: user });
  } catch (err) { next(err); }
};
