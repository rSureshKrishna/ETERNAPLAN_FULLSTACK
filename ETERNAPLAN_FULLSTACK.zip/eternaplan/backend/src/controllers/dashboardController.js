/**
 * Dashboard Controller
 * Advanced analytics: revenue, bookings, events, vendors, growth metrics
 */

const { sequelize } = require('../config/database');
const AppError = require('../utils/AppError');

const raw = (sql, opts) => sequelize.query(sql, { type: sequelize.QueryTypes.SELECT, ...opts });

/** GET /dashboard/overview */
exports.getOverview = async (req, res, next) => {
  try {
    const cid  = req.user.company_id;
    const year = parseInt(req.query.year) || new Date().getFullYear();

    // ── KPI Cards ────────────────────────────────────────
    const [kpi] = await raw(`
      SELECT
        (SELECT COUNT(*) FROM events   WHERE company_id=? AND YEAR(event_date)=?) AS total_events,
        (SELECT COUNT(*) FROM events   WHERE company_id=? AND status='completed'  AND YEAR(event_date)=?) AS completed_events,
        (SELECT COUNT(*) FROM events   WHERE company_id=? AND event_date>=CURDATE() AND status NOT IN('cancelled','completed')) AS upcoming_events,
        (SELECT COUNT(*) FROM customers WHERE company_id=?) AS total_customers,
        (SELECT COUNT(*) FROM customers WHERE company_id=? AND YEAR(created_at)=?) AS new_customers,
        (SELECT COUNT(*) FROM bookings  WHERE company_id=? AND YEAR(created_at)=?) AS total_bookings,
        (SELECT COALESCE(SUM(amount),0) FROM payments p JOIN invoices i ON p.invoice_id=i.id
         WHERE i.company_id=? AND p.status='completed' AND YEAR(p.payment_date)=?) AS total_revenue,
        (SELECT COALESCE(SUM(amount),0) FROM payments p JOIN invoices i ON p.invoice_id=i.id
         WHERE i.company_id=? AND p.status='completed'
         AND MONTH(p.payment_date)=MONTH(NOW()) AND YEAR(p.payment_date)=YEAR(NOW())) AS revenue_this_month,
        (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE company_id=? AND YEAR(expense_date)=?) AS total_expenses,
        (SELECT COUNT(*) FROM vendors WHERE company_id=? AND approval_status='approved') AS total_vendors
    `, { replacements: [cid,year, cid,year, cid, cid, cid,year, cid,year, cid,year, cid, cid,year, cid] });

    // ── Monthly Revenue (last 12 months) ─────────────────
    const monthlyRevenue = await raw(`
      SELECT
        DATE_FORMAT(p.payment_date,'%b %Y') AS month_label,
        DATE_FORMAT(p.payment_date,'%Y-%m') AS month_key,
        COALESCE(SUM(p.amount),0)          AS revenue,
        COALESCE(SUM(e2.amount),0)         AS expenses,
        COUNT(DISTINCT p.id)               AS transactions
      FROM payments p
      JOIN invoices i ON p.invoice_id = i.id
      LEFT JOIN expenses e2 ON e2.company_id = i.company_id
        AND DATE_FORMAT(e2.expense_date,'%Y-%m') = DATE_FORMAT(p.payment_date,'%Y-%m')
      WHERE i.company_id=? AND p.status='completed'
        AND p.payment_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
      GROUP BY DATE_FORMAT(p.payment_date,'%Y-%m')
      ORDER BY month_key ASC
    `, { replacements: [cid] });

    // ── Event Status Distribution ─────────────────────────
    const eventStatus = await raw(`
      SELECT status, COUNT(*) AS count,
        ROUND(COUNT(*)*100.0/(SELECT COUNT(*) FROM events WHERE company_id=?),1) AS pct
      FROM events WHERE company_id=? AND YEAR(event_date)=?
      GROUP BY status
    `, { replacements: [cid, cid, year] });

    // ── Event Category Distribution ───────────────────────
    const categoryDist = await raw(`
      SELECT ec.name, ec.color, COUNT(e.id) AS count
      FROM events e JOIN event_categories ec ON e.category_id = ec.id
      WHERE e.company_id=?
      GROUP BY ec.id ORDER BY count DESC
    `, { replacements: [cid] });

    // ── Top Vendors by Revenue ────────────────────────────
    const topVendors = await raw(`
      SELECT v.business_name, vc.name AS category, v.city,
        COUNT(b.id) AS bookings, SUM(b.agreed_price) AS revenue,
        ROUND(v.rating,1) AS rating
      FROM bookings b
      JOIN vendors v ON b.vendor_id = v.id
      JOIN vendor_categories vc ON v.category_id = vc.id
      WHERE b.company_id=? AND b.status='completed'
      GROUP BY v.id ORDER BY revenue DESC LIMIT 6
    `, { replacements: [cid] });

    // ── Recent Activities ─────────────────────────────────
    const recentActivities = await raw(`
      SELECT af.action, af.description, af.created_at,
        CONCAT(u.first_name,' ',u.last_name) AS user_name, u.avatar_url
      FROM activity_feed af
      LEFT JOIN users u ON af.user_id = u.id
      WHERE af.company_id=?
      ORDER BY af.created_at DESC LIMIT 12
    `, { replacements: [cid] });

    // ── Upcoming Events ───────────────────────────────────
    const upcomingEvents = await raw(`
      SELECT e.id, e.event_code, e.event_name, e.event_date, e.event_time, e.status,
        ec.name AS category, ec.color,
        CONCAT(c.first_name,' ',c.last_name) AS customer,
        v.name AS venue, DATEDIFF(e.event_date,CURDATE()) AS days_away,
        fn_event_completion_pct(e.id) AS completion_pct
      FROM events e
      LEFT JOIN customers c ON e.customer_id=c.id
      LEFT JOIN event_categories ec ON e.category_id=ec.id
      LEFT JOIN venues v ON e.venue_id=v.id
      WHERE e.company_id=? AND e.event_date>=CURDATE()
        AND e.status NOT IN('cancelled','completed')
      ORDER BY e.event_date ASC LIMIT 5
    `, { replacements: [cid] });

    // ── Customer Growth (last 6 months) ──────────────────
    const customerGrowth = await raw(`
      SELECT DATE_FORMAT(created_at,'%b') AS month,
        DATE_FORMAT(created_at,'%Y-%m')   AS month_key,
        COUNT(*) AS new_customers,
        SUM(COUNT(*)) OVER (ORDER BY DATE_FORMAT(created_at,'%Y-%m')) AS cumulative
      FROM customers WHERE company_id=?
        AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
      GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY month_key
    `, { replacements: [cid] });

    // ── Pending Tasks count ───────────────────────────────
    const [taskSummary] = await raw(`
      SELECT
        COUNT(*)                                    AS total,
        SUM(et.status='pending')                    AS pending,
        SUM(et.status='in_progress')                AS in_progress,
        SUM(et.status='completed')                  AS completed,
        SUM(et.priority='critical' AND et.status != 'completed') AS critical_open,
        SUM(et.due_date < CURDATE() AND et.status != 'completed') AS overdue
      FROM event_tasks et
      JOIN events e ON et.event_id = e.id
      WHERE e.company_id=?
    `, { replacements: [cid] });

    // ── Revenue by Payment Method ─────────────────────────
    const paymentMethods = await raw(`
      SELECT p.payment_method, SUM(p.amount) AS total,
        COUNT(*) AS count,
        ROUND(SUM(p.amount)*100/(SELECT SUM(amount) FROM payments p2
          JOIN invoices i2 ON p2.invoice_id=i2.id
          WHERE i2.company_id=? AND p2.status='completed' AND YEAR(p2.payment_date)=?),1) AS pct
      FROM payments p JOIN invoices i ON p.invoice_id=i.id
      WHERE i.company_id=? AND p.status='completed' AND YEAR(p.payment_date)=?
      GROUP BY p.payment_method ORDER BY total DESC
    `, { replacements: [cid, year, cid, year] });

    // ── Outstanding Balances ──────────────────────────────
    const outstanding = await raw(`
      SELECT CONCAT(c.first_name,' ',c.last_name) AS customer, c.phone,
        e.event_name, e.event_date, i.invoice_number,
        i.grand_total, i.amount_paid, i.balance_due, i.due_date,
        CASE WHEN i.due_date < CURDATE() THEN 'overdue' ELSE 'pending' END AS overdue_status
      FROM invoices i
      JOIN events e ON i.event_id=e.id
      JOIN customers c ON i.customer_id=c.id
      WHERE i.company_id=? AND i.balance_due > 0 AND i.status NOT IN('cancelled','paid')
      ORDER BY i.due_date ASC LIMIT 8
    `, { replacements: [cid] });

    res.json({
      success: true,
      data: {
        kpi,
        monthly_revenue: monthlyRevenue,
        event_status: eventStatus,
        category_distribution: categoryDist,
        top_vendors: topVendors,
        recent_activities: recentActivities,
        upcoming_events: upcomingEvents,
        customer_growth: customerGrowth,
        task_summary: taskSummary,
        payment_methods: paymentMethods,
        outstanding_balances: outstanding,
      },
    });
  } catch (err) { next(err); }
};

/** GET /dashboard/reports/monthly */
exports.getMonthlyReport = async (req, res, next) => {
  try {
    const cid   = req.user.company_id;
    const month = parseInt(req.query.month) || new Date().getMonth() + 1;
    const year  = parseInt(req.query.year)  || new Date().getFullYear();

    const events = await raw(`
      SELECT e.event_code, e.event_name, e.event_date, e.status,
        ec.name AS category, CONCAT(c.first_name,' ',c.last_name) AS customer,
        v.name AS venue, e.guest_count_actual, e.budget_total,
        COALESCE(SUM(p.amount),0) AS received
      FROM events e
      LEFT JOIN customers c ON e.customer_id=c.id
      LEFT JOIN event_categories ec ON e.category_id=ec.id
      LEFT JOIN venues v ON e.venue_id=v.id
      LEFT JOIN invoices i ON e.id=i.event_id
      LEFT JOIN payments p ON i.id=p.invoice_id AND p.status='completed'
      WHERE e.company_id=? AND MONTH(e.event_date)=? AND YEAR(e.event_date)=?
      GROUP BY e.id ORDER BY e.event_date
    `, { replacements: [cid, month, year] });

    const [summary] = await raw(`
      SELECT
        COUNT(DISTINCT e.id)             AS total_events,
        SUM(e.guest_count_actual)        AS total_guests,
        COALESCE(SUM(p.amount),0)        AS total_revenue,
        COALESCE(SUM(ex.amount),0)       AS total_expenses,
        COALESCE(SUM(p.amount),0) - COALESCE(SUM(ex.amount),0) AS net_profit
      FROM events e
      LEFT JOIN invoices i ON e.id=i.event_id
      LEFT JOIN payments p ON i.id=p.invoice_id AND p.status='completed'
      LEFT JOIN expenses ex ON e.id=ex.event_id
      WHERE e.company_id=? AND MONTH(e.event_date)=? AND YEAR(e.event_date)=?
    `, { replacements: [cid, month, year] });

    res.json({ success: true, data: { events, summary } });
  } catch (err) { next(err); }
};

/** GET /dashboard/calendar */
exports.getCalendar = async (req, res, next) => {
  try {
    const { year, month } = req.query;
    const cid = req.user.company_id;
    const events = await raw(`
      SELECT e.id, e.event_name, e.event_code, e.event_date, e.event_time,
        e.status, ec.color, ec.name AS category,
        CONCAT(c.first_name,' ',c.last_name) AS customer
      FROM events e
      LEFT JOIN event_categories ec ON e.category_id=ec.id
      LEFT JOIN customers c ON e.customer_id=c.id
      WHERE e.company_id=? AND YEAR(e.event_date)=? AND MONTH(e.event_date)=?
      ORDER BY e.event_date, e.event_time
    `, { replacements: [cid, year, month] });
    res.json({ success: true, data: events });
  } catch (err) { next(err); }
};
