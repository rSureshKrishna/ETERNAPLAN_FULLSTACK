/**
 * EternaPlaan - Server Entry Point
 * Handles process-level error catching and server startup
 */

require('dotenv').config();
const app = require('./app');
const { sequelize } = require('./config/database');
const logger = require('./utils/logger');

const PORT = process.env.PORT || 5000;

// Graceful shutdown handler
const gracefulShutdown = (signal) => {
  logger.info(`Received ${signal}. Starting graceful shutdown...`);
  server.close(async () => {
    await sequelize.close();
    logger.info('Database connections closed.');
    process.exit(0);
  });
};

// Start server
const server = app.listen(PORT, async () => {
  try {
    await sequelize.authenticate();
    logger.info('✅ Database connection established.');
    logger.info(`🚀 EternaPlaan API running on port ${PORT} [${process.env.NODE_ENV}]`);
  } catch (error) {
    logger.error('❌ Unable to connect to database:', error);
    process.exit(1);
  }
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
  gracefulShutdown('unhandledRejection');
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  gracefulShutdown('uncaughtException');
});

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT',  () => gracefulShutdown('SIGINT'));
