/**
 * EternaPlaan - Main Router
 * Wires all route modules to /api/v1/*
 */
const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth.middleware');
const authCtrl = require('../controllers/authController');
const evtCtrl  = require('../controllers/eventController');
const dashCtrl = require('../controllers/dashboardController');
const { customers, vendors, bookings, guests, finance } = require('../controllers/combinedControllers');
const { body, query, param } = require('express-validator');
const { validateRequest } = require('../middleware/validate.middleware');

// ─── Auth Routes ─────────────────────────────────────────────
router.post('/auth/register',
  [body('email').isEmail(), body('password').isLength({min:8}), body('first_name').notEmpty(), body('last_name').notEmpty(), body('phone').notEmpty()],
  validateRequest, authCtrl.register
);
router.post('/auth/login',
  [body('email').isEmail(), body('password').notEmpty()],
  validateRequest, authCtrl.login
);
router.post('/auth/verify-otp',   [body('email').isEmail(), body('otp').isLength({min:6,max:6})], validateRequest, authCtrl.verifyOTP);
router.post('/auth/refresh',      authCtrl.refreshToken);
router.post('/auth/forgot-password', [body('email').isEmail()], validateRequest, authCtrl.forgotPassword);
router.post('/auth/reset-password',  [body('token').notEmpty(), body('password').isLength({min:8})], validateRequest, authCtrl.resetPassword);
router.post('/auth/logout',       authenticate, authCtrl.logout);
router.get('/auth/me',            authenticate, authCtrl.getProfile);

// ─── Dashboard Routes ─────────────────────────────────────────
router.get('/dashboard/overview',          authenticate, authorize('super_admin','admin','event_manager'), dashCtrl.getOverview);
router.get('/dashboard/reports/monthly',   authenticate, authorize('super_admin','admin'), dashCtrl.getMonthlyReport);
router.get('/dashboard/calendar',          authenticate, dashCtrl.getCalendar);

// ─── Event Routes ─────────────────────────────────────────────
router.get('/events',                  authenticate, evtCtrl.getEvents);
router.post('/events',                 authenticate, authorize('super_admin','admin','event_manager'), evtCtrl.createEvent);
router.get('/events/upcoming',         authenticate, evtCtrl.getUpcomingEvents);
router.get('/events/:id',              authenticate, evtCtrl.getEvent);
router.put('/events/:id',              authenticate, authorize('super_admin','admin','event_manager'), evtCtrl.updateEvent);
router.delete('/events/:id',           authenticate, authorize('super_admin','admin'), evtCtrl.deleteEvent);
router.post('/events/:id/tasks',       authenticate, evtCtrl.createTask);
router.patch('/events/:id/tasks/:taskId', authenticate, evtCtrl.updateTask);

// ─── Customer Routes ──────────────────────────────────────────
router.get('/customers',               authenticate, customers.list);
router.post('/customers',              authenticate, authorize('super_admin','admin','event_manager'), customers.create);
router.get('/customers/:id',           authenticate, customers.get);
router.put('/customers/:id',           authenticate, authorize('super_admin','admin','event_manager'), customers.update);
router.post('/customers/:id/notes',    authenticate, customers.addNote);

// ─── Vendor Routes ────────────────────────────────────────────
router.get('/vendors',                 authenticate, vendors.list);
router.get('/vendors/:id',             authenticate, vendors.get);
router.patch('/vendors/:id/approve',   authenticate, authorize('super_admin','admin'), vendors.approve);

// ─── Booking Routes ───────────────────────────────────────────
router.get('/bookings',                authenticate, bookings.list);
router.post('/bookings',               authenticate, authorize('super_admin','admin','event_manager'), bookings.create);
router.patch('/bookings/:id/status',   authenticate, bookings.updateStatus);

// ─── Guest Routes ─────────────────────────────────────────────
router.get('/guests',                  authenticate, guests.list);
router.post('/guests',                 authenticate, guests.create);
router.post('/guests/bulk-import',     authenticate, guests.bulkImport);
router.patch('/guests/rsvp/:code',     guests.updateRSVP);   // Public - for RSVP link
router.patch('/guests/:id/check-in',   authenticate, guests.checkIn);

// ─── Finance Routes ───────────────────────────────────────────
router.get('/finance/invoices',        authenticate, finance.invoices);
router.get('/finance/invoices/:id',    authenticate, finance.getInvoice);
router.post('/finance/payments',       authenticate, authorize('super_admin','admin'), finance.recordPayment);
router.get('/finance/expenses',        authenticate, finance.expenses);
router.post('/finance/expenses',       authenticate, finance.addExpense);

// ─── Utility Routes ───────────────────────────────────────────
router.get('/meta/categories',    async (req, res) => {
  const { sequelize } = require('../config/database');
  const cats = await sequelize.query('SELECT * FROM event_categories WHERE is_active=1 ORDER BY sort_order', { type: sequelize.QueryTypes.SELECT });
  res.json({ success:true, data: cats });
});
router.get('/meta/vendor-categories', async (req, res) => {
  const { sequelize } = require('../config/database');
  const cats = await sequelize.query('SELECT * FROM vendor_categories WHERE is_active=1', { type: sequelize.QueryTypes.SELECT });
  res.json({ success:true, data: cats });
});
router.get('/meta/venues', authenticate, async (req, res) => {
  const { sequelize } = require('../config/database');
  const venues = await sequelize.query('SELECT id,name,city,capacity_max,base_price,price_per_day FROM venues WHERE is_available=1 ORDER BY name', { type: sequelize.QueryTypes.SELECT });
  res.json({ success:true, data: venues });
});

// Extra routes to append
router.post('/vendors',                authenticate, authorize('super_admin','admin'), vendors.create);
router.put('/vendors/:id',             authenticate, authorize('super_admin','admin'), vendors.update);
router.delete('/vendors/:id',          authenticate, authorize('super_admin','admin'), vendors.delete);
router.post('/finance/invoices',       authenticate, authorize('super_admin','admin'), finance.createInvoice);
router.delete('/finance/expenses/:id', authenticate, finance.deleteExpense);
router.get('/guests/rsvp-info/:code',  guests.getRSVPInfo);
router.patch('/guests/:id',            authenticate, guests.update);
router.delete('/customers/:id',        authenticate, authorize('super_admin','admin'), customers.delete);

module.exports = router;
