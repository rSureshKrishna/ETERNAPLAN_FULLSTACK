# EternaPlaan™ — Quick Start Guide

## Prerequisites
- Node.js >= 18
- MySQL 8.0
- npm or yarn

---

## Option A: Local Development (Fastest)

### 1. Setup Database
```bash
mysql -u root -p -e "
  CREATE DATABASE eternaplan_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  CREATE USER 'eternaplan'@'localhost' IDENTIFIED BY 'Password@123';
  GRANT ALL PRIVILEGES ON eternaplan_db.* TO 'eternaplan'@'localhost';
  FLUSH PRIVILEGES;
"
mysql -u root -p eternaplan_db < database/schema.sql
mysql -u root -p eternaplan_db < database/seed.sql
```

### 2. Setup Backend
```bash
cd backend
cp .env.example .env
# Edit .env — set DB_PASSWORD and JWT_SECRET at minimum
npm install
npm run dev
# API running at http://localhost:5000
```

### 3. Setup Frontend
```bash
cd frontend
npm install
npm run dev
# App running at http://localhost:3000
```

### 4. Login
- URL: http://localhost:3000
- Email: admin@eternaplan.in
- Password: Password@123

---

## Option B: Docker (One Command)

```bash
# Copy and edit environment variables
cp backend/.env.example backend/.env
# Edit backend/.env — set DB_PASSWORD, JWT_SECRET, JWT_REFRESH_SECRET

# Start everything
docker-compose up -d --build

# View logs
docker-compose logs -f

# Access at http://localhost
```

---

## Default Login Credentials

| Role          | Email                        | Password     |
|---------------|------------------------------|--------------|
| Super Admin   | superadmin@eternaplan.in     | Password@123 |
| Administrator | admin@eternaplan.in          | Password@123 |
| Event Manager | manager1@eternaplan.in       | Password@123 |

> ⚠️ Change all passwords immediately after first login!

---

## Project Structure

```
eternaplan/
├── backend/                    ← Node.js + Express REST API
│   ├── src/
│   │   ├── controllers/        ← Business logic
│   │   ├── middleware/         ← Auth, validation, error handling
│   │   ├── routes/             ← API route definitions
│   │   ├── config/             ← Database connection
│   │   └── utils/              ← Helpers, JWT, email, SMS
│   ├── .env.example            ← Copy to .env and configure
│   └── package.json
├── frontend/                   ← React 18 + Tailwind CSS
│   ├── src/
│   │   ├── pages/              ← All 20+ page components
│   │   ├── components/         ← Reusable UI components
│   │   ├── services/           ← API service calls
│   │   ├── store/              ← Zustand auth store
│   │   └── utils/              ← Formatters, helpers
│   └── package.json
├── database/
│   ├── schema.sql              ← Full MySQL schema (25 tables)
│   └── seed.sql                ← Sample data
├── docker/
│   ├── nginx/nginx.conf        ← Nginx reverse proxy config
│   └── mysql/my.cnf            ← MySQL tuning config
├── docs/
│   ├── API.md                  ← API documentation
│   ├── DEPLOYMENT.md           ← Full deployment guide
│   └── postman_collection.json ← Import to Postman
└── docker-compose.yml          ← Full stack orchestration
```

---

## API Base URL
All API endpoints: `http://localhost:5000/api/v1/`

## Postman Collection
Import `docs/postman_collection.json` into Postman to test all 50+ endpoints.
