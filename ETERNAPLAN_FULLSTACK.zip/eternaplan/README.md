# ✦ EternaPlaan™
### Wedding & Event Planning Management System

> **Production-grade SaaS platform** for professional event management companies to orchestrate weddings, receptions, corporate events, vendor networks, guest management, and financial operations from a single centralized command centre.

---

## 📋 Table of Contents
1. [Overview](#overview)
2. [Tech Stack](#tech-stack)
3. [Architecture](#architecture)
4. [Features](#features)
5. [Database Design](#database-design)
6. [Project Structure](#project-structure)
7. [Quick Start](#quick-start)
8. [Environment Configuration](#environment-configuration)
9. [Docker Deployment](#docker-deployment)
10. [API Reference](#api-reference)
11. [SQL Implementation](#sql-implementation)
12. [Security](#security)
13. [Roles & Permissions](#roles--permissions)
14. [Diagrams](#diagrams)

---

## Overview

EternaPlaan is an enterprise-grade, multi-tenant SaaS application purpose-built for the wedding and event management industry. It replaces spreadsheets and disconnected tools with a unified platform covering every phase of event lifecycle — from initial inquiry to post-event analytics.

**Business Value:**
- Reduce event coordination time by 60%
- Eliminate double-bookings with real-time conflict detection
- Centralise vendor contracts, guest lists, and payments
- Generate professional invoices and financial reports instantly
- Track every rupee from budget to profit/loss

---

## Tech Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend** | React 18 + Vite | SPA with component-based UI |
| **Styling** | Tailwind CSS | Utility-first responsive design |
| **State** | Zustand | Lightweight global state |
| **Charts** | Chart.js | Revenue & analytics visualizations |
| **Backend** | Node.js + Express.js | REST API server |
| **Database** | MySQL 8.0 | Primary relational data store |
| **ORM** | Sequelize v6 | SQL abstraction + raw query mix |
| **Auth** | JWT + Refresh Tokens | Stateless secure authentication |
| **Storage** | Cloudinary | Image / document storage |
| **Email** | Nodemailer + SMTP | Transactional email |
| **SMS** | Twilio | OTP and event alerts |
| **Container** | Docker + Docker Compose | Isolated service orchestration |
| **Proxy** | Nginx | SSL termination, rate limiting, reverse proxy |
| **Cache** | Redis | Session + query caching |
| **Logging** | Winston + DailyRotate | Structured log management |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         NGINX (Port 80/443)                     │
│              SSL · Rate Limiting · Reverse Proxy                │
└──────────────────┬──────────────────────┬───────────────────────┘
                   │                      │
         ┌─────────▼──────────┐  ┌───────▼────────────┐
         │  React Frontend    │  │  Express.js API    │
         │  (Port 3000/80)    │  │  (Port 5000)       │
         │  Vite + Tailwind   │  │  MVC Architecture  │
         └────────────────────┘  └───────┬────────────┘
                                         │
                     ┌───────────────────┼───────────────────┐
                     │                   │                   │
             ┌───────▼──────┐   ┌────────▼──────┐  ┌────────▼──────┐
             │  MySQL 8.0   │   │  Redis Cache  │  │  Cloudinary   │
             │  (Port 3306) │   │  (Port 6379)  │  │  File Storage │
             │  25 Tables   │   │  Session/KV   │  │  Images/Docs  │
             └──────────────┘   └───────────────┘  └───────────────┘
```

---

## Features

### 🔐 Multi-Role Authentication
- **5 Roles:** Super Admin, Admin, Event Manager, Vendor, Customer
- JWT Access Token (15 min) + Refresh Token (7 days)
- OTP email verification on registration
- Forgot password with secure reset link
- Account lockout after 5 failed attempts (30 min)
- httpOnly cookie for refresh token security

### 📊 Dashboard & Analytics
- Real-time KPI cards: revenue, events, customers, vendors
- Monthly revenue vs expenses line chart
- Event category donut chart
- Customer growth trend
- Outstanding balances list
- Recent activity feed
- Upcoming events with countdown

### 💐 Event Management
- Full event lifecycle: Inquiry → Planning → Confirmed → In Progress → Completed
- Task management with priority levels and sub-tasks
- Venue booking with real-time conflict detection
- Event timeline and checklist (JSON stored)
- Budget tracking with spend vs allocated
- Auto-generated event codes (EVT-YYYY-XXXX)

### 👥 Customer CRM
- 360° customer profiles with event history
- Lead pipeline: New → Contacted → Qualified → Proposal → Won/Lost
- Priority segmentation (VIP, High, Medium, Low)
- Notes and follow-up reminders
- Customer lifetime value (LTV) function
- Referral source tracking
- Full-text search

### 🏪 Vendor Management
- 14 vendor categories (catering, photography, etc.)
- Package-based pricing with inclusions/exclusions
- Vendor approval workflow
- Rating & review system (auto-updates on insert via trigger)
- Portfolio image gallery
- GST/PAN tracking for compliance

### 📅 Booking System
- Vendor and venue bookings
- Conflict detection for venue time slots
- Approval workflow (pending → approved → confirmed)
- Auto booking code generation
- Price negotiation tracking (quoted vs agreed)

### 💰 Finance Module
- Invoice generation with line items
- Multi-installment payment tracking
- Expense management with categories
- Tax calculation (GST)
- Payment method breakdown (cash, UPI, bank transfer, etc.)
- Revenue vs expense analytics
- Budget variance analysis

### 👤 Guest Management
- Guest list with RSVP tracking
- QR code invitation generation
- Meal preference tracking (veg/non-veg/vegan/jain)
- Table and seating allocation
- Bulk CSV import
- Check-in system with timestamp
- Guest group management (bride/groom side)

### 🔔 Notifications
- In-app notification center
- Email notifications (booking confirmed, payment received, etc.)
- SMS alerts via Twilio
- Scheduled reminders

---

## Database Design

### 25 Tables
```
companies          event_categories    vendor_categories
roles              venues              vendor_packages
users              customers           bookings
audit_logs         customer_notes      vendor_reviews
events             guests              invoice_items
event_tasks        guest_groups        payments
invoices           notifications       expenses
venue_bookings     activity_feed       subscription_plans
```

### 5 Database Views
| View | Purpose |
|---|---|
| `vw_event_summary` | Events with customer, venue, manager |
| `vw_vendor_performance` | Vendor stats with booking aggregations |
| `vw_event_financials` | Revenue, expenses, profit per event |
| `vw_customer_360` | Full customer profile with LTV |
| `vw_revenue_dashboard` | Monthly revenue by payment method |

### 5 Stored Procedures
- `sp_generate_event_code` — Auto-generates EVT-YYYY-XXXX codes
- `sp_create_invoice` — Creates invoice from bookings with tax calc
- `sp_dashboard_analytics` — Returns all dashboard data in one call
- `sp_check_venue_availability` — Conflict detection for venue slots
- `sp_update_event_financials` — Recalculates budget spent/balance

### 2 Functions
- `fn_get_customer_ltv(customer_id)` — Calculates customer lifetime value
- `fn_event_completion_pct(event_id)` — Returns task completion %

### 4 Triggers
- `tr_payment_after_insert` — Auto-updates invoice status on payment
- `tr_booking_after_update` — Updates vendor stats on completion
- `tr_event_after_insert` — Increments customer event count + activity log
- `tr_review_after_insert` — Recalculates vendor rating on review

### Advanced SQL Concepts Used
✅ INNER JOIN / LEFT JOIN / RIGHT JOIN / FULL JOIN simulation  
✅ GROUP BY + HAVING  
✅ Complex aggregations (SUM, COUNT, AVG, MAX)  
✅ Nested subqueries  
✅ Correlated subqueries  
✅ CTEs (WITH clause)  
✅ Window functions (ROW_NUMBER, RANK, DENSE_RANK, NTILE, LAG, SUM OVER, AVG OVER)  
✅ Views  
✅ Stored procedures  
✅ SQL functions  
✅ Triggers  
✅ Transactions (START TRANSACTION / COMMIT / ROLLBACK)  
✅ Cursors  
✅ ACID compliance  
✅ Composite keys  
✅ Foreign key constraints with CASCADE/SET NULL/RESTRICT  
✅ Full-text indexes  
✅ Query optimization with EXPLAIN  
✅ Proper indexing strategy (single + composite)  

---

## Project Structure

```
eternaplan/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/         # Button, Badge, Modal, Toast
│   │   │   ├── layout/         # Sidebar, Topbar, PageWrapper
│   │   │   └── charts/         # RevenueChart, CategoryChart, etc.
│   │   ├── context/            # AuthContext, ThemeContext
│   │   ├── hooks/              # useAuth, useApi, useDashboard
│   │   ├── pages/
│   │   │   ├── auth/           # Login, Register, ForgotPassword
│   │   │   ├── dashboard/      # Dashboard, Calendar
│   │   │   ├── events/         # EventList, EventDetail, CreateEvent
│   │   │   ├── customers/      # CustomerCRM, CustomerDetail
│   │   │   ├── vendors/        # VendorDirectory, VendorDetail
│   │   │   ├── bookings/       # BookingList, CreateBooking
│   │   │   ├── guests/         # GuestList, CheckIn, RSVP
│   │   │   ├── finance/        # Invoices, Payments, Expenses
│   │   │   ├── reports/        # Analytics, MonthlyReport
│   │   │   └── settings/       # CompanySettings, UserManagement
│   │   ├── services/           # api.js, auth.service.js, etc.
│   │   └── utils/              # formatters, validators, constants
│   ├── index.html              # Full standalone demo
│   ├── package.json
│   └── Dockerfile
│
├── backend/
│   └── src/
│       ├── config/
│       │   └── database.js     # Sequelize + MySQL config
│       ├── controllers/
│       │   ├── authController.js
│       │   ├── eventController.js
│       │   ├── dashboardController.js
│       │   └── combinedControllers.js
│       ├── middleware/
│       │   ├── auth.middleware.js
│       │   ├── error.middleware.js
│       │   └── validate.middleware.js
│       ├── routes/
│       │   └── index.js        # All routes consolidated
│       └── utils/
│           ├── AppError.js
│           ├── jwt.js
│           ├── logger.js
│           ├── email.js
│           ├── sms.js
│           └── helpers.js
│
├── database/
│   ├── schema.sql              # Full schema: 25 tables + views + SP + triggers
│   └── seed.sql                # Realistic sample data
│
├── docs/
│   ├── API.md                  # REST API documentation
│   ├── sql_queries.sql         # 20 advanced SQL query examples
│   └── er_diagram.html         # Interactive ER diagram
│
├── docker/
│   ├── nginx/nginx.conf        # Production Nginx config
│   └── mysql/my.cnf            # MySQL tuning config
│
├── docker-compose.yml          # Full stack orchestration
└── README.md
```

---

## Quick Start

### Prerequisites
- Node.js ≥ 18
- MySQL 8.0
- Docker + Docker Compose (for containerised deployment)

### Local Development

```bash
# 1. Clone and navigate
git clone https://github.com/yourorg/eternaplan.git
cd eternaplan

# 2. Setup database
mysql -u root -p < database/schema.sql
mysql -u root -p eternaplan_db < database/seed.sql

# 3. Backend setup
cd backend
cp .env.example .env
# Edit .env with your values
npm install
npm run dev

# 4. Frontend setup (new terminal)
cd frontend
npm install
npm run dev

# App: http://localhost:3000
# API: http://localhost:5000
```

### Demo Login
```
URL:      http://localhost:3000
Email:    admin@eternaplan.in
Password: Password@123
Role:     Administrator
```

---

## Environment Configuration

```env
# Database
DB_HOST=localhost
DB_NAME=eternaplan_db
DB_USER=root
DB_PASSWORD=your_password

# JWT (generate with: openssl rand -hex 32)
JWT_SECRET=your_64_char_secret
JWT_REFRESH_SECRET=your_64_char_refresh_secret

# Cloudinary (https://cloudinary.com)
CLOUDINARY_CLOUD_NAME=your_cloud
CLOUDINARY_API_KEY=your_key
CLOUDINARY_API_SECRET=your_secret

# Email (Gmail App Password)
SMTP_USER=your@gmail.com
SMTP_PASS=your_app_password

# Twilio (https://twilio.com)
TWILIO_ACCOUNT_SID=ACxxxxxxxx
TWILIO_AUTH_TOKEN=your_token
TWILIO_FROM_NUMBER=+1234567890
```

---

## Docker Deployment

```bash
# Production deployment
cp backend/.env.example backend/.env
# Edit all values in backend/.env

docker-compose up -d --build

# View logs
docker-compose logs -f backend

# Database shell
docker-compose exec db mysql -u root -p eternaplan_db

# Scale backend (horizontal)
docker-compose up -d --scale backend=3
```

Services exposed:
- `http://localhost` → Nginx → Frontend + Backend
- `localhost:3307` → MySQL (for admin tools)

---

## API Reference

Full documentation: [`docs/API.md`](docs/API.md)

**Base URL:** `https://api.eternaplan.in/api/v1`

Quick reference:
```
POST   /auth/login
POST   /auth/register
GET    /dashboard/overview
GET    /events            ?page&limit&status&search
POST   /events
GET    /events/:id
PUT    /events/:id
GET    /customers         ?search&lead_status&priority
POST   /customers
GET    /vendors           ?category_id&city&rating_min
GET    /bookings          ?event_id&status
POST   /bookings
GET    /guests            ?event_id&rsvp_status
POST   /guests
PATCH  /guests/rsvp/:code   (public - RSVP link)
GET    /finance/invoices
POST   /finance/payments
GET    /finance/expenses
```

---

## SQL Implementation

Key SQL concepts demonstrated in `docs/sql_queries.sql`:

| # | Concept | Query |
|---|---|---|
| 1 | INNER JOIN | Events + customers + venues |
| 2 | LEFT JOIN | Customers with zero events |
| 3 | RIGHT JOIN | All vendor categories |
| 4 | FULL JOIN | UNION simulation |
| 5 | GROUP BY + HAVING | Vendors with >2 bookings |
| 6 | Complex Aggregation | Monthly revenue + P&L |
| 7 | Nested Subquery | Events above avg budget |
| 8 | Correlated Subquery | Customers above avg events |
| 9 | CTE | Event progress + financials |
| 10 | Window Functions | Running total, MoM growth, RANK |
| 11 | Transaction | Payment + invoice update |
| 12 | Cursor | Batch process overdue invoices |
| 13 | FK Integrity | information_schema query |
| 14 | EXPLAIN | Index usage analysis |
| 15 | Cascade Demo | Delete cascade chain |
| 16 | Index Analysis | Table size + index size |
| 17 | RSVP Analytics | Guest meal breakdown |
| 18 | Vendor Report | Performance + tier classification |
| 19 | Budget Variance | Over/under budget analysis |
| 20 | Multi-table Agg | Full admin financial summary |

---

## Security

| Measure | Implementation |
|---|---|
| Password hashing | bcrypt (12 rounds) |
| JWT | HS256, 15-min access + 7-day refresh |
| Refresh token | httpOnly cookie (no JS access) |
| Account lockout | 5 attempts → 30-min lock |
| Rate limiting | 100 req/15min global, 10/15min auth |
| SQL injection | Parameterized queries (Sequelize) |
| XSS | xss-clean middleware |
| CORS | Strict origin whitelist |
| Helmet | 14 security HTTP headers |
| Email enumeration | Consistent forgot-password response |
| Non-root Docker | UID 1001 nodeuser |
| SSL | TLS 1.2/1.3 only via Nginx |
| CSP | Content-Security-Policy header |

---

## Roles & Permissions

| Permission | Super Admin | Admin | Event Manager | Vendor | Customer |
|---|---|---|---|---|---|
| All system access | ✅ | — | — | — | — |
| Company management | ✅ | ✅ | — | — | — |
| Event CRUD | ✅ | ✅ | ✅ | — | View own |
| Customer CRUD | ✅ | ✅ | ✅ | — | — |
| Vendor CRUD | ✅ | ✅ | View | Own profile | — |
| Booking management | ✅ | ✅ | ✅ | View | View own |
| Invoice & Payments | ✅ | ✅ | View | — | View own |
| Reports | ✅ | ✅ | — | — | — |
| User management | ✅ | ✅ | — | — | — |
| Vendor approval | ✅ | ✅ | — | — | — |

---

## Diagrams

| Diagram | File |
|---|---|
| ER Diagram | `docs/er_diagram.html` |
| API Documentation | `docs/API.md` |
| SQL Queries | `docs/sql_queries.sql` |
| Architecture | See ASCII diagram above |
| Data Flow | `docs/dfd_diagrams.md` |

---

## License

Proprietary — EternaPlaan™ © 2025. All rights reserved.  
Built for commercial deployment. Not for redistribution.

---

<div align="center">
  <strong>✦ ETERNAPLAAN™ — Where Every Moment is Eternal ✦</strong><br>
  <em>Crafted with precision for the wedding & events industry</em>
</div>
