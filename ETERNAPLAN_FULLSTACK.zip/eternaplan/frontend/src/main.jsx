import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="bottom-right"
        toastOptions={{
          duration: 3500,
          style: {
            background: '#141d35',
            color: '#f2ede6',
            border: '1px solid rgba(201,169,110,0.2)',
            borderRadius: '10px',
            fontSize: '13px',
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#030508' } },
          error:   { iconTheme: { primary: '#ef4444', secondary: '#030508' } },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>
);
