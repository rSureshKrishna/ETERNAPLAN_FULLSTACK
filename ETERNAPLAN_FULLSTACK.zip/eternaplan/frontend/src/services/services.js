import api from './api';

// ─── Dashboard ────────────────────────────────────────────────────────────
export const dashboardService = {
  getOverview:      (year)         => api.get(`/dashboard/overview?year=${year || new Date().getFullYear()}`),
  getMonthlyReport: (month, year)  => api.get(`/dashboard/reports/monthly?month=${month}&year=${year}`),
  getCalendar:      (year, month)  => api.get(`/dashboard/calendar?year=${year}&month=${month}`),
};

// ─── Events ───────────────────────────────────────────────────────────────
export const eventService = {
  list:        (params)         => api.get('/events', { params }),
  get:         (id)             => api.get(`/events/${id}`),
  create:      (data)           => api.post('/events', data),
  update:      (id, data)       => api.put(`/events/${id}`, data),
  delete:      (id)             => api.delete(`/events/${id}`),
  upcoming:    ()               => api.get('/events/upcoming'),
  createTask:  (id, data)       => api.post(`/events/${id}/tasks`, data),
  updateTask:  (id, tid, data)  => api.patch(`/events/${id}/tasks/${tid}`, data),
};

// ─── Customers ────────────────────────────────────────────────────────────
export const customerService = {
  list:    (params)    => api.get('/customers', { params }),
  get:     (id)        => api.get(`/customers/${id}`),
  create:  (data)      => api.post('/customers', data),
  update:  (id, data)  => api.put(`/customers/${id}`, data),
  delete:  (id)        => api.delete(`/customers/${id}`),
  addNote: (id, data)  => api.post(`/customers/${id}/notes`, data),
};

// ─── Vendors ──────────────────────────────────────────────────────────────
export const vendorService = {
  list:    (params)    => api.get('/vendors', { params }),
  get:     (id)        => api.get(`/vendors/${id}`),
  create:  (data)      => api.post('/vendors', data),
  update:  (id, data)  => api.put(`/vendors/${id}`, data),
  delete:  (id)        => api.delete(`/vendors/${id}`),
  approve: (id, data)  => api.patch(`/vendors/${id}/approve`, data),
};

// ─── Bookings ─────────────────────────────────────────────────────────────
export const bookingService = {
  list:         (params)    => api.get('/bookings', { params }),
  create:       (data)      => api.post('/bookings', data),
  updateStatus: (id, data)  => api.patch(`/bookings/${id}/status`, data),
};

// ─── Guests ───────────────────────────────────────────────────────────────
export const guestService = {
  list:        (params)     => api.get('/guests', { params }),
  get:         (id)         => api.get(`/guests/${id}`),
  create:      (data)       => api.post('/guests', data),
  update:      (id, data)   => api.patch(`/guests/${id}`, data),
  bulkImport:  (data)       => api.post('/guests/bulk-import', data),
  updateRSVP:  (code, data) => api.patch(`/guests/rsvp/${code}`, data),
  getRSVPInfo: (code)       => api.get(`/guests/rsvp-info/${code}`),
  checkIn:     (id)         => api.patch(`/guests/${id}/check-in`),
};

// ─── Finance ──────────────────────────────────────────────────────────────
export const financeService = {
  invoices:       (params)    => api.get('/finance/invoices', { params }),
  getInvoice:     (id)        => api.get(`/finance/invoices/${id}`),
  createInvoice:  (data)      => api.post('/finance/invoices', data),
  recordPayment:  (data)      => api.post('/finance/payments', data),
  expenses:       (params)    => api.get('/finance/expenses', { params }),
  addExpense:     (data)      => api.post('/finance/expenses', data),
  deleteExpense:  (id)        => api.delete(`/finance/expenses/${id}`),
};

// ─── Meta / Utility ───────────────────────────────────────────────────────
export const metaService = {
  categories:       () => api.get('/meta/categories'),
  vendorCategories: () => api.get('/meta/vendor-categories'),
  venues:           () => api.get('/meta/venues'),
};
