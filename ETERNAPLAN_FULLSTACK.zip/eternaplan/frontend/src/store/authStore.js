import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api from '../services/api';

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: async (email, password) => {
        const { data } = await api.post('/auth/login', { email, password });
        set({ user: data.data.user, token: data.data.token, isAuthenticated: true });
        api.defaults.headers.common['Authorization'] = `Bearer ${data.data.token}`;
        return data.data.user;
      },

      register: async (payload) => {
        const { data } = await api.post('/auth/register', payload);
        return data;
      },

      logout: async () => {
        try { await api.post('/auth/logout'); } catch {}
        set({ user: null, token: null, isAuthenticated: false });
        delete api.defaults.headers.common['Authorization'];
      },

      refreshToken: async () => {
        const { data } = await api.post('/auth/refresh');
        set({ token: data.data.token });
        api.defaults.headers.common['Authorization'] = `Bearer ${data.data.token}`;
        return data.data.token;
      },

      updateUser: (updates) => set((s) => ({ user: { ...s.user, ...updates } })),

      hasRole: (...roles) => roles.includes(get().user?.role),
      isAdmin: () => ['super_admin', 'admin'].includes(get().user?.role),
      isManager: () => ['super_admin', 'admin', 'event_manager'].includes(get().user?.role),
    }),
    {
      name: 'eternaplan-auth',
      partialize: (s) => ({ user: s.user, token: s.token, isAuthenticated: s.isAuthenticated }),
      onRehydrateStorage: () => (state) => {
        if (state?.token) {
          api.defaults.headers.common['Authorization'] = `Bearer ${state.token}`;
        }
      },
    }
  )
);
