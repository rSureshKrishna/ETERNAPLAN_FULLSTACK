import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { guestService } from '../../services/services';
import toast from 'react-hot-toast';

export default function RSVPPage() {
  const { code } = useParams();
  const [guest, setGuest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState('rsvp'); // rsvp | meal | done
  const [rsvp, setRsvp] = useState('');
  const [meal, setMeal] = useState('no_preference');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // Try to load guest info from code
    setLoading(false);
    setGuest(MOCK_GUEST); // use mock when API not available
  }, [code]);

  const submitRSVP = async (status) => {
    setRsvp(status);
    if (status === 'not_attending') {
      setSaving(true);
      try {
        await guestService.updateRSVP(code, { rsvp_status: status });
      } catch {}
      setSaving(false);
      setStep('done');
    } else {
      setStep('meal');
    }
  };

  const submitMeal = async () => {
    setSaving(true);
    try {
      await guestService.updateRSVP(code, { rsvp_status: rsvp, meal_preference: meal });
    } catch {}
    setSaving(false);
    setStep('done');
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{background:'#030508'}}>
      <div className="animate-spin rounded-full border-2 border-transparent" style={{width:32,height:32,borderTopColor:'#c9a96e'}} />
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#030508', position:'relative', overflow:'hidden'}}>
      {/* Background glow */}
      <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse 60% 50% at 50% 40%,rgba(201,169,110,0.06) 0%,transparent 70%)',pointerEvents:'none'}}/>
      <div style={{position:'absolute',inset:0,backgroundImage:'repeating-linear-gradient(0deg,transparent,transparent 59px,rgba(201,169,110,0.02) 60px),repeating-linear-gradient(90deg,transparent,transparent 59px,rgba(201,169,110,0.02) 60px)',pointerEvents:'none'}}/>

      <div className="relative z-10 w-full max-w-md">
        {/* Card */}
        <div className="rounded-2xl overflow-hidden" style={{background:'#0f1628', border:'1px solid rgba(201,169,110,0.2)', boxShadow:'0 32px 80px rgba(0,0,0,0.6)'}}>
          {/* Gold top bar */}
          <div className="h-1" style={{background:'linear-gradient(90deg,#9a7a4a,#c9a96e,#e8c98a,#c9a96e,#9a7a4a)'}} />

          {/* Header */}
          <div className="text-center px-8 pt-8 pb-6" style={{borderBottom:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontSize:32, marginBottom:12}}>💌</div>
            <div style={{fontFamily:'Cinzel,serif', fontSize:22, fontWeight:700, color:'#c9a96e', letterSpacing:2, marginBottom:4}}>
              YOU'RE INVITED
            </div>
            <div style={{fontFamily:'Cormorant Garamond,serif', fontSize:26, fontStyle:'italic', color:'#f2ede6', marginBottom:8}}>
              {guest?.event_name || 'Vikram & Priya Wedding'}
            </div>
            <div style={{fontSize:13, color:'#9ca3af'}}>📅 {guest?.event_date || 'November 15, 2025'}</div>
            <div style={{fontSize:13, color:'#9ca3af', marginTop:4}}>🏛️ {guest?.venue || 'The Grand Palace Banquet, Chennai'}</div>
            {guest && (
              <div className="mt-4 rounded-xl px-4 py-3" style={{background:'rgba(201,169,110,0.06)', border:'1px solid rgba(201,169,110,0.15)'}}>
                <div style={{fontSize:12, color:'#6b6458', marginBottom:2}}>Dear</div>
                <div style={{fontSize:17, fontWeight:600, color:'#f2ede6'}}>{guest.first_name} {guest.last_name}</div>
                {guest.relation && <div style={{fontSize:12, color:'#9ca3af'}}>{guest.relation}</div>}
              </div>
            )}
          </div>

          <div className="px-8 py-6">
            {/* Step: RSVP */}
            {step === 'rsvp' && (
              <>
                <p style={{fontSize:14, color:'#9ca3af', textAlign:'center', marginBottom:24, lineHeight:1.7}}>
                  We joyfully request your presence to celebrate this special occasion. Kindly let us know if you'll be joining us.
                </p>
                <div className="space-y-3">
                  <button
                    onClick={() => submitRSVP('attending')}
                    disabled={saving}
                    className="w-full py-4 rounded-xl font-semibold text-sm transition-all"
                    style={{background:'rgba(16,185,129,0.12)', border:'1px solid rgba(16,185,129,0.3)', color:'#10b981', cursor:'pointer'}}
                    onMouseEnter={e=>e.currentTarget.style.background='rgba(16,185,129,0.2)'}
                    onMouseLeave={e=>e.currentTarget.style.background='rgba(16,185,129,0.12)'}>
                    ✅ Yes, I'll be there!
                  </button>
                  <button
                    onClick={() => submitRSVP('maybe')}
                    disabled={saving}
                    className="w-full py-4 rounded-xl font-semibold text-sm transition-all"
                    style={{background:'rgba(245,158,11,0.12)', border:'1px solid rgba(245,158,11,0.3)', color:'#f59e0b', cursor:'pointer'}}
                    onMouseEnter={e=>e.currentTarget.style.background='rgba(245,158,11,0.2)'}
                    onMouseLeave={e=>e.currentTarget.style.background='rgba(245,158,11,0.12)'}>
                    ❓ Maybe — I'll try to make it
                  </button>
                  <button
                    onClick={() => submitRSVP('not_attending')}
                    disabled={saving}
                    className="w-full py-3 rounded-xl text-sm transition-all"
                    style={{background:'rgba(239,68,68,0.08)', border:'1px solid rgba(239,68,68,0.15)', color:'#6b6458', cursor:'pointer'}}
                    onMouseEnter={e=>e.currentTarget.style.color='#ef4444'}
                    onMouseLeave={e=>e.currentTarget.style.color='#6b6458'}>
                    ❌ Sorry, I can't make it
                  </button>
                </div>
              </>
            )}

            {/* Step: Meal Preference */}
            {step === 'meal' && (
              <>
                <div className="text-center mb-6">
                  <div style={{fontSize:24, marginBottom:8}}>🍽️</div>
                  <div style={{fontFamily:'Cormorant Garamond,serif', fontSize:20, color:'#f2ede6', marginBottom:4}}>Meal Preference</div>
                  <p style={{fontSize:13, color:'#9ca3af'}}>Please let us know your food preference so we can make arrangements.</p>
                </div>
                <div className="space-y-2 mb-6">
                  {[
                    { value:'veg', label:'🥦 Vegetarian', desc:'Pure vegetarian meal' },
                    { value:'non_veg', label:'🍗 Non-Vegetarian', desc:'Includes non-veg dishes' },
                    { value:'vegan', label:'🌱 Vegan', desc:'No animal products' },
                    { value:'jain', label:'🙏 Jain', desc:'Jain-friendly meal' },
                    { value:'no_preference', label:'🍽️ No Preference', desc:'Happy with anything' },
                  ].map(opt => (
                    <div key={opt.value}
                      onClick={() => setMeal(opt.value)}
                      className="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all"
                      style={{
                        background: meal===opt.value ? 'rgba(201,169,110,0.12)' : '#141d35',
                        border: `1px solid ${meal===opt.value ? 'rgba(201,169,110,0.4)' : 'rgba(201,169,110,0.06)'}`,
                      }}>
                      <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                        style={{borderColor: meal===opt.value ? '#c9a96e' : '#3a3028', background: meal===opt.value ? '#c9a96e' : 'transparent'}}>
                        {meal===opt.value && <div className="w-2 h-2 rounded-full" style={{background:'#030508'}} />}
                      </div>
                      <div>
                        <div style={{fontSize:14, fontWeight:500, color:'#f2ede6'}}>{opt.label}</div>
                        <div style={{fontSize:11, color:'#6b6458'}}>{opt.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={submitMeal} disabled={saving}
                  className="w-full py-3.5 rounded-xl font-semibold text-sm transition-all"
                  style={{background:'linear-gradient(135deg,#9a7a4a,#c9a96e)', color:'#030508', border:'none', cursor:'pointer'}}>
                  {saving ? 'Confirming…' : 'Confirm RSVP ✦'}
                </button>
              </>
            )}

            {/* Step: Done */}
            {step === 'done' && (
              <div className="text-center py-4">
                {rsvp === 'attending' || rsvp === 'maybe' ? (
                  <>
                    <div style={{fontSize:48, marginBottom:16}}>🎉</div>
                    <div style={{fontFamily:'Cormorant Garamond,serif', fontSize:24, color:'#c9a96e', marginBottom:8}}>Thank You!</div>
                    <p style={{fontSize:14, color:'#9ca3af', lineHeight:1.7, marginBottom:16}}>
                      {rsvp === 'attending'
                        ? `Wonderful! We've confirmed your attendance. A reminder with venue details will be sent closer to the date.`
                        : `Thank you for your response. We'll keep you updated and hope you can make it!`}
                    </p>
                    <div className="rounded-xl p-4" style={{background:'rgba(201,169,110,0.06)', border:'1px solid rgba(201,169,110,0.15)'}}>
                      <div style={{fontSize:12, color:'#6b6458', marginBottom:4}}>Your meal preference:</div>
                      <div style={{fontSize:14, color:'#f2ede6', fontWeight:500}}>{meal.replace(/_/g,' ')}</div>
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{fontSize:48, marginBottom:16}}>💌</div>
                    <div style={{fontFamily:'Cormorant Garamond,serif', fontSize:22, color:'#f2ede6', marginBottom:8}}>We'll Miss You</div>
                    <p style={{fontSize:14, color:'#9ca3af', lineHeight:1.7}}>
                      Thank you for letting us know. We're sorry you won't be able to join us, but we'll celebrate with you in spirit!
                    </p>
                  </>
                )}
                <div className="mt-6 pt-6" style={{borderTop:'1px solid rgba(201,169,110,0.08)'}}>
                  <div style={{fontFamily:'Cinzel,serif', fontSize:12, color:'#6b6458', letterSpacing:1.5}}>ETERNAPLAAN™</div>
                  <div style={{fontSize:11, color:'#3a3028', marginTop:2}}>Event Management Excellence</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Invitation code */}
        <div className="text-center mt-4">
          <div style={{fontSize:11, color:'#3a3028', letterSpacing:1}}>Invitation Code: {code || 'INV-1-ABC123'}</div>
        </div>
      </div>
    </div>
  );
}

const MOCK_GUEST = {
  first_name: 'Rajesh',
  last_name: 'Patel',
  relation: 'Father of Groom',
  event_name: 'Vikram & Priya Wedding',
  event_date: 'November 15, 2025 · 9:00 AM',
  venue: 'The Grand Palace Banquet, Chennai',
};
