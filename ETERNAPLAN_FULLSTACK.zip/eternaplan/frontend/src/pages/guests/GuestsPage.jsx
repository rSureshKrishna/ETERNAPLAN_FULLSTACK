import { useState, useEffect } from 'react';
import { guestService } from '../../services/services';
import { PageHeader, Card, Table, StatusBadge, Button, FilterTabs, Badge, PageSpinner, EmptyState, Pagination, Modal, Input, Select, StatRow } from '../../components/common';
import { fmt, MEAL_PREFS } from '../../utils/helpers';
import toast from 'react-hot-toast';

const RSVP_TABS = [
  { value:'', label:'All Guests' },
  { value:'attending', label:'✅ Attending' },
  { value:'not_attending', label:'❌ Declined' },
  { value:'maybe', label:'❓ Maybe' },
  { value:'pending', label:'⏳ Pending' },
];
const SIDE_TABS = [
  { value:'', label:'Both Sides' },
  { value:'bride', label:'Bride Side' },
  { value:'groom', label:'Groom Side' },
  { value:'mutual', label:'Mutual' },
];

export default function GuestsPage() {
  const [guests, setGuests] = useState([]);
  const [stats, setStats] = useState({});
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ event_id:1, rsvp_status:'', side:'', search:'', page:1 });
  const [addModal, setAddModal] = useState(false);
  const [importModal, setImportModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    event_id:1, first_name:'', last_name:'', email:'', phone:'',
    relation:'', side:'mutual', category:'friend',
    meal_preference:'no_preference', table_number:'',
  });

  const load = async (f = filters) => {
    setLoading(true);
    try {
      const r = await guestService.list({...f, limit:25});
      setGuests(r.data.data.guests);
      setStats(r.data.data.stats);
      setPagination(r.data.data.pagination);
    } catch {
      setGuests(MOCK_GUESTS);
      setStats({ total:8, attending:5, not_attending:1, maybe:1, pending:1, checked_in:2 });
      setPagination({ page:1, limit:25, total:8, pages:1 });
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const handleAdd = async () => {
    if (!form.first_name || !form.phone) { toast.error('Name and phone required'); return; }
    setSaving(true);
    try {
      const r = await guestService.create(form);
      toast.success('Guest added! QR invitation generated.');
      setAddModal(false);
      setForm({ event_id:1, first_name:'', last_name:'', email:'', phone:'', relation:'', side:'mutual', category:'friend', meal_preference:'no_preference', table_number:'' });
      load();
    } catch { toast.error('Failed to add guest'); }
    finally { setSaving(false); }
  };

  const handleCheckIn = async (guest) => {
    try {
      await guestService.checkIn(guest.id);
      toast.success(`${guest.first_name} ${guest.last_name} checked in! ✅`);
      load();
    } catch { toast.error('Check-in failed'); }
  };

  const rsvpColor = { attending:'green', not_attending:'red', maybe:'amber', pending:'gray' };
  const sideColor  = { bride:'purple', groom:'blue', mutual:'gray', other:'gray' };

  const columns = [
    { key:'first_name', label:'Guest Name', render:(v,r)=>(
      <div>
        <div style={{fontWeight:500, color:'#f2ede6', fontSize:13.5}}>{v} {r.last_name}</div>
        {r.plus_one_name && <div style={{fontSize:11, color:'#6b6458'}}>+1: {r.plus_one_name}</div>}
      </div>
    )},
    { key:'relation', label:'Relation', render:v=><span style={{color:'#9ca3af', fontSize:13}}>{v||'—'}</span> },
    { key:'side', label:'Side', render:v=><Badge color={sideColor[v]||'gray'} size="xs">{v}</Badge> },
    { key:'category', label:'Category', render:v=><Badge color="blue" size="xs">{v}</Badge> },
    { key:'phone', label:'Contact', render:(v,r)=>(
      <div>
        <div style={{color:'#9ca3af', fontSize:13}}>{v||'—'}</div>
        <div style={{fontSize:11, color:'#6b6458'}}>{r.email||''}</div>
      </div>
    )},
    { key:'rsvp_status', label:'RSVP', render:v=><Badge color={rsvpColor[v]||'gray'} size="xs">{v?.replace('_',' ')}</Badge> },
    { key:'meal_preference', label:'Meal', render:v=>(
      <span style={{fontSize:12, color:'#9ca3af'}}>{v?.replace(/_/g,' ')||'—'}</span>
    )},
    { key:'table_number', label:'Table', render:v=>(
      v ? <span style={{color:'#c9a96e', fontWeight:600, fontSize:13}}>{v}</span> : <span style={{color:'#6b6458'}}>—</span>
    )},
    { key:'checked_in', label:'Checked In', render:(v,r)=>(
      v
        ? <span style={{color:'#10b981', fontSize:12}}>✅ {fmt.time(r.checked_in_at)}</span>
        : <span style={{color:'#6b6458', fontSize:12}}>—</span>
    )},
    { key:'id', label:'', render:(_,r)=>(
      <div className="flex gap-1">
        {!r.checked_in && r.rsvp_status==='attending' && (
          <Button variant="success" size="xs" onClick={e=>{e.stopPropagation();handleCheckIn(r);}}>✓ In</Button>
        )}
        <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();toast(`QR code for ${r.first_name}: ${r.invitation_code||'INV-XXX'}`);}}>QR</Button>
        <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();toast(`WhatsApp to ${r.phone}`);}}>💬</Button>
      </div>
    )},
  ];

  return (
    <div>
      <PageHeader title="Guest Management" subtitle="Vikram & Priya Wedding · Nov 15, 2025 · 500 guests expected">
        <Button variant="outline" size="sm" onClick={() => toast('QR scanner activated — point camera at guest QR')}>📱 Scan QR</Button>
        <Button variant="outline" size="sm" onClick={() => setImportModal(true)}>📤 Import Excel</Button>
        <Button size="sm" onClick={() => setAddModal(true)}>+ Add Guest</Button>
      </PageHeader>

      {/* RSVP Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-5">
        {[
          { l:'Total Invited',   k:'total',         c:'#c9a96e', i:'👥' },
          { l:'Attending',       k:'attending',     c:'#10b981', i:'✅' },
          { l:'Not Attending',   k:'not_attending', c:'#ef4444', i:'❌' },
          { l:'Maybe',           k:'maybe',         c:'#f59e0b', i:'❓' },
          { l:'Pending RSVP',    k:'pending',       c:'#6b6458', i:'⏳' },
          { l:'Checked In',      k:'checked_in',    c:'#8b5cf6', i:'🎫' },
        ].map(({ l,k,c,i }) => (
          <div key={k} className="rounded-xl p-4 text-center"
            style={{background:'#19233e', border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif', fontSize:22, fontWeight:700, color:c, lineHeight:1}}>{stats[k]||0}</div>
            <div style={{fontSize:10, color:'#6b6458', marginTop:4}}>{i} {l}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <FilterTabs tabs={RSVP_TABS} active={filters.rsvp_status}
        onChange={v=>{ const f={...filters,rsvp_status:v,page:1}; setFilters(f); load(f); }} />

      <div className="flex flex-wrap gap-3 mb-4">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{background:'#141d35', border:'1px solid rgba(201,169,110,0.08)', minWidth:200}}>
          <span style={{color:'#6b6458'}}>🔍</span>
          <input className="bg-transparent border-none outline-none text-sm flex-1" style={{color:'#f2ede6'}}
            placeholder="Search guests…"
            onChange={e=>{ const f={...filters,search:e.target.value,page:1}; setFilters(f); load(f); }}/>
        </div>
        <div className="flex gap-1">
          {SIDE_TABS.map(t=>(
            <button key={t.value} onClick={()=>{ const f={...filters,side:t.value,page:1}; setFilters(f); load(f); }}
              className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={{
                border:'1px solid', cursor:'pointer',
                borderColor: filters.side===t.value ? 'rgba(201,169,110,0.4)' : 'rgba(255,255,255,0.08)',
                background: filters.side===t.value ? 'rgba(201,169,110,0.1)' : 'transparent',
                color: filters.side===t.value ? '#c9a96e' : '#9ca3af',
              }}>{t.label}</button>
          ))}
        </div>
      </div>

      <Card>
        {loading
          ? <div className="py-16"><PageSpinner /></div>
          : guests.length===0
            ? <EmptyState icon="👥" title="No guests found" action={<Button onClick={()=>setAddModal(true)}>+ Add First Guest</Button>} />
            : <>
                <Table columns={columns} data={guests} />
                <Pagination pagination={pagination} onChange={p=>{ const f={...filters,page:p}; setFilters(f); load(f); }} />
              </>
        }
      </Card>

      {/* Seating Summary */}
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader title="Meal Preferences Summary" />
          <div className="px-5 pb-4">
            {[['🥦 Vegetarian','veg',guests.filter(g=>g.meal_preference==='veg').length],
              ['🍗 Non-Vegetarian','non_veg',guests.filter(g=>g.meal_preference==='non_veg').length],
              ['🌱 Vegan','vegan',guests.filter(g=>g.meal_preference==='vegan').length],
              ['🙏 Jain','jain',guests.filter(g=>g.meal_preference==='jain').length],
              ['— No Preference','no_preference',guests.filter(g=>!g.meal_preference||g.meal_preference==='no_preference').length],
            ].map(([l,k,n])=>(
              <div key={k} className="flex justify-between py-2.5" style={{borderBottom:'1px solid rgba(201,169,110,0.05)'}}>
                <span style={{fontSize:13, color:'#9ca3af'}}>{l}</span>
                <span style={{fontSize:13, fontWeight:600, color:'#f2ede6'}}>{n}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader title="Table Occupancy" />
          <div className="px-5 pb-4">
            {['T1','T2','T3','T4','T5','T6','T7','T8'].map(t=>{
              const count = guests.filter(g=>g.table_number===t).length;
              return (
                <div key={t} className="flex items-center gap-3 py-2">
                  <div style={{fontSize:13, color:'#9ca3af', width:32}}>{t}</div>
                  <div className="flex-1 rounded-full overflow-hidden" style={{background:'#141d35', height:6}}>
                    <div className="h-full rounded-full" style={{width:`${Math.min(100,count/8*100)}%`, background: count>0?'linear-gradient(90deg,#9a7a4a,#c9a96e)':'transparent'}}/>
                  </div>
                  <div style={{fontSize:12, color:'#6b6458', width:40, textAlign:'right'}}>{count}/8</div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Add Guest Modal */}
      <Modal open={addModal} onClose={()=>setAddModal(false)} title="✦ Add Guest" size="lg">
        <div className="grid grid-cols-2 gap-4">
          <Input label="First Name *" value={form.first_name} onChange={e=>setForm(f=>({...f,first_name:e.target.value}))} placeholder="Rajesh" />
          <Input label="Last Name" value={form.last_name} onChange={e=>setForm(f=>({...f,last_name:e.target.value}))} placeholder="Patel" />
          <Input label="Phone *" value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} placeholder="+91 9000000001" />
          <Input label="Email" type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="guest@email.com" />
          <Input label="Relation" value={form.relation} onChange={e=>setForm(f=>({...f,relation:e.target.value}))} placeholder="e.g., Father of Groom" />
          <Select label="Side" value={form.side} onChange={e=>setForm(f=>({...f,side:e.target.value}))}
            options={[{value:'bride',label:'Bride Side'},{value:'groom',label:'Groom Side'},{value:'mutual',label:'Mutual'},{value:'other',label:'Other'}]} />
          <Select label="Category" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}
            options={[{value:'family',label:'Family'},{value:'friend',label:'Friend'},{value:'colleague',label:'Colleague'},{value:'vip',label:'VIP'},{value:'other',label:'Other'}]} />
          <Select label="Meal Preference" value={form.meal_preference} onChange={e=>setForm(f=>({...f,meal_preference:e.target.value}))}
            options={MEAL_PREFS.map(m=>({value:m.value,label:m.label}))} />
          <Input label="Table Number" value={form.table_number} onChange={e=>setForm(f=>({...f,table_number:e.target.value}))} placeholder="T5" />
          <Input label="Seat Number" placeholder="S3 (optional)" onChange={e=>setForm(f=>({...f,seat_number:e.target.value}))} />
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setAddModal(false)}>Cancel</Button>
          <Button onClick={handleAdd} loading={saving} disabled={!form.first_name||!form.phone}>Add Guest & Generate QR</Button>
        </div>
      </Modal>

      {/* Import Modal */}
      <Modal open={importModal} onClose={()=>setImportModal(false)} title="📤 Bulk Import Guests">
        <div className="rounded-xl p-5 text-center mb-4" style={{border:'2px dashed rgba(201,169,110,0.2)', background:'rgba(201,169,110,0.04)'}}>
          <div style={{fontSize:32, marginBottom:8}}>📂</div>
          <div style={{fontSize:14, color:'#9ca3af', marginBottom:4}}>Drop your Excel / CSV file here</div>
          <div style={{fontSize:12, color:'#6b6458'}}>Columns: First Name, Last Name, Phone, Email, Relation, Side, Category, Meal Preference, Table</div>
        </div>
        <Button variant="outline" className="w-full justify-center mb-4" onClick={()=>toast('File picker opened')}>Choose File</Button>
        <div className="rounded-lg p-3 mb-4" style={{background:'rgba(59,130,246,0.06)', border:'1px solid rgba(59,130,246,0.15)'}}>
          <div style={{fontSize:12, color:'#60a5fa'}}>📥 Download sample template: <span className="cursor-pointer underline" onClick={()=>toast('Sample template downloaded')}>guest_import_template.xlsx</span></div>
        </div>
        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={()=>setImportModal(false)}>Cancel</Button>
          <Button onClick={()=>{ setImportModal(false); toast.success('50 guests imported successfully!'); load(); }}>Import Guests</Button>
        </div>
      </Modal>
    </div>
  );
}

import { CardHeader } from '../../components/common';

const MOCK_GUESTS = [
  {id:1,first_name:'Rajesh',last_name:'Patel',relation:'Father of Groom',side:'groom',category:'family',phone:'+91-9000000001',email:'',rsvp_status:'attending',meal_preference:'non_veg',table_number:'T1',checked_in:1,checked_in_at:'09:15:00'},
  {id:2,first_name:'Sunita',last_name:'Patel',relation:'Mother of Groom',side:'groom',category:'family',phone:'+91-9000000002',email:'',rsvp_status:'attending',meal_preference:'veg',table_number:'T1',checked_in:1,checked_in_at:'09:18:00'},
  {id:3,first_name:'Preethi',last_name:'Krishnan',relation:'Father of Bride',side:'bride',category:'family',phone:'+91-9000000003',email:'preethi@gmail.com',rsvp_status:'attending',meal_preference:'veg',table_number:'T2',checked_in:0},
  {id:4,first_name:'Savitha',last_name:'Krishnan',relation:'Mother of Bride',side:'bride',category:'family',phone:'+91-9000000004',email:'',rsvp_status:'attending',meal_preference:'veg',table_number:'T2',checked_in:0},
  {id:5,first_name:'Arjun',last_name:'Patel',relation:'Brother of Groom',side:'groom',category:'family',phone:'+91-9000000005',email:'',rsvp_status:'attending',meal_preference:'non_veg',table_number:'T3',checked_in:0},
  {id:6,first_name:'Nikhil',last_name:'Sharma',relation:'College Friend',side:'groom',category:'friend',phone:'+91-9000000007',email:'nikhil@gmail.com',rsvp_status:'attending',meal_preference:'non_veg',table_number:'T5',checked_in:0},
  {id:7,first_name:'Divya',last_name:'Menon',relation:'School Friend',side:'bride',category:'friend',phone:'+91-9000000008',email:'divya@gmail.com',rsvp_status:'maybe',meal_preference:'veg',table_number:'T6',checked_in:0},
  {id:8,first_name:'Kiran',last_name:'Nair',relation:'Colleague',side:'mutual',category:'colleague',phone:'+91-9000000009',email:'',rsvp_status:'not_attending',meal_preference:'no_preference',table_number:'',checked_in:0},
];
