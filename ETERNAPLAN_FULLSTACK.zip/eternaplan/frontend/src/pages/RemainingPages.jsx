// ── TASKS PAGE ──────────────────────────────────────────────────────────────
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageHeader, Card, CardHeader, Table, StatusBadge, Button, FilterTabs, Badge, Modal, Input, Select, StatRow, Progress, EmptyState } from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

export function TasksPage() {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState(MOCK_TASKS);
  const [filter, setFilter] = useState('');
  const [addModal, setAddModal] = useState(false);
  const [form, setForm] = useState({ title:'', category:'', priority:'medium', due_date:'' });

  const completeTask = (id) => {
    setTasks(ts => ts.map(t => t.id===id ? {...t, status:'completed'} : t));
    toast.success('Task marked complete ✅');
  };

  const filtered = filter==='critical' ? tasks.filter(t=>t.priority==='critical') : filter ? tasks.filter(t=>t.status===filter) : tasks;
  const TABS = [{value:'',label:'All Tasks'},{value:'critical',label:'⚡ Critical'},{value:'pending',label:'Pending'},{value:'in_progress',label:'In Progress'},{value:'completed',label:'Completed'}];

  return (
    <div>
      <PageHeader title="Tasks & Checklists" subtitle="Track event preparation tasks across all events">
        <Button size="sm" onClick={()=>setAddModal(true)}>+ Add Task</Button>
      </PageHeader>

      {/* Summary */}
      <div className="grid grid-cols-5 gap-3 mb-5">
        {[['Total',tasks.length,'#f2ede6'],['Critical',tasks.filter(t=>t.priority==='critical'&&t.status!=='completed').length,'#ef4444'],['Pending',tasks.filter(t=>t.status==='pending').length,'#f59e0b'],['In Progress',tasks.filter(t=>t.status==='in_progress').length,'#3b82f6'],['Completed',tasks.filter(t=>t.status==='completed').length,'#10b981']].map(([l,n,c])=>(
          <div key={l} className="rounded-xl p-4 text-center" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif',fontSize:24,fontWeight:700,color:c,lineHeight:1}}>{n}</div>
            <div style={{fontSize:11,color:'#6b6458',marginTop:4}}>{l}</div>
          </div>
        ))}
      </div>

      {/* Overall progress */}
      <div className="rounded-xl p-4 mb-5" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
        <div className="flex justify-between mb-2"><span style={{fontSize:13,color:'#9ca3af'}}>Overall Completion</span><span style={{fontSize:13,fontWeight:600,color:'#c9a96e'}}>{Math.round(tasks.filter(t=>t.status==='completed').length/Math.max(tasks.length,1)*100)}%</span></div>
        <Progress value={Math.round(tasks.filter(t=>t.status==='completed').length/Math.max(tasks.length,1)*100)} height={8}/>
      </div>

      <FilterTabs tabs={TABS} active={filter} onChange={setFilter}/>

      <Card>
        <Table
          columns={[
            {key:'title',label:'Task',render:(v,r)=>(
              <div className="flex items-center gap-3">
                <div onClick={e=>{e.stopPropagation();completeTask(r.id);}} className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 cursor-pointer"
                  style={{border:`2px solid ${r.status==='completed'?'#c9a96e':'#3a3028'}`,background:r.status==='completed'?'#c9a96e':'transparent',color:'#030508',fontSize:10}}>
                  {r.status==='completed'&&'✓'}
                </div>
                <div>
                  <div style={{fontSize:13,fontWeight:500,color:r.status==='completed'?'#6b6458':'#f2ede6',textDecoration:r.status==='completed'?'line-through':'none'}}>{v}</div>
                  <div style={{fontSize:11,color:'#6b6458'}}>{r.event_name}</div>
                </div>
              </div>
            )},
            {key:'category',label:'Category',render:v=><Badge color="blue" size="xs">{v}</Badge>},
            {key:'priority',label:'Priority',render:v=><Badge color={{critical:'red',high:'amber',medium:'blue',low:'gray'}[v]||'gray'} size="xs">{v}</Badge>},
            {key:'status',label:'Status',render:v=><StatusBadge type="task" value={v}/>},
            {key:'assigned_to_name',label:'Assigned To',render:v=><span style={{fontSize:12,color:'#9ca3af'}}>{v||'Unassigned'}</span>},
            {key:'due_date',label:'Due Date',render:v=>(
              <span style={{fontSize:12,color:new Date(v)<new Date()?'#ef4444':'#9ca3af'}}>{fmt.date(v)}</span>
            )},
            {key:'id',label:'',render:(_,r)=>(
              <div className="flex gap-1">
                {r.status!=='completed'&&<Button variant="success" size="xs" onClick={e=>{e.stopPropagation();completeTask(r.id);}}>✓</Button>}
                <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();navigate(`/events/${r.event_id}`);}}>Event</Button>
              </div>
            )},
          ]}
          data={filtered}
          emptyMessage="No tasks match the current filter."
        />
      </Card>

      <Modal open={addModal} onClose={()=>setAddModal(false)} title="✦ Add Task">
        <Input label="Task Title *" value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="e.g., Confirm catering menu"/>
        <div className="grid grid-cols-2 gap-4">
          <Select label="Category" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}
            options={[{value:'Catering',label:'Catering'},{value:'Decoration',label:'Decoration'},{value:'Photography',label:'Photography'},{value:'Guest Mgmt',label:'Guest Management'},{value:'Venue',label:'Venue'},{value:'Beauty',label:'Beauty'},{value:'Finance',label:'Finance'},{value:'Other',label:'Other'}]}/>
          <Select label="Priority" value={form.priority} onChange={e=>setForm(f=>({...f,priority:e.target.value}))}
            options={[{value:'low',label:'Low'},{value:'medium',label:'Medium'},{value:'high',label:'High'},{value:'critical',label:'🔴 Critical'}]}/>
          <Input label="Due Date" type="date" value={form.due_date} onChange={e=>setForm(f=>({...f,due_date:e.target.value}))}/>
          <Input label="Due Time" type="time"/>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setAddModal(false)}>Cancel</Button>
          <Button disabled={!form.title} onClick={()=>{
            setTasks(ts=>[...ts,{id:Date.now(),title:form.title,category:form.category,priority:form.priority,status:'pending',due_date:form.due_date,event_name:'General',assigned_to_name:'You'}]);
            setAddModal(false); toast.success('Task added!');
          }}>Add Task</Button>
        </div>
      </Modal>
    </div>
  );
}

// ── INVOICES PAGE ────────────────────────────────────────────────────────────
export function InvoicesPage() {
  const navigate = useNavigate();
  const STABS = [{value:'',label:'All'},{value:'partial',label:'Partial'},{value:'paid',label:'Paid'},{value:'overdue',label:'Overdue'},{value:'draft',label:'Draft'}];
  const [filter, setFilter] = useState('');
  const filtered = filter ? MOCK_INVOICES.filter(i=>i.status===filter) : MOCK_INVOICES;

  return (
    <div>
      <PageHeader title="Invoices" subtitle="Billing and payment management">
        <Button size="sm" onClick={()=>toast('Create invoice form')}>+ New Invoice</Button>
      </PageHeader>
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[['Total Billed','₹7,19,800','#f2ede6'],['Received','₹5,76,260','#10b981'],['Outstanding','₹1,43,540','#f59e0b'],['Overdue','₹0','#6b6458']].map(([l,v,c])=>(
          <div key={l} className="rounded-xl p-5" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:c,lineHeight:1.2}}>{v}</div>
            <div style={{fontSize:11,color:'#6b6458',marginTop:4}}>{l}</div>
          </div>
        ))}
      </div>
      <FilterTabs tabs={STABS} active={filter} onChange={setFilter}/>
      <Card>
        <Table
          columns={[
            {key:'invoice_number',label:'Invoice #',render:v=><span style={{color:'#c9a96e',fontWeight:700}}>{v}</span>},
            {key:'event_name',label:'Event',render:(v,r)=><div><div style={{color:'#f2ede6'}}>{v}</div><div style={{fontSize:11,color:'#6b6458'}}>{r.event_code}</div></div>},
            {key:'customer_name',label:'Customer'},
            {key:'invoice_date',label:'Issued',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
            {key:'due_date',label:'Due',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
            {key:'grand_total',label:'Total',render:v=><span style={{color:'#f2ede6',fontWeight:500}}>{fmt.currency(v)}</span>},
            {key:'amount_paid',label:'Paid',render:v=><span style={{color:'#10b981'}}>{fmt.currency(v)}</span>},
            {key:'balance_due',label:'Balance',render:v=><span style={{color:v>0?'#f59e0b':'#10b981',fontWeight:600}}>{fmt.currency(v)}</span>},
            {key:'status',label:'Status',render:v=><StatusBadge type="invoice" value={v}/>},
            {key:'id',label:'',render:(_,r)=>(
              <div className="flex gap-1">
                <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();navigate(`/finance/invoices/${r.id}`);}}>View</Button>
                <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();toast('PDF downloading…');}}>📄</Button>
              </div>
            )},
          ]}
          data={filtered}
          onRowClick={r=>navigate(`/finance/invoices/${r.id}`)}
        />
      </Card>
    </div>
  );
}

// ── PAYMENTS PAGE ───────────────────────────────────────────────────────────
export function PaymentsPage() {
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({amount:'',payment_method:'upi',payment_type:'installment',payment_ref:''});
  return (
    <div>
      <PageHeader title="Payments" subtitle="Record and track all payment transactions">
        <Button size="sm" onClick={()=>setModal(true)}>+ Record Payment</Button>
      </PageHeader>
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[['Total Received','₹5,76,260','#10b981'],['This Month','₹1,50,000','#c9a96e'],['Bank Transfer','₹3,75,000','#9ca3af'],['UPI Payments','₹1,76,260','#9ca3af']].map(([l,v,c])=>(
          <div key={l} className="rounded-xl p-5" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:c}}>{v}</div>
            <div style={{fontSize:11,color:'#6b6458',marginTop:4}}>{l}</div>
          </div>
        ))}
      </div>
      <Card>
        <CardHeader title="Transaction History"/>
        <Table
          columns={[
            {key:'payment_code',label:'Code',render:v=><span style={{color:'#c9a96e',fontWeight:700}}>{v}</span>},
            {key:'customer',label:'Customer',render:v=><span style={{color:'#f2ede6'}}>{v}</span>},
            {key:'invoice',label:'Invoice'},
            {key:'amount',label:'Amount',render:v=><span style={{color:'#10b981',fontWeight:600}}>{fmt.currency(v)}</span>},
            {key:'method',label:'Method',render:v=><Badge color="blue" size="xs">{v.replace('_',' ')}</Badge>},
            {key:'date',label:'Date',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
            {key:'type',label:'Type',render:v=><Badge color="purple" size="xs">{v}</Badge>},
            {key:'status',label:'Status',render:v=><Badge color="green" size="xs">{v}</Badge>},
          ]}
          data={MOCK_PAYMENTS}
        />
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title="💳 Record Payment">
        <div className="grid grid-cols-2 gap-4">
          <Input label="Amount (₹) *" type="number" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))} placeholder="50000" className="col-span-2"/>
          <Select label="Payment Method" value={form.payment_method} onChange={e=>setForm(f=>({...f,payment_method:e.target.value}))}
            options={[{value:'upi',label:'UPI'},{value:'bank_transfer',label:'Bank Transfer'},{value:'cash',label:'Cash'},{value:'cheque',label:'Cheque'},{value:'card',label:'Card'}]}/>
          <Select label="Payment Type" value={form.payment_type} onChange={e=>setForm(f=>({...f,payment_type:e.target.value}))}
            options={[{value:'advance',label:'Advance'},{value:'installment',label:'Installment'},{value:'full',label:'Full Payment'}]}/>
          <Input label="Reference / UTR" placeholder="Optional" className="col-span-2" value={form.payment_ref} onChange={e=>setForm(f=>({...f,payment_ref:e.target.value}))}/>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setModal(false)}>Cancel</Button>
          <Button disabled={!form.amount} onClick={()=>{setModal(false);toast.success('Payment recorded ✓');}}>Record Payment</Button>
        </div>
      </Modal>
    </div>
  );
}

// ── EXPENSES PAGE ───────────────────────────────────────────────────────────
export function ExpensesPage() {
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({category:'',description:'',amount:'',expense_date:'',payment_method:'cash'});
  const [expenses, setExpenses] = useState(MOCK_EXPENSES);

  const addExpense = () => {
    if (!form.description || !form.amount) { toast.error('Fill required fields'); return; }
    setExpenses(ex=>[{id:Date.now(),expense_date:form.expense_date||new Date().toISOString().split('T')[0],category:form.category||'Other',description:form.description,event_name:'General',amount:+form.amount,payment_method:form.payment_method,status:'pending'},...ex]);
    setModal(false); toast.success('Expense recorded!');
  };

  return (
    <div>
      <PageHeader title="Expenses" subtitle="Track and manage all operational expenses">
        <Button size="sm" onClick={()=>setModal(true)}>+ Add Expense</Button>
      </PageHeader>
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[['Total Expenses',fmt.currency(expenses.reduce((s,e)=>s+e.amount,0)),'#f2ede6'],['This Month',fmt.currency(expenses.filter(e=>new Date(e.expense_date).getMonth()===new Date().getMonth()).reduce((s,e)=>s+e.amount,0)),'#f59e0b'],['Approved',fmt.currency(expenses.filter(e=>e.status==='paid').reduce((s,e)=>s+e.amount,0)),'#10b981'],['Pending',fmt.currency(expenses.filter(e=>e.status==='pending').reduce((s,e)=>s+e.amount,0)),'#6b6458']].map(([l,v,c])=>(
          <div key={l} className="rounded-xl p-5" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif',fontSize:20,fontWeight:700,color:c}}>{v}</div>
            <div style={{fontSize:11,color:'#6b6458',marginTop:4}}>{l}</div>
          </div>
        ))}
      </div>
      <Card>
        <Table
          columns={[
            {key:'expense_date',label:'Date',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
            {key:'category',label:'Category',render:v=><Badge color="blue" size="xs">{v}</Badge>},
            {key:'description',label:'Description',render:v=><span style={{color:'#f2ede6'}}>{v}</span>},
            {key:'event_name',label:'Event',render:v=><span style={{fontSize:12,color:'#6b6458'}}>{v}</span>},
            {key:'amount',label:'Amount',render:v=><span style={{color:'#ef4444',fontWeight:600}}>{fmt.currency(v)}</span>},
            {key:'payment_method',label:'Method',render:v=><span style={{fontSize:12,color:'#9ca3af'}}>{v.replace('_',' ')}</span>},
            {key:'status',label:'Status',render:v=><Badge color={v==='paid'?'green':'amber'} size="xs">{v}</Badge>},
            {key:'id',label:'',render:(_,r)=><Button variant="outline" size="xs" onClick={()=>toast('Expense details')}>View</Button>},
          ]}
          data={expenses}
        />
      </Card>
      <Modal open={modal} onClose={()=>setModal(false)} title="✦ Add Expense">
        <div className="grid grid-cols-2 gap-4">
          <Select label="Category" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}
            options={[{value:'',label:'Select…'},{value:'Catering',label:'Catering'},{value:'Decoration',label:'Decoration'},{value:'Venue',label:'Venue'},{value:'Photography',label:'Photography'},{value:'DJ & Music',label:'DJ & Music'},{value:'Marketing',label:'Marketing'},{value:'Transport',label:'Transport'},{value:'Other',label:'Other'}]}/>
          <Input label="Amount (₹) *" type="number" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))} placeholder="25000"/>
          <Input label="Description *" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} placeholder="Stage backdrop" className="col-span-2"/>
          <Input label="Date" type="date" value={form.expense_date} onChange={e=>setForm(f=>({...f,expense_date:e.target.value}))}/>
          <Select label="Payment Method" value={form.payment_method} onChange={e=>setForm(f=>({...f,payment_method:e.target.value}))}
            options={[{value:'cash',label:'Cash'},{value:'upi',label:'UPI'},{value:'bank_transfer',label:'Bank Transfer'},{value:'cheque',label:'Cheque'}]}/>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setModal(false)}>Cancel</Button>
          <Button onClick={addExpense} disabled={!form.description||!form.amount}>Save Expense</Button>
        </div>
      </Modal>
    </div>
  );
}

// ── REPORTS PAGE ─────────────────────────────────────────────────────────────
export function ReportsPage() {
  const navigate = useNavigate();
  return (
    <div>
      <PageHeader title="Analytics & Reports" subtitle="Business intelligence and performance metrics">
        <select className="input-dark" style={{width:100,padding:'8px 12px'}}><option>2025</option><option>2024</option></select>
        <Button variant="outline" size="sm" onClick={()=>toast('Generating PDF report…')}>📥 Export PDF</Button>
      </PageHeader>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[['📈','Annual Revenue','₹14.2L','23% YoY','#c9a96e','#9a7a4a'],['💰','Net Profit','₹2.8L','18% margin','#10b981','#065f46'],['💐','Avg Event Value','₹2.37L','12% vs last year','#8b5cf6','#4c1d95'],['🎯','Lead Conversion','67%','8 pts improvement','#f59e0b','#78350f']].map(([i,l,v,t,c1,c2])=>(
          <div key={l} className="rounded-xl p-5 relative overflow-hidden" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
            <div className="absolute top-0 left-0 right-0 h-0.5" style={{background:`linear-gradient(90deg,${c2},${c1})`}}/>
            <div className="text-2xl mb-3">{i}</div>
            <div style={{fontFamily:'Cinzel,serif',fontSize:24,fontWeight:700,color:'#f2ede6',lineHeight:1}}>{v}</div>
            <div style={{fontSize:11,color:'#6b6458',marginTop:4}}>{l}</div>
            <div style={{fontSize:12,color:c1,marginTop:6}}>▲ {t}</div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
        <Card>
          <CardHeader title="Top Revenue Events"/>
          <div className="px-5 pb-3">
            {[['Meera & Arjun Grand Wedding','₹18,00,000','Wedding',1],['Vikram & Priya Wedding','₹12,00,000','Wedding',2],['TechSol Corporate Gala','₹8,00,000','Corporate',3],['Ananya Reception','₹6,00,000','Reception',4],["Kavya's Birthday 30th",'₹2,50,000','Birthday',5]].map(([n,r,c,i])=>(
              <div key={n} className="flex items-center justify-between py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                <span className="text-sm flex items-center gap-2" style={{color:'#9ca3af'}}>
                  <span style={{color:'#c9a96e',fontWeight:700,fontFamily:'Cinzel,serif'}}>{i}</span>
                  <span style={{maxWidth:180,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{n}</span>
                </span>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Badge color="blue" size="xs">{c}</Badge>
                  <span style={{fontSize:13,fontWeight:600,color:'#f2ede6'}}>{r}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader title="Vendor Performance"/>
          <div className="px-5 pb-3">
            {[['Star Catering Services','Catering',4.8,89],['Dream Decor Studio','Decoration',4.9,201],['Pixel Perfect Photography','Photography',4.9,156],['Glamour House Makeup','Makeup',4.7,320],['Petal Paradise Flowers','Florals',4.8,134]].map(([n,c,r,e])=>(
              <div key={n} className="flex items-center justify-between py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                <div><div style={{fontSize:13,color:'#f2ede6'}}>{n}</div><div style={{fontSize:11,color:'#6b6458'}}>{c} · {e} events</div></div>
                <div style={{fontSize:13,fontWeight:600,color:'#f59e0b'}}>★ {r}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[['Customer Growth','7 total customers · 3 new this month · 67% conversion rate'],['Revenue Sources','Bank Transfer 52% · UPI 24% · Cash 15% · Cheque 9%'],['Budget Utilization','Events avg 68% budget utilized · ₹1.4L outstanding balances']].map(([t,d])=>(
          <Card key={t} className="p-5">
            <div style={{fontFamily:'Cormorant Garamond,serif',fontSize:16,fontWeight:600,color:'#f2ede6',marginBottom:8}}>{t}</div>
            <div style={{fontSize:13,color:'#6b6458',lineHeight:1.65}}>{d}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ── SETTINGS PAGE ─────────────────────────────────────────────────────────────
export function SettingsPage() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState({email:true,sms:true,whatsapp:false,reminders:true});
  const handleLogout = () => { localStorage.removeItem('eternaplan-auth'); navigate('/login'); toast.success('Signed out'); };

  return (
    <div>
      <PageHeader title="Settings" subtitle="Company profile and account preferences">
        <Button onClick={()=>toast.success('Settings saved ✓')}>Save Changes</Button>
      </PageHeader>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="space-y-5">
          <Card>
            <CardHeader title="Company Profile"/>
            <div className="p-5">
              <div className="flex items-center gap-4 mb-5 p-4 rounded-xl" style={{background:'#141d35'}}>
                <div className="flex items-center justify-center rounded-full font-bold flex-shrink-0"
                  style={{width:52,height:52,background:'linear-gradient(135deg,#9a7a4a,#c9a96e)',color:'#030508',fontFamily:'Cinzel,serif',fontSize:18}}>EP</div>
                <div className="flex-1">
                  <div style={{fontSize:15,fontWeight:600,color:'#f2ede6'}}>EternaPlaan Events Pvt Ltd</div>
                  <div style={{fontSize:12,color:'#6b6458'}}>Enterprise Plan · admin@eternaplan.in</div>
                </div>
                <Button variant="outline" size="xs" onClick={()=>toast('Upload photo')}>Upload Logo</Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Company Name" defaultValue="EternaPlaan Events Pvt Ltd"/>
                <Input label="Phone" defaultValue="+91-9876543210"/>
                <Input label="Email" defaultValue="admin@eternaplan.in"/>
                <Input label="Website" defaultValue="www.eternaplan.in"/>
                <Textarea label="Address" defaultValue="42 MG Road, Nungambakkam, Chennai - 600 034, Tamil Nadu" className="col-span-2"/>
              </div>
            </div>
          </Card>
          <Card>
            <CardHeader title="Team Members"/>
            <div className="px-5 pb-3">
              {[['Arjun Sharma','Super Admin','active'],['Priya Nair','Administrator','active'],['Rahul Menon','Event Manager','active'],['Sneha Krishnan','Event Manager','active']].map(([n,r,s])=>(
                <div key={n} className="flex items-center gap-3 py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                  <div className="flex items-center justify-center rounded-full text-xs font-bold flex-shrink-0"
                    style={{width:32,height:32,background:'linear-gradient(135deg,#9a7a4a,#c9a96e)',color:'#030508',fontFamily:'Cinzel,serif'}}>
                    {n.split(' ').map(p=>p[0]).join('')}
                  </div>
                  <div className="flex-1"><div style={{fontSize:13,color:'#f2ede6'}}>{n}</div><div style={{fontSize:11,color:'#6b6458'}}>{r}</div></div>
                  <Badge color="green" size="xs">{s}</Badge>
                </div>
              ))}
              <Button variant="outline" size="sm" className="mt-3 w-full justify-center" onClick={()=>toast('Invite team member')}>+ Invite Team Member</Button>
            </div>
          </Card>
        </div>
        <div className="space-y-5">
          <Card>
            <CardHeader title="Subscription Plan"/>
            <div className="p-5">
              <div className="rounded-xl p-5 mb-4" style={{background:'linear-gradient(135deg,rgba(201,169,110,0.08),rgba(139,92,246,0.06))',border:'1px solid rgba(201,169,110,0.2)'}}>
                <div style={{fontFamily:'Cinzel,serif',fontSize:18,color:'#c9a96e',marginBottom:4}}>Enterprise Plan</div>
                <div style={{fontSize:12,color:'#6b6458',marginBottom:12}}>Unlimited events · 100GB storage · All features enabled</div>
                <div style={{display:'flex',gap:16}}>
                  {[['Events','Unlimited'],['Team','Unlimited'],['Storage','100 GB'],['Vendors','Unlimited']].map(([l,v])=>(
                    <div key={l} className="text-center">
                      <div style={{fontSize:13,fontWeight:600,color:'#c9a96e'}}>{v}</div>
                      <div style={{fontSize:10,color:'#6b6458'}}>{l}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{fontSize:12,color:'#6b6458',marginBottom:12}}>Subscription expires: December 31, 2025</div>
              <Button variant="outline" className="w-full justify-center">Manage Subscription</Button>
            </div>
          </Card>
          <Card>
            <CardHeader title="Notifications"/>
            <div className="px-5 pb-3">
              {[['Email Notifications','Receive booking & payment emails','email'],['SMS Alerts','Urgent event SMS alerts','sms'],['Payment Reminders','Auto-remind customers of dues','reminders'],['WhatsApp Integration','Send invitations via WhatsApp','whatsapp']].map(([t,d,k])=>(
                <div key={k} className="flex items-center justify-between py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                  <div><div style={{fontSize:13,color:'#f2ede6'}}>{t}</div><div style={{fontSize:11,color:'#6b6458'}}>{d}</div></div>
                  <div onClick={()=>{setNotifications(n=>({...n,[k]:!n[k]}));toast(notifications[k]?`${t} disabled`:`${t} enabled`);}}
                    className="cursor-pointer transition-all relative"
                    style={{width:40,height:22,background:notifications[k]?'#c9a96e':'#141d35',borderRadius:11,border:'1px solid rgba(201,169,110,0.2)',transition:'background 0.3s'}}>
                    <div style={{position:'absolute',top:2,width:16,height:16,background:notifications[k]?'#030508':'#6b6458',borderRadius:'50%',transition:'all 0.3s',[notifications[k]?'right':'left']:2}}/>
                  </div>
                </div>
              ))}
            </div>
          </Card>
          <Card>
            <CardHeader title="Security"/>
            <div className="p-5 space-y-2">
              <Button variant="outline" className="w-full justify-start" onClick={()=>toast('Password change email sent')}>🔒 Change Password</Button>
              <Button variant="outline" className="w-full justify-start" onClick={()=>toast('2FA setup wizard')}>🛡️ Enable 2FA</Button>
              <Button variant="outline" className="w-full justify-start" onClick={()=>toast('Audit log downloaded')}>📋 Download Audit Log</Button>
              <div className="h-px my-2" style={{background:'rgba(201,169,110,0.08)'}}/>
              <Button variant="danger" className="w-full justify-start" onClick={handleLogout}>🚪 Sign Out of All Devices</Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ── NOT FOUND PAGE ──────────────────────────────────────────────────────────
export function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center" style={{background:'#030508'}}>
      <div className="text-center px-4">
        <div style={{fontFamily:'Cinzel,serif',fontSize:120,fontWeight:700,color:'rgba(201,169,110,0.1)',lineHeight:1,marginBottom:24}}>404</div>
        <div style={{fontFamily:'Cinzel,serif',fontSize:28,fontWeight:700,color:'#c9a96e',marginBottom:8}}>Page Not Found</div>
        <p style={{fontSize:15,color:'#6b6458',marginBottom:32,maxWidth:400,margin:'0 auto 32px'}}>
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="flex gap-3 justify-center">
          <Button onClick={()=>navigate(-1)} variant="outline">← Go Back</Button>
          <Button onClick={()=>navigate('/dashboard')}>Go to Dashboard</Button>
        </div>
      </div>
    </div>
  );
}

// ── FORGOT PASSWORD PAGE ─────────────────────────────────────────────────────
export function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const handle = async (e) => {
    e.preventDefault(); if (!email) return;
    setLoading(true);
    try {
      const api = (await import('../../services/api')).default;
      await api.post('/auth/forgot-password', { email });
    } catch {}
    setSent(true); setLoading(false);
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#030508'}}>
      <div className="w-full max-w-sm rounded-2xl p-10" style={{background:'#0f1628',border:'1px solid rgba(201,169,110,0.2)',boxShadow:'0 32px 80px rgba(0,0,0,0.6)'}}>
        <div className="text-center mb-8">
          <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:'#c9a96e',letterSpacing:2}}>ETERNAPLAAN</div>
          <div style={{fontSize:13,color:'#6b6458',marginTop:4}}>Reset your password</div>
        </div>
        {sent ? (
          <div className="text-center">
            <div style={{fontSize:48,marginBottom:12}}>📧</div>
            <div style={{fontSize:15,fontWeight:600,color:'#f2ede6',marginBottom:8}}>Check Your Inbox</div>
            <p style={{fontSize:13,color:'#6b6458',marginBottom:20}}>We've sent a password reset link to <strong style={{color:'#9ca3af'}}>{email}</strong></p>
            <Button variant="outline" className="w-full justify-center" onClick={()=>navigate('/login')}>← Back to Login</Button>
          </div>
        ) : (
          <form onSubmit={handle}>
            <p style={{fontSize:13,color:'#6b6458',marginBottom:20,lineHeight:1.65}}>Enter your email address and we'll send you a link to reset your password.</p>
            <Input label="Email Address" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.in" className="mb-5"/>
            <button type="submit" disabled={loading||!email} className="btn-gold w-full justify-center py-3 text-sm" style={{width:'100%',display:'flex',justifyContent:'center'}}>
              {loading ? '⟳ Sending…' : 'Send Reset Link'}
            </button>
            <div className="text-center mt-4">
              <span className="text-xs cursor-pointer" style={{color:'#c9a96e'}} onClick={()=>navigate('/login')}>← Back to Login</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

// ── RESET PASSWORD PAGE ──────────────────────────────────────────────────────
export function ResetPasswordPage() {
  const navigate = useNavigate();
  const token = new URLSearchParams(window.location.search).get('token') || 'demo-token';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const handle = async (e) => {
    e.preventDefault();
    if (password !== confirm) { toast.error('Passwords do not match'); return; }
    if (password.length < 8) { toast.error('Password must be at least 8 characters'); return; }
    setLoading(true);
    try {
      const api = (await import('../../services/api')).default;
      await api.post('/auth/reset-password', { token, password });
    } catch {}
    setDone(true); setLoading(false);
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#030508'}}>
      <div className="w-full max-w-sm rounded-2xl p-10" style={{background:'#0f1628',border:'1px solid rgba(201,169,110,0.2)',boxShadow:'0 32px 80px rgba(0,0,0,0.6)'}}>
        <div className="text-center mb-8">
          <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:'#c9a96e',letterSpacing:2}}>ETERNAPLAAN</div>
          <div style={{fontSize:13,color:'#6b6458',marginTop:4}}>Set new password</div>
        </div>
        {done ? (
          <div className="text-center">
            <div style={{fontSize:48,marginBottom:12}}>✅</div>
            <div style={{fontSize:15,fontWeight:600,color:'#f2ede6',marginBottom:8}}>Password Updated!</div>
            <p style={{fontSize:13,color:'#6b6458',marginBottom:20}}>Your password has been reset successfully.</p>
            <Button className="w-full justify-center" onClick={()=>navigate('/login')}>Sign In Now →</Button>
          </div>
        ) : (
          <form onSubmit={handle}>
            <Input label="New Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Min 8 characters" className="mb-4"/>
            <Input label="Confirm Password" type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="Confirm new password" className="mb-5"/>
            <button type="submit" disabled={loading||!password||!confirm} className="btn-gold w-full" style={{width:'100%',display:'flex',justifyContent:'center',padding:'12px'}}>
              {loading ? '⟳ Saving…' : 'Reset Password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

import { Textarea } from '../../components/common';

// ── MOCK DATA ───────────────────────────────────────────────────────────────
const MOCK_TASKS = [
  {id:1,title:'Confirm catering menu',event_name:'Vikram & Priya Wedding',event_id:1,category:'Catering',priority:'high',status:'completed',due_date:'2025-09-15',assigned_to_name:'Rahul Menon'},
  {id:2,title:'Finalize decoration theme',event_name:'Vikram & Priya Wedding',event_id:1,category:'Decoration',priority:'high',status:'completed',due_date:'2025-09-20',assigned_to_name:'Sneha Krishnan'},
  {id:3,title:'Send invitations to 500 guests',event_name:'Vikram & Priya Wedding',event_id:1,category:'Guest Mgmt',priority:'critical',status:'in_progress',due_date:'2025-10-01',assigned_to_name:'Rahul Menon'},
  {id:4,title:'Arrange mehendi artist',event_name:'Vikram & Priya Wedding',event_id:1,category:'Beauty',priority:'medium',status:'pending',due_date:'2025-10-15',assigned_to_name:null},
  {id:5,title:'Coordinate DJ & Music setup',event_name:'Vikram & Priya Wedding',event_id:1,category:'Entertainment',priority:'medium',status:'pending',due_date:'2025-10-20',assigned_to_name:null},
  {id:6,title:'Book baraat vehicles',event_name:'Vikram & Priya Wedding',event_id:1,category:'Transport',priority:'high',status:'pending',due_date:'2025-10-25',assigned_to_name:'Sneha Krishnan'},
  {id:7,title:'Venue setup walkthrough',event_name:'Ananya & Kiran Reception',event_id:2,category:'Venue',priority:'high',status:'pending',due_date:'2025-11-20',assigned_to_name:'Rahul Menon'},
  {id:8,title:'Book bridal makeup artist',event_name:'Meera & Arjun Wedding',event_id:3,category:'Beauty',priority:'high',status:'pending',due_date:'2025-12-01',assigned_to_name:null},
  {id:9,title:'Confirm 2-day catering package',event_name:'Meera & Arjun Wedding',event_id:3,category:'Catering',priority:'critical',status:'pending',due_date:'2025-12-10',assigned_to_name:'Sneha Krishnan'},
];

const MOCK_INVOICES = [
  {id:1,invoice_number:'INV-2025-00001',event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',customer_name:'Vikram Patel',invoice_date:'2025-09-01',due_date:'2025-09-15',grand_total:434240,amount_paid:300000,balance_due:134240,status:'partial'},
  {id:2,invoice_number:'INV-2025-00002',event_name:"Kavya Birthday 30th",event_code:'EVT-2025-0004',customer_name:'Kavya Nambiar',invoice_date:'2025-09-15',due_date:'2025-09-30',grand_total:126260,amount_paid:126260,balance_due:0,status:'paid'},
  {id:3,invoice_number:'INV-2025-00003',event_name:'Ananya & Kiran Reception',event_code:'EVT-2025-0002',customer_name:'Ananya Krishnan',invoice_date:'2025-10-01',due_date:'2025-10-15',grand_total:159300,amount_paid:150000,balance_due:9300,status:'partial'},
];

const MOCK_PAYMENTS = [
  {id:1,payment_code:'PAY-2025-0001',customer:'Vikram Patel',invoice:'INV-2025-00001',amount:300000,method:'bank_transfer',date:'2025-09-01',type:'advance',status:'completed'},
  {id:2,payment_code:'PAY-2025-0002',customer:'Kavya Nambiar',invoice:'INV-2025-00002',amount:126260,method:'upi',date:'2025-09-15',type:'full',status:'completed'},
  {id:3,payment_code:'PAY-2025-0003',customer:'Ananya Krishnan',invoice:'INV-2025-00003',amount:150000,method:'upi',date:'2025-10-01',type:'advance',status:'completed'},
];

const MOCK_EXPENSES = [
  {id:1,expense_date:'2025-10-18',category:'Decoration',description:'Floral arrangements - Birthday',event_name:"Kavya's Birthday",amount:15000,payment_method:'cash',status:'paid'},
  {id:2,expense_date:'2025-10-15',category:'Catering',description:'Advance to Star Catering',event_name:"Kavya's Birthday",amount:50000,payment_method:'bank_transfer',status:'paid'},
  {id:3,expense_date:'2025-09-05',category:'Venue',description:'Grand Palace advance payment',event_name:'Vikram & Priya Wedding',amount:75000,payment_method:'bank_transfer',status:'paid'},
  {id:4,expense_date:'2025-09-10',category:'Marketing',description:'Digital invitation design',event_name:'Vikram & Priya Wedding',amount:5000,payment_method:'upi',status:'paid'},
  {id:5,expense_date:'2025-10-16',category:'DJ & Music',description:'Beat Masters DJ advance',event_name:"Kavya's Birthday",amount:10000,payment_method:'upi',status:'paid'},
];
