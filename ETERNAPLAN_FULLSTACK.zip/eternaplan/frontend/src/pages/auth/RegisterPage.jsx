// RegisterPage.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import toast from 'react-hot-toast';

export function RegisterPage() {
  const [form, setForm] = useState({ first_name:'',last_name:'',email:'',phone:'',password:'',company_name:'' });
  const [loading, setLoading] = useState(false);
  const { register } = useAuthStore();
  const navigate = useNavigate();
  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(form);
      toast.success('Account created! Please verify your email.');
      navigate('/login');
    } catch(err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#030508'}}>
      <div className="w-full max-w-md rounded-2xl p-10"
        style={{background:'#0f1628',border:'1px solid rgba(201,169,110,0.2)',boxShadow:'0 32px 80px rgba(0,0,0,0.6)'}}>
        <div className="text-center mb-8">
          <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:'#c9a96e',letterSpacing:3}}>ETERNAPLAAN</div>
          <div style={{fontSize:13,color:'#9ca3af',marginTop:4}}>Create your company account</div>
        </div>
        <form onSubmit={handle}>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div><label className="block mb-1.5 text-xs font-medium" style={{color:'#6b6458'}}>First Name</label>
              <input className="input-dark" value={form.first_name} onChange={e=>set('first_name',e.target.value)} required placeholder="Priya"/></div>
            <div><label className="block mb-1.5 text-xs font-medium" style={{color:'#6b6458'}}>Last Name</label>
              <input className="input-dark" value={form.last_name} onChange={e=>set('last_name',e.target.value)} required placeholder="Nair"/></div>
          </div>
          <div className="mb-3"><label className="block mb-1.5 text-xs font-medium" style={{color:'#6b6458'}}>Company Name</label>
            <input className="input-dark" value={form.company_name} onChange={e=>set('company_name',e.target.value)} required placeholder="My Events Co"/></div>
          <div className="mb-3"><label className="block mb-1.5 text-xs font-medium" style={{color:'#6b6458'}}>Email</label>
            <input className="input-dark" type="email" value={form.email} onChange={e=>set('email',e.target.value)} required placeholder="admin@company.in"/></div>
          <div className="mb-3"><label className="block mb-1.5 text-xs font-medium" style={{color:'#6b6458'}}>Phone</label>
            <input className="input-dark" value={form.phone} onChange={e=>set('phone',e.target.value)} required placeholder="+91 9876543210"/></div>
          <div className="mb-6"><label className="block mb-1.5 text-xs font-medium" style={{color:'#6b6458'}}>Password</label>
            <input className="input-dark" type="password" value={form.password} onChange={e=>set('password',e.target.value)} required placeholder="Min 8 characters"/></div>
          <button type="submit" disabled={loading} className="btn-gold w-full justify-center py-3 text-sm">
            {loading ? '⟳ Creating…' : 'Create Account ✦'}
          </button>
        </form>
        <p className="text-center mt-4 text-xs" style={{color:'#6b6458'}}>
          Already have an account? <Link to="/login" style={{color:'#c9a96e'}}>Sign in</Link>
        </p>
      </div>
    </div>
  );
}
export default RegisterPage;

// ForgotPasswordPage
export function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const handle = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const api = (await import('../../services/api')).default;
      await api.post('/auth/forgot-password', { email });
      setSent(true);
    } catch {} finally { setLoading(false); }
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#030508'}}>
      <div className="w-full max-w-sm rounded-2xl p-10" style={{background:'#0f1628',border:'1px solid rgba(201,169,110,0.2)'}}>
        <h1 style={{fontFamily:'Cinzel,serif',fontSize:20,color:'#c9a96e',marginBottom:4}}>Reset Password</h1>
        <p className="text-sm mb-6" style={{color:'#6b6458'}}>Enter your email to receive a reset link.</p>
        {sent ? (
          <div className="text-center py-4">
            <div className="text-4xl mb-3">📧</div>
            <p className="text-sm" style={{color:'#9ca3af'}}>Check your inbox for the reset link.</p>
            <Link to="/login" className="block mt-4 text-sm" style={{color:'#c9a96e'}}>← Back to login</Link>
          </div>
        ) : (
          <form onSubmit={handle}>
            <input className="input-dark mb-4" type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="your@email.com"/>
            <button type="submit" disabled={loading} className="btn-gold w-full justify-center py-2.5 text-sm">
              {loading ? '⟳ Sending…' : 'Send Reset Link'}
            </button>
            <Link to="/login" className="block text-center mt-3 text-xs" style={{color:'#6b6458'}}>← Back to login</Link>
          </form>
        )}
      </div>
    </div>
  );
}

// ResetPasswordPage
export function ResetPasswordPage() {
  const [password, setPassword] = useState('');
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const token = new URLSearchParams(window.location.search).get('token');
  const handle = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const api = (await import('../../services/api')).default;
      await api.post('/auth/reset-password', { token, password });
      setDone(true);
    } catch {} finally { setLoading(false); }
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#030508'}}>
      <div className="w-full max-w-sm rounded-2xl p-10" style={{background:'#0f1628',border:'1px solid rgba(201,169,110,0.2)'}}>
        <h1 style={{fontFamily:'Cinzel,serif',fontSize:20,color:'#c9a96e',marginBottom:6}}>Set New Password</h1>
        {done ? (
          <div className="text-center py-4">
            <div className="text-4xl mb-3">✅</div>
            <p className="text-sm" style={{color:'#9ca3af'}}>Password reset successfully.</p>
            <Link to="/login" className="block mt-4 text-sm" style={{color:'#c9a96e'}}>Sign in now →</Link>
          </div>
        ) : (
          <form onSubmit={handle}>
            <input className="input-dark mb-4" type="password" value={password} onChange={e=>setPassword(e.target.value)} required placeholder="New password" minLength={8}/>
            <button type="submit" disabled={loading} className="btn-gold w-full justify-center py-2.5 text-sm">
              {loading ? '⟳ Saving…' : 'Reset Password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
