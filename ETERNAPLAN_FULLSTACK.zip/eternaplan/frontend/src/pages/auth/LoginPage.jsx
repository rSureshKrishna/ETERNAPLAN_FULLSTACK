import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [form, setForm] = useState({ email: 'admin@eternaplan.in', password: 'Password@123' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back! ✦');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{ background: '#030508' }}>
      {/* Glow */}
      <div className="absolute w-[600px] h-[600px] rounded-full pointer-events-none animate-breathe"
        style={{ background: 'radial-gradient(circle,rgba(201,169,110,0.06) 0%,transparent 70%)',
          top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }} />
      {/* Grid */}
      <div className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: 'repeating-linear-gradient(0deg,transparent,transparent 59px,rgba(201,169,110,0.03) 60px),repeating-linear-gradient(90deg,transparent,transparent 59px,rgba(201,169,110,0.03) 60px)' }} />

      <div className="relative z-10 w-full max-w-[420px] mx-4">
        <div className="rounded-2xl p-12"
          style={{ background: '#0f1628', border: '1px solid rgba(201,169,110,0.2)',
            boxShadow: '0 32px 80px rgba(0,0,0,0.6)' }}>
          {/* Logo */}
          <div className="text-center mb-9">
            <div className="mx-auto mb-4 flex items-center justify-center rounded-full"
              style={{ width: 68, height: 68, border: '2px solid #c9a96e',
                background: 'rgba(201,169,110,0.08)', fontSize: 28 }}>
              💍
            </div>
            <div style={{ fontFamily: 'Cinzel,serif', fontSize: 24, fontWeight: 700,
              color: '#c9a96e', letterSpacing: 3 }}>ETERNAPLAAN</div>
            <div style={{ fontSize: 12, color: '#6b6458', letterSpacing: 2,
              textTransform: 'uppercase', marginTop: 4 }}>Event Management</div>
          </div>

          <form onSubmit={handle}>
            <div className="mb-4">
              <label className="block mb-1.5 text-xs font-medium" style={{ color: '#6b6458' }}>Email Address</label>
              <input className="input-dark" type="email" value={form.email}
                onChange={(e) => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="you@company.com" required />
            </div>
            <div className="mb-2">
              <label className="block mb-1.5 text-xs font-medium" style={{ color: '#6b6458' }}>Password</label>
              <input className="input-dark" type="password" value={form.password}
                onChange={(e) => setForm(f => ({ ...f, password: e.target.value }))}
                placeholder="••••••••" required />
            </div>
            <div className="text-right mb-6">
              <Link to="/forgot-password" className="text-xs" style={{ color: '#c9a96e' }}>Forgot password?</Link>
            </div>
            <button type="submit" disabled={loading}
              className="btn-gold w-full justify-center py-3 text-sm">
              {loading ? '⟳ Signing in…' : 'Sign In to Dashboard'}
            </button>
          </form>

          <p className="text-center mt-5 text-xs" style={{ color: '#6b6458' }}>
            Don't have an account?{' '}
            <Link to="/register" style={{ color: '#c9a96e' }}>Register your company</Link>
          </p>
          <p className="text-center mt-3 text-xs" style={{ color: '#3a3028' }}>
            Demo: admin@eternaplan.in / Password@123
          </p>
        </div>
      </div>
    </div>
  );
}
