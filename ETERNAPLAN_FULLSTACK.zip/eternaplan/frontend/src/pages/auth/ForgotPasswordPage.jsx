export { ForgotPasswordPage as default } from '../RemainingPages';
