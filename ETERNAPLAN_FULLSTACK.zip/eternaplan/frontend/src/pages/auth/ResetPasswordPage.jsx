export { ResetPasswordPage as default } from '../RemainingPages';
