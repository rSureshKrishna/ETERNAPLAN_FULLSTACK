export { InvoicesPage as default } from '../RemainingPages';
