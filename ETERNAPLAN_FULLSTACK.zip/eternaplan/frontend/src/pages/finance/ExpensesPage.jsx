export { ExpensesPage as default } from '../RemainingPages';
