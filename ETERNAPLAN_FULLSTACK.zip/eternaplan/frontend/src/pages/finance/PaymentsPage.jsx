export { PaymentsPage as default } from '../RemainingPages';
