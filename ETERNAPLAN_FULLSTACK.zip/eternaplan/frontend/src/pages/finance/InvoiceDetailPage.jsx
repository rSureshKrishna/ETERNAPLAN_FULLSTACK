import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { financeService } from '../../services/services';
import { PageHeader, Card, CardHeader, StatusBadge, Button, Badge, StatRow, Modal, Input, Select, EmptyState, PageSpinner } from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

export default function InvoiceDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [payModal, setPayModal] = useState(false);
  const [payForm, setPayForm] = useState({ amount:'', payment_method:'upi', payment_ref:'', payment_type:'installment' });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const r = await financeService.getInvoice(id); setData(r.data.data); }
    catch { setData(MOCK); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [id]);

  const recordPayment = async () => {
    setSaving(true);
    try {
      await financeService.recordPayment({ invoice_id: +id, customer_id: data.invoice.customer_id, ...payForm, amount: +payForm.amount, payment_date: new Date().toISOString().split('T')[0] });
      toast.success('Payment recorded!');
      setPayModal(false);
      load();
    } catch { toast.error('Failed'); }
    finally { setSaving(false); }
  };

  if (loading) return <PageSpinner />;
  if (!data) return <EmptyState icon="📄" title="Invoice not found" />;

  const { invoice, items = [], payments = [] } = data;
  const paid = payments.reduce((s,p) => s + (p.status === 'completed' ? +p.amount : 0), 0);
  const statusColor = { draft:'gray', sent:'blue', viewed:'purple', partial:'amber', paid:'green', overdue:'red', cancelled:'gray' };

  return (
    <div>
      <PageHeader title={invoice.invoice_number} subtitle={`${invoice.event_name} · ${invoice.customer_name}`}>
        <Button variant="outline" size="sm" onClick={() => navigate('/finance/invoices')}>← Invoices</Button>
        <Button variant="outline" size="sm" onClick={() => toast('Sending invoice email…')}>📧 Send</Button>
        <Button variant="outline" size="sm" onClick={() => toast('Generating PDF…')}>📄 PDF</Button>
        {invoice.balance_due > 0 && <Button size="sm" onClick={() => setPayModal(true)}>💳 Record Payment</Button>}
      </PageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left – Invoice */}
        <div className="lg:col-span-2 space-y-5">
          {/* Invoice Header */}
          <div className="rounded-2xl overflow-hidden" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.12)'}}>
            {/* Top bar */}
            <div className="p-6" style={{background:'linear-gradient(135deg,rgba(201,169,110,0.08),rgba(139,92,246,0.04))'}}>
              <div className="flex justify-between items-start">
                <div>
                  <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:'#c9a96e',letterSpacing:2}}>ETERNAPLAAN</div>
                  <div style={{fontSize:11,color:'#6b6458',letterSpacing:1.5,marginTop:2}}>WEDDING & EVENT MANAGEMENT</div>
                  <div className="mt-3" style={{fontSize:12,color:'#9ca3af'}}>
                    42 MG Road, Nungambakkam<br/>Chennai - 600 034, Tamil Nadu<br/>admin@eternaplan.in
                  </div>
                </div>
                <div className="text-right">
                  <div style={{fontSize:28,fontWeight:700,color:'#f2ede6',fontFamily:'Cinzel,serif'}}>{invoice.invoice_number}</div>
                  <div className="mt-2"><StatusBadge type="invoice" value={invoice.status} /></div>
                  <div className="mt-2" style={{fontSize:12,color:'#6b6458'}}>
                    <div>Issued: {fmt.date(invoice.invoice_date)}</div>
                    <div>Due: {fmt.date(invoice.due_date)}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bill To */}
            <div className="px-6 py-4" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
              <div style={{fontSize:10,fontWeight:700,color:'#6b6458',letterSpacing:2,marginBottom:6}}>BILL TO</div>
              <div style={{fontSize:15,fontWeight:600,color:'#f2ede6'}}>{invoice.customer_name}</div>
              <div style={{fontSize:13,color:'#9ca3af'}}>{invoice.phone}</div>
              <div style={{fontSize:13,color:'#9ca3af'}}>{invoice.email}</div>
              <div className="mt-2" style={{fontSize:13,color:'#9ca3af'}}>
                <span style={{color:'#c9a96e',fontWeight:500}}>Event: </span>{invoice.event_name} · {fmt.date(invoice.event_date)}
              </div>
            </div>

            {/* Line Items */}
            <div className="px-6 py-4">
              <table className="w-full border-collapse">
                <thead>
                  <tr style={{borderBottom:'1px solid rgba(201,169,110,0.08)'}}>
                    {['Description','Category','Qty','Unit Price','Tax','Amount'].map(h => (
                      <th key={h} style={{fontSize:10,fontWeight:700,color:'#6b6458',letterSpacing:1.5,textTransform:'uppercase',padding:'6px 8px',textAlign:h==='Amount'||h==='Tax'||h==='Qty'||h==='Unit Price'?'right':'left'}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, i) => (
                    <tr key={i} style={{borderBottom:'1px solid rgba(201,169,110,0.04)'}}>
                      <td style={{padding:'12px 8px',fontSize:13,color:'#f2ede6'}}>{item.description}</td>
                      <td style={{padding:'12px 8px',fontSize:11}}><Badge color="blue" size="xs">{item.category||'Service'}</Badge></td>
                      <td style={{padding:'12px 8px',fontSize:13,color:'#9ca3af',textAlign:'right'}}>{item.quantity}</td>
                      <td style={{padding:'12px 8px',fontSize:13,color:'#9ca3af',textAlign:'right'}}>{fmt.currency(item.unit_price)}</td>
                      <td style={{padding:'12px 8px',fontSize:13,color:'#9ca3af',textAlign:'right'}}>{item.tax_rate||18}%</td>
                      <td style={{padding:'12px 8px',fontSize:13,fontWeight:600,color:'#f2ede6',textAlign:'right'}}>{fmt.currency(item.total||item.subtotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="px-6 pb-6 flex justify-end">
              <div style={{minWidth:280}}>
                <div className="flex justify-between py-2" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                  <span style={{fontSize:13,color:'#9ca3af'}}>Subtotal</span>
                  <span style={{fontSize:13,color:'#f2ede6'}}>{fmt.currency(invoice.subtotal)}</span>
                </div>
                {invoice.discount_amount > 0 && (
                  <div className="flex justify-between py-2" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                    <span style={{fontSize:13,color:'#10b981'}}>Discount ({invoice.discount_value}%)</span>
                    <span style={{fontSize:13,color:'#10b981'}}>- {fmt.currency(invoice.discount_amount)}</span>
                  </div>
                )}
                <div className="flex justify-between py-2" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                  <span style={{fontSize:13,color:'#9ca3af'}}>GST ({invoice.tax_rate}%)</span>
                  <span style={{fontSize:13,color:'#9ca3af'}}>{fmt.currency(invoice.tax_amount)}</span>
                </div>
                <div className="flex justify-between py-3" style={{borderBottom:'2px solid rgba(201,169,110,0.2)'}}>
                  <span style={{fontSize:15,fontWeight:700,color:'#f2ede6'}}>Grand Total</span>
                  <span style={{fontSize:15,fontWeight:700,color:'#c9a96e'}}>{fmt.currency(invoice.grand_total)}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span style={{fontSize:13,color:'#10b981'}}>Amount Paid</span>
                  <span style={{fontSize:13,fontWeight:600,color:'#10b981'}}>{fmt.currency(invoice.amount_paid)}</span>
                </div>
                <div className="flex justify-between py-2 rounded-lg px-3" style={{background:invoice.balance_due>0?'rgba(239,68,68,0.08)':'rgba(16,185,129,0.08)',marginTop:4}}>
                  <span style={{fontSize:14,fontWeight:700,color:invoice.balance_due>0?'#ef4444':'#10b981'}}>Balance Due</span>
                  <span style={{fontSize:14,fontWeight:700,color:invoice.balance_due>0?'#ef4444':'#10b981'}}>{fmt.currency(invoice.balance_due)}</span>
                </div>
              </div>
            </div>

            {/* Notes */}
            {invoice.notes && (
              <div className="px-6 pb-5" style={{borderTop:'1px solid rgba(201,169,110,0.06)',paddingTop:16}}>
                <div style={{fontSize:11,color:'#6b6458',marginBottom:4}}>NOTES</div>
                <div style={{fontSize:13,color:'#9ca3af'}}>{invoice.notes}</div>
              </div>
            )}
          </div>

          {/* Payment History */}
          <Card>
            <CardHeader title="Payment History" />
            {payments.length === 0
              ? <EmptyState icon="💳" title="No payments recorded" action={<Button onClick={()=>setPayModal(true)}>Record First Payment</Button>} />
              : <table className="w-full border-collapse">
                  <thead>
                    <tr>
                      {['Payment Code','Method','Type','Amount','Date','Status'].map(h => (
                        <th key={h} style={{fontSize:10,fontWeight:700,color:'#6b6458',letterSpacing:1.5,textTransform:'uppercase',padding:'10px 16px',textAlign:'left',borderBottom:'1px solid rgba(201,169,110,0.06)'}}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map(p => (
                      <tr key={p.id} style={{borderBottom:'1px solid rgba(201,169,110,0.04)'}}>
                        <td style={{padding:'12px 16px',fontSize:13,color:'#c9a96e',fontWeight:600}}>{p.payment_code}</td>
                        <td style={{padding:'12px 16px',fontSize:13,color:'#9ca3af',textTransform:'capitalize'}}>{p.payment_method?.replace('_',' ')}</td>
                        <td style={{padding:'12px 16px'}}><Badge color="blue" size="xs">{p.payment_type}</Badge></td>
                        <td style={{padding:'12px 16px',fontSize:13,fontWeight:600,color:'#10b981'}}>{fmt.currency(p.amount)}</td>
                        <td style={{padding:'12px 16px',fontSize:13,color:'#9ca3af'}}>{fmt.date(p.payment_date)}</td>
                        <td style={{padding:'12px 16px'}}><Badge color="green">{p.status}</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
            }
          </Card>
        </div>

        {/* Right sidebar */}
        <div className="space-y-5">
          <Card>
            <CardHeader title="Invoice Summary" />
            <div className="px-5 pb-3">
              <StatRow label="Invoice #" value={invoice.invoice_number} />
              <StatRow label="Issued Date" value={fmt.date(invoice.invoice_date)} />
              <StatRow label="Due Date" value={fmt.date(invoice.due_date)} />
              <StatRow label="Grand Total" value={fmt.currency(invoice.grand_total)} />
              <StatRow label="Amount Paid" value={fmt.currency(invoice.amount_paid)} valueColor="#10b981" />
              <StatRow label="Balance Due" value={fmt.currency(invoice.balance_due)} valueColor={invoice.balance_due>0?'#ef4444':'#10b981'} />
              <div className="mt-4">
                <div style={{fontSize:11,color:'#6b6458',marginBottom:4}}>Collection Progress</div>
                <div className="rounded-full overflow-hidden" style={{background:'#141d35',height:8}}>
                  <div className="h-full rounded-full" style={{width:`${Math.min(100,Math.round(invoice.amount_paid/Math.max(invoice.grand_total,1)*100))}%`,background:'linear-gradient(90deg,#9a7a4a,#c9a96e)'}}/>
                </div>
                <div className="text-right mt-1" style={{fontSize:11,color:'#6b6458'}}>
                  {Math.min(100,Math.round(invoice.amount_paid/Math.max(invoice.grand_total,1)*100))}% collected
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader title="Actions" />
            <div className="p-4 space-y-2">
              {invoice.balance_due > 0 && <Button className="w-full justify-start" size="sm" onClick={()=>setPayModal(true)}>💳 Record Payment</Button>}
              <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Generating PDF…')}>📄 Download PDF</Button>
              <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Sending email…')}>📧 Email Invoice</Button>
              <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Sending WhatsApp…')}>💬 WhatsApp</Button>
              <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>navigate(`/events/${invoice.event_id}`)}>💐 View Event</Button>
              <Button variant="danger" className="w-full justify-start" size="sm" onClick={()=>toast.error('Cancel not allowed for partial invoices')}>🚫 Cancel Invoice</Button>
            </div>
          </Card>

          <Card>
            <CardHeader title="Customer" />
            <div className="p-5">
              <div style={{fontSize:15,fontWeight:600,color:'#f2ede6',marginBottom:4}}>{invoice.customer_name}</div>
              <div style={{fontSize:13,color:'#9ca3af'}}>{invoice.phone}</div>
              <div style={{fontSize:13,color:'#9ca3af'}}>{invoice.email}</div>
              <Button variant="outline" size="sm" className="mt-3 w-full justify-center" onClick={()=>navigate(`/customers/${invoice.customer_id}`)}>View Profile →</Button>
            </div>
          </Card>
        </div>
      </div>

      {/* Record Payment Modal */}
      <Modal open={payModal} onClose={()=>setPayModal(false)} title="💳 Record Payment">
        <div className="rounded-xl p-4 mb-4" style={{background:'rgba(201,169,110,0.06)',border:'1px solid rgba(201,169,110,0.15)'}}>
          <div className="flex justify-between">
            <span style={{fontSize:13,color:'#9ca3af'}}>Invoice: {invoice.invoice_number}</span>
            <span style={{fontSize:13,color:'#9ca3af'}}>Balance Due: <strong style={{color:'#ef4444'}}>{fmt.currency(invoice.balance_due)}</strong></span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2 mb-1">
            <label className="block mb-1.5" style={{fontSize:12,fontWeight:500,color:'#6b6458'}}>Amount (₹) *</label>
            <input className="input-dark" type="number" placeholder={invoice.balance_due} value={payForm.amount}
              onChange={e=>setPayForm(f=>({...f,amount:e.target.value}))} max={invoice.balance_due}/>
          </div>
          <Select label="Payment Method" value={payForm.payment_method} onChange={e=>setPayForm(f=>({...f,payment_method:e.target.value}))}
            options={[{value:'upi',label:'UPI'},{value:'bank_transfer',label:'Bank Transfer'},{value:'cash',label:'Cash'},{value:'cheque',label:'Cheque'},{value:'card',label:'Card'},{value:'online',label:'Online Gateway'}]}/>
          <Select label="Payment Type" value={payForm.payment_type} onChange={e=>setPayForm(f=>({...f,payment_type:e.target.value}))}
            options={[{value:'advance',label:'Advance'},{value:'installment',label:'Installment'},{value:'full',label:'Full Payment'},{value:'partial',label:'Partial'}]}/>
          <div className="col-span-2 mb-1">
            <label className="block mb-1.5" style={{fontSize:12,fontWeight:500,color:'#6b6458'}}>Reference / UTR (optional)</label>
            <input className="input-dark" placeholder="e.g., UPI-TXN-12345" value={payForm.payment_ref} onChange={e=>setPayForm(f=>({...f,payment_ref:e.target.value}))}/>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setPayModal(false)}>Cancel</Button>
          <Button onClick={recordPayment} loading={saving} disabled={!payForm.amount || +payForm.amount <= 0}>Confirm Payment ✓</Button>
        </div>
      </Modal>
    </div>
  );
}

const MOCK = {
  invoice:{id:1,invoice_number:'INV-2025-00001',event_id:1,event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',customer_id:1,customer_name:'Vikram Patel',phone:'+91-9876543214',email:'vikram.patel@gmail.com',invoice_date:'2025-09-01',due_date:'2025-09-15',subtotal:368000,discount_value:0,discount_amount:0,tax_rate:18,tax_amount:66240,grand_total:434240,amount_paid:300000,balance_due:134240,status:'partial',notes:'Payment terms: 25% advance, 50% before event, 25% post-event.'},
  items:[
    {id:1,description:'Gold Wedding Catering Package (500 guests)',category:'Catering',quantity:1,unit_price:180000,tax_rate:18,tax_amount:32400,subtotal:180000,total:212400},
    {id:2,description:'Premium Cinematic Photography + Videography',category:'Photography',quantity:1,unit_price:95000,tax_rate:18,tax_amount:17100,subtotal:95000,total:112100},
    {id:3,description:'Elegant Stage & Hall Decoration',category:'Decoration',quantity:1,unit_price:75000,tax_rate:18,tax_amount:13500,subtotal:75000,total:88500},
    {id:4,description:'Bridal Glam Makeup Package',category:'Makeup',quantity:1,unit_price:18000,tax_rate:18,tax_amount:3240,subtotal:18000,total:21240},
  ],
  payments:[
    {id:1,payment_code:'PAY-2025-0001',payment_method:'bank_transfer',payment_type:'advance',amount:300000,payment_date:'2025-09-01',status:'completed'},
  ],
};
