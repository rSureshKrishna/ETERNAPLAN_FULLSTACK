import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { customerService } from '../../services/services';
import {
  PageHeader, Card, Table, StatusBadge, Button, FilterTabs,
  Badge, PageSpinner, EmptyState, Pagination, Avatar, Modal,
  Input, Select, Textarea
} from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

const LEAD_TABS = [
  { value:'', label:'All Customers' },
  { value:'new', label:'New' },
  { value:'contacted', label:'Contacted' },
  { value:'qualified', label:'Qualified' },
  { value:'proposal_sent', label:'Proposal Sent' },
  { value:'won', label:'Won ✓' },
  { value:'lost', label:'Lost' },
];

const PIPELINE = [
  { stage:'new', label:'New', color:'#6b6458' },
  { stage:'contacted', label:'Contacted', color:'#60a5fa' },
  { stage:'qualified', label:'Qualified', color:'#60a5fa' },
  { stage:'proposal_sent', label:'Proposal', color:'#fbbf24' },
  { stage:'won', label:'Won', color:'#10b981' },
  { stage:'lost', label:'Lost', color:'#ef4444' },
];

export default function CustomersPage() {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ lead_status:'', search:'', priority:'', page:1 });
  const [addModal, setAddModal] = useState(false);
  const [form, setForm] = useState({ first_name:'', last_name:'', phone:'', email:'', source:'walk_in', priority:'medium', lead_status:'new' });
  const [saving, setSaving] = useState(false);

  const load = async (f = filters) => {
    setLoading(true);
    try {
      const r = await customerService.list({ ...f, limit:15 });
      setCustomers(r.data.data.customers);
      setPagination(r.data.data.pagination);
    } catch {
      setCustomers(MOCK_CUSTOMERS);
      setPagination({ page:1, limit:15, total:MOCK_CUSTOMERS.length, pages:1 });
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const handleAdd = async () => {
    if (!form.first_name || !form.phone) { toast.error('Name and phone required'); return; }
    setSaving(true);
    try {
      await customerService.create(form);
      toast.success('Customer added!');
      setAddModal(false);
      setForm({ first_name:'', last_name:'', phone:'', email:'', source:'walk_in', priority:'medium', lead_status:'new' });
      load();
    } catch { toast.error('Failed to add customer'); }
    finally { setSaving(false); }
  };

  const pColor = { vip:'gold', high:'purple', medium:'blue', low:'gray' };

  const columns = [
    { key:'first_name', label:'Customer', render:(v,r) => (
      <div className="flex items-center gap-3">
        <Avatar name={`${v} ${r.last_name}`} size={34} />
        <div>
          <div style={{fontWeight:500, color:'#f2ede6', fontSize:13.5}}>{v} {r.last_name}</div>
          <div style={{fontSize:11, color:'#6b6458'}}>{r.source?.replace(/_/g,' ')}</div>
        </div>
      </div>
    )},
    { key:'phone', label:'Contact', render:(v,r) => (
      <div>
        <div style={{color:'#9ca3af', fontSize:13}}>{v}</div>
        <div style={{fontSize:11, color:'#6b6458'}}>{r.email||'—'}</div>
      </div>
    )},
    { key:'priority', label:'Priority', render:v => <Badge color={pColor[v]||'gray'}>{(v||'').toUpperCase()}</Badge> },
    { key:'lead_status', label:'Lead Status', render:v => <StatusBadge type="lead" value={v} /> },
    { key:'total_events', label:'Events', render:v => <span style={{color:'#f2ede6', fontWeight:600, fontSize:13}}>{v||0}</span> },
    { key:'lifetime_value', label:'Lifetime Value', render:v => <span style={{color:'#c9a96e', fontWeight:500}}>{fmt.currency(v)}</span> },
    { key:'assigned_to_name', label:'Manager', render:v => <span style={{color:'#9ca3af', fontSize:12}}>{v||'—'}</span> },
    { key:'id', label:'', render:(_,r) => (
      <div className="flex gap-1.5">
        <Button variant="outline" size="xs" onClick={e => { e.stopPropagation(); navigate(`/customers/${r.id}`); }}>View</Button>
        <Button variant="outline" size="xs" onClick={e => { e.stopPropagation(); toast('Adding note…'); }}>Note</Button>
      </div>
    )},
  ];

  // Pipeline count by stage
  const pipeline = PIPELINE.map(p => ({
    ...p,
    count: customers.filter(c => c.lead_status === p.stage).length,
  }));

  return (
    <div>
      <PageHeader title="Customer CRM" subtitle="Manage customer relationships and lead pipeline">
        <Button variant="outline" size="sm">📤 Import</Button>
        <Button size="sm" onClick={() => setAddModal(true)}>+ Add Customer</Button>
      </PageHeader>

      {/* Pipeline Summary */}
      <div className="grid grid-cols-6 gap-3 mb-5">
        {pipeline.map(({ stage, label, color, count }) => (
          <div key={stage}
            className="rounded-xl p-4 text-center cursor-pointer transition-all"
            style={{ background:'#19233e', border:`1px solid ${filters.lead_status===stage?'rgba(201,169,110,0.3)':'rgba(201,169,110,0.08)'}` }}
            onClick={() => { const f={...filters, lead_status:stage, page:1}; setFilters(f); load(f); }}>
            <div style={{ fontFamily:'Cinzel,serif', fontSize:22, fontWeight:700, color, lineHeight:1 }}>{count}</div>
            <div style={{ fontSize:11, color:'#6b6458', marginTop:4 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <FilterTabs
        tabs={LEAD_TABS}
        active={filters.lead_status}
        onChange={v => { const f={...filters, lead_status:v, page:1}; setFilters(f); load(f); }}
      />

      <div className="flex flex-wrap gap-3 mb-4">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg flex-1" style={{ minWidth:200, maxWidth:320, background:'#141d35', border:'1px solid rgba(201,169,110,0.08)' }}>
          <span style={{color:'#6b6458'}}>🔍</span>
          <input className="bg-transparent border-none outline-none text-sm flex-1" style={{color:'#f2ede6'}}
            placeholder="Search name, phone, email…"
            onChange={e => { const f={...filters, search:e.target.value, page:1}; setFilters(f); load(f); }} />
        </div>
        <select className="input-dark" style={{width:140, padding:'8px 12px'}}
          value={filters.priority}
          onChange={e => { const f={...filters, priority:e.target.value, page:1}; setFilters(f); load(f); }}>
          <option value="">All Priority</option>
          <option value="vip">⭐ VIP</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </div>

      <Card>
        {loading
          ? <div className="py-16"><PageSpinner /></div>
          : customers.length === 0
            ? <EmptyState icon="👤" title="No customers found" description="Add your first customer to get started." action={<Button onClick={() => setAddModal(true)}>+ Add Customer</Button>} />
            : <>
                <Table columns={columns} data={customers} onRowClick={r => navigate(`/customers/${r.id}`)} />
                <Pagination pagination={pagination} onChange={p => { const f={...filters, page:p}; setFilters(f); load(f); }} />
              </>
        }
      </Card>

      {/* Add Customer Modal */}
      <Modal open={addModal} onClose={() => setAddModal(false)} title="✦ Add Customer">
        <div className="grid grid-cols-2 gap-4">
          <Input label="First Name *" value={form.first_name} onChange={e => setForm(f=>({...f,first_name:e.target.value}))} placeholder="Vikram" />
          <Input label="Last Name" value={form.last_name} onChange={e => setForm(f=>({...f,last_name:e.target.value}))} placeholder="Patel" />
          <Input label="Phone *" value={form.phone} onChange={e => setForm(f=>({...f,phone:e.target.value}))} placeholder="+91 9876543210" />
          <Input label="Email" type="email" value={form.email} onChange={e => setForm(f=>({...f,email:e.target.value}))} placeholder="email@gmail.com" />
          <Select label="Source" value={form.source} onChange={e => setForm(f=>({...f,source:e.target.value}))}
            options={[{value:'walk_in',label:'Walk In'},{value:'referral',label:'Referral'},{value:'website',label:'Website'},{value:'social_media',label:'Social Media'},{value:'phone',label:'Phone Enquiry'},{value:'other',label:'Other'}]} />
          <Select label="Priority" value={form.priority} onChange={e => setForm(f=>({...f,priority:e.target.value}))}
            options={[{value:'low',label:'Low'},{value:'medium',label:'Medium'},{value:'high',label:'High'},{value:'vip',label:'⭐ VIP'}]} />
        </div>
        <Textarea label="Initial Notes (optional)" value={form.notes} onChange={e => setForm(f=>({...f,notes:e.target.value}))} placeholder="Any initial notes about this customer…" />
        <div className="flex justify-end gap-3 mt-2">
          <Button variant="outline" onClick={() => setAddModal(false)}>Cancel</Button>
          <Button onClick={handleAdd} loading={saving} disabled={!form.first_name||!form.phone}>Add Customer ✦</Button>
        </div>
      </Modal>
    </div>
  );
}

import { Textarea } from '../../components/common';

const MOCK_CUSTOMERS = [
  {id:1,first_name:'Vikram',last_name:'Patel',phone:'+91-9876543214',email:'vikram.patel@gmail.com',priority:'vip',lead_status:'won',total_events:3,lifetime_value:1850000,assigned_to_name:'Rahul Menon',source:'referral'},
  {id:2,first_name:'Ananya',last_name:'Krishnan',phone:'+91-9712345678',email:'ananya.k@gmail.com',priority:'high',lead_status:'confirmed',total_events:1,lifetime_value:620000,assigned_to_name:'Rahul Menon',source:'social_media'},
  {id:3,first_name:'Meera',last_name:'Iyer',phone:'+91-9934567890',email:'meera.iyer@gmail.com',priority:'vip',lead_status:'won',total_events:2,lifetime_value:2280000,assigned_to_name:'Sneha Krishnan',source:'walk_in'},
  {id:4,first_name:'Kavya',last_name:'Nambiar',phone:'+91-9756789012',email:'kavya.n@gmail.com',priority:'high',lead_status:'won',total_events:4,lifetime_value:1420000,assigned_to_name:'Rahul Menon',source:'referral'},
  {id:5,first_name:'Rohit',last_name:'Verma',phone:'+91-9823456789',email:'rohit.verma@gmail.com',priority:'medium',lead_status:'proposal_sent',total_events:0,lifetime_value:0,assigned_to_name:'Rahul Menon',source:'website'},
  {id:6,first_name:'Aditya',last_name:'Singh',phone:'+91-9645678901',email:'aditya.singh@gmail.com',priority:'medium',lead_status:'qualified',total_events:1,lifetime_value:800000,assigned_to_name:'Sneha Krishnan',source:'phone'},
  {id:7,first_name:'Deepika',last_name:'Rao',phone:'+91-9978901234',email:'deepika.rao@gmail.com',priority:'high',lead_status:'won',total_events:1,lifetime_value:380000,assigned_to_name:'Sneha Krishnan',source:'social_media'},
  {id:8,first_name:'Sanjay',last_name:'Mehta',phone:'+91-9867890123',email:'sanjay.mehta@gmail.com',priority:'low',lead_status:'contacted',total_events:0,lifetime_value:0,assigned_to_name:'Rahul Menon',source:'website'},
];
