import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { customerService } from '../../services/services';
import {
  PageHeader, Card, CardHeader, Table, StatusBadge, Button,
  Badge, StatRow, Modal, Select, Textarea, EmptyState, PageSpinner, Avatar
} from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

const TABS = ['Overview','Events','Notes','Activity'];

export default function CustomerDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tab, setTab] = useState('Overview');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [noteModal, setNoteModal] = useState(false);
  const [noteForm, setNoteForm] = useState({ note:'', note_type:'general', followup_at:'' });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const r = await customerService.get(id); setData(r.data.data); }
    catch { setData(MOCK); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [id]);

  const addNote = async () => {
    setSaving(true);
    try {
      await customerService.addNote(id, noteForm);
      toast.success('Note added!');
      setNoteModal(false);
      setNoteForm({ note:'', note_type:'general', followup_at:'' });
      load();
    } catch { toast.error('Failed to add note'); }
    finally { setSaving(false); }
  };

  if (loading) return <PageSpinner />;
  if (!data) return <EmptyState icon="👤" title="Customer not found" />;

  const { customer, events = [], notes = [] } = data;
  const pColor = { vip:'gold', high:'purple', medium:'blue', low:'gray' }[customer.priority] || 'gray';

  return (
    <div>
      <PageHeader title={`${customer.first_name} ${customer.last_name}`}
        subtitle={`Customer #${customer.id} · Since ${fmt.date(customer.created_at)}`}>
        <Button variant="outline" size="sm" onClick={() => navigate('/customers')}>← Back</Button>
        <Button variant="outline" size="sm" onClick={() => setNoteModal(true)}>+ Note</Button>
        <Button size="sm" onClick={() => navigate('/events/new')}>+ Event</Button>
      </PageHeader>

      {/* Header card */}
      <div className="rounded-2xl p-6 mb-5 flex flex-wrap gap-6 items-center"
        style={{ background:'#19233e', border:'1px solid rgba(201,169,110,0.12)' }}>
        <Avatar name={`${customer.first_name} ${customer.last_name}`} size={72} />
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap gap-3 mb-2">
            <h2 style={{ fontFamily:'Cormorant Garamond,serif', fontSize:22, fontWeight:600, color:'#f2ede6' }}>
              {customer.first_name} {customer.last_name}
            </h2>
            <Badge color={pColor}>{(customer.priority||'').toUpperCase()}</Badge>
            <StatusBadge type="lead" value={customer.lead_status} />
          </div>
          <div className="flex flex-wrap gap-5">
            <span style={{fontSize:13,color:'#9ca3af'}}>📞 {customer.phone}</span>
            {customer.email && <span style={{fontSize:13,color:'#9ca3af'}}>✉️ {customer.email}</span>}
            {customer.city && <span style={{fontSize:13,color:'#9ca3af'}}>📍 {customer.city}</span>}
            <span style={{fontSize:13,color:'#9ca3af'}}>🎯 {customer.source?.replace(/_/g,' ')}</span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-6 text-center">
          {[
            { l:'Events', v:customer.total_events||events.length, c:'#c9a96e' },
            { l:'Lifetime Value', v:fmt.lakh(customer.lifetime_value||customer.total_revenue), c:'#10b981' },
            { l:'Assigned To', v:(customer.assigned_manager||'—').split(' ')[0], c:'#9ca3af' },
          ].map(({l,v,c}) => (
            <div key={l}>
              <div style={{fontFamily:'Cinzel,serif',fontSize:18,fontWeight:700,color:c}}>{v}</div>
              <div style={{fontSize:11,color:'#6b6458',marginTop:3}}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex mb-5" style={{borderBottom:'1px solid rgba(201,169,110,0.08)'}}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{padding:'10px 20px',fontSize:13.5,fontWeight:500,
            background:'transparent',border:'none',cursor:'pointer',color:tab===t?'#c9a96e':'#6b6458',
            borderBottom:tab===t?'2px solid #c9a96e':'2px solid transparent',marginBottom:-1,transition:'color .2s'}}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-5">
            <Card>
              <CardHeader title="Profile Details" />
              <div className="p-5 grid grid-cols-2 gap-x-8 gap-y-4">
                {[
                  ['Phone', customer.phone],
                  ['Email', customer.email||'—'],
                  ['WhatsApp', customer.whatsapp||'—'],
                  ['Date of Birth', fmt.date(customer.date_of_birth)||'—'],
                  ['Anniversary', fmt.date(customer.anniversary_date)||'—'],
                  ['City', customer.city||'—'],
                  ['State', customer.state||'—'],
                  ['Lead Status', customer.lead_status?.replace(/_/g,' ')],
                  ['Priority', customer.priority],
                  ['Source', customer.source?.replace(/_/g,' ')],
                  ['Assigned Manager', customer.assigned_manager||'—'],
                  ['Member Since', fmt.date(customer.created_at)],
                ].map(([l,v]) => (
                  <div key={l}>
                    <div style={{fontSize:11,color:'#6b6458',marginBottom:2}}>{l}</div>
                    <div style={{fontSize:13,color:'#f2ede6',textTransform:'capitalize'}}>{v||'—'}</div>
                  </div>
                ))}
              </div>
              {customer.notes && (
                <div className="px-5 pb-5">
                  <div style={{fontSize:11,color:'#6b6458',marginBottom:4}}>Notes</div>
                  <div style={{fontSize:13,color:'#9ca3af',lineHeight:1.6}}>{customer.notes}</div>
                </div>
              )}
            </Card>

            {events.length > 0 && (
              <Card>
                <CardHeader title="Recent Events" action={<Button size="xs" onClick={()=>setTab('Events')}>View All</Button>} />
                <div className="p-3">
                  {events.slice(0,3).map(ev => (
                    <div key={ev.id} onClick={() => navigate(`/events/${ev.id}`)}
                      className="flex items-center gap-4 p-3 rounded-xl mb-2 cursor-pointer transition-all"
                      style={{background:'#141d35',border:'1px solid rgba(201,169,110,0.06)'}}
                      onMouseEnter={e=>e.currentTarget.style.borderColor='rgba(201,169,110,0.2)'}
                      onMouseLeave={e=>e.currentTarget.style.borderColor='rgba(201,169,110,0.06)'}>
                      <div className="rounded-xl text-center py-2 px-3 flex-shrink-0"
                        style={{background:'rgba(201,169,110,0.08)',border:'1px solid rgba(201,169,110,0.15)',minWidth:52}}>
                        <div style={{fontFamily:'Cinzel,serif',fontSize:18,fontWeight:700,color:'#c9a96e',lineHeight:1}}>
                          {new Date(ev.event_date).getDate()}
                        </div>
                        <div style={{fontSize:9,color:'#6b6458',letterSpacing:1,textTransform:'uppercase'}}>
                          {new Date(ev.event_date).toLocaleString('en',{month:'short'})}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div style={{fontSize:13.5,fontWeight:500,color:'#f2ede6'}}>{ev.event_name}</div>
                        <div style={{fontSize:11,color:'#6b6458'}}>Budget: {fmt.currency(ev.budget_total)}</div>
                      </div>
                      <StatusBadge type="event" value={ev.status} />
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>

          <div className="space-y-5">
            <Card>
              <CardHeader title="Financials" />
              <div className="px-5 pb-3">
                <StatRow label="Total Events" value={customer.total_events||events.length} />
                <StatRow label="Lifetime Value" value={fmt.currency(customer.lifetime_value||0)} valueColor="#10b981" />
                <StatRow label="Avg Event Value" value={events.length?fmt.currency(events.reduce((s,e)=>s+(+e.budget_total),0)/events.length):'—'} />
                <StatRow label="Last Event" value={events[0]?.event_date ? fmt.date(events[0].event_date) : '—'} />
              </div>
            </Card>
            <Card>
              <CardHeader title="Pipeline Stage" />
              <div className="p-5">
                {['new','contacted','qualified','proposal_sent','won'].map((s,i,arr) => {
                  const idx = arr.indexOf(customer.lead_status);
                  const done = i<=idx; const cur = i===idx;
                  return (
                    <div key={s} className="flex items-center gap-3 mb-3">
                      <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold"
                        style={{background:done?'#c9a96e':'#141d35',color:done?'#030508':'#6b6458',border:cur?'2px solid #c9a96e':done?'none':'1px solid #3a3028'}}>
                        {done?'✓':''}
                      </div>
                      <span style={{fontSize:13,color:cur?'#c9a96e':done?'#f2ede6':'#6b6458',fontWeight:cur?600:400,textTransform:'capitalize'}}>
                        {s.replace('_',' ')}
                      </span>
                    </div>
                  );
                })}
              </div>
            </Card>
            <Card>
              <CardHeader title="Quick Actions" />
              <div className="p-4 space-y-2">
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>setNoteModal(true)}>📝 Add Note</Button>
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>navigate('/events/new')}>💐 New Event</Button>
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Opening WhatsApp…')}>💬 WhatsApp</Button>
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Email opened')}>✉️ Send Email</Button>
              </div>
            </Card>
          </div>
        </div>
      )}

      {tab === 'Events' && (
        <Card>
          <CardHeader title="All Events" action={<Button size="sm" onClick={()=>navigate('/events/new')}>+ New Event</Button>} />
          {events.length===0
            ? <EmptyState icon="💐" title="No events yet" action={<Button onClick={()=>navigate('/events/new')}>Create Event →</Button>} />
            : <Table
                columns={[
                  {key:'event_code',label:'Code',render:v=><span style={{color:'#c9a96e',fontWeight:600}}>{v}</span>},
                  {key:'event_name',label:'Event',render:v=><span style={{color:'#f2ede6'}}>{v}</span>},
                  {key:'event_date',label:'Date',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
                  {key:'status',label:'Status',render:v=><StatusBadge type="event" value={v}/>},
                  {key:'budget_total',label:'Budget',render:v=><span style={{color:'#f2ede6'}}>{fmt.currency(v)}</span>},
                  {key:'id',label:'',render:(_,r)=><Button variant="outline" size="xs" onClick={()=>navigate(`/events/${r.id}`)}>View →</Button>},
                ]}
                data={events}
              />
          }
        </Card>
      )}

      {tab === 'Notes' && (
        <div>
          <div className="flex justify-between mb-4">
            <span style={{fontSize:14,color:'#9ca3af'}}>{notes.length} notes</span>
            <Button size="sm" onClick={()=>setNoteModal(true)}>+ Add Note</Button>
          </div>
          {notes.length===0
            ? <Card><EmptyState icon="📝" title="No notes yet" action={<Button onClick={()=>setNoteModal(true)}>Add Note</Button>}/></Card>
            : notes.map(note => (
              <div key={note.id} className="rounded-xl p-5 mb-3"
                style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
                <div className="flex justify-between mb-3">
                  <div className="flex gap-2 items-center">
                    <Badge color={{general:'blue',followup:'amber',complaint:'red',meeting:'purple',call:'green',other:'gray'}[note.note_type]||'gray'}>
                      {note.note_type?.replace('_',' ')}
                    </Badge>
                    {note.followup_at && <span style={{fontSize:11,color:'#f59e0b'}}>📅 {fmt.date(note.followup_at)}</span>}
                  </div>
                  <span style={{fontSize:11,color:'#6b6458'}}>{fmt.dateTime(note.created_at)}</span>
                </div>
                <p style={{fontSize:13.5,color:'#f2ede6',lineHeight:1.65}}>{note.note}</p>
                <div className="flex items-center gap-2 mt-3">
                  <Avatar name={note.added_by||'User'} size={20}/>
                  <span style={{fontSize:11,color:'#6b6458'}}>{note.added_by||'Team'}</span>
                </div>
              </div>
            ))
          }
        </div>
      )}

      {tab === 'Activity' && (
        <Card>
          <CardHeader title="Activity Timeline"/>
          <div className="p-6">
            <div className="relative pl-6">
              <div className="absolute left-2 top-0 bottom-0 w-px" style={{background:'rgba(201,169,110,0.15)'}}/>
              {MOCK_ACTIVITY.map((a,i) => (
                <div key={i} className="relative mb-5">
                  <div className="absolute -left-4 top-1.5 w-3 h-3 rounded-full" style={{background:'rgba(201,169,110,0.2)',border:'2px solid rgba(201,169,110,0.4)'}}/>
                  <div style={{fontSize:11,color:'#6b6458',marginBottom:2}}>{a.time}</div>
                  <div style={{fontSize:13.5,fontWeight:500,color:'#f2ede6'}}>{a.title}</div>
                  <div style={{fontSize:12,color:'#6b6458'}}>{a.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      <Modal open={noteModal} onClose={()=>setNoteModal(false)} title="✦ Add Note">
        <Textarea label="Note *" value={noteForm.note} onChange={e=>setNoteForm(f=>({...f,note:e.target.value}))} placeholder="Write your note…"/>
        <div className="grid grid-cols-2 gap-4">
          <Select label="Type" value={noteForm.note_type} onChange={e=>setNoteForm(f=>({...f,note_type:e.target.value}))}
            options={[{value:'general',label:'General'},{value:'followup',label:'Follow-up'},{value:'meeting',label:'Meeting'},{value:'call',label:'Call'},{value:'complaint',label:'Complaint'},{value:'other',label:'Other'}]}/>
          <div className="mb-4">
            <label className="block mb-1.5" style={{fontSize:12,fontWeight:500,color:'#6b6458'}}>Follow-up Date</label>
            <input type="datetime-local" className="input-dark" value={noteForm.followup_at} onChange={e=>setNoteForm(f=>({...f,followup_at:e.target.value}))}/>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-2">
          <Button variant="outline" onClick={()=>setNoteModal(false)}>Cancel</Button>
          <Button onClick={addNote} loading={saving} disabled={!noteForm.note.trim()}>Save Note</Button>
        </div>
      </Modal>
    </div>
  );
}

const MOCK = {
  customer:{id:1,first_name:'Vikram',last_name:'Patel',email:'vikram.patel@gmail.com',phone:'+91-9876543214',whatsapp:'+91-9876543214',city:'Chennai',state:'Tamil Nadu',lead_status:'won',priority:'vip',source:'referral',total_events:3,total_revenue:1850000,lifetime_value:1850000,assigned_manager:'Rahul Menon',notes:'Long-term VIP client. Always pays on time.',anniversary_date:'2020-03-15',created_at:'2024-06-15'},
  events:[{id:1,event_code:'EVT-2025-0001',event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',status:'confirmed',budget_total:1200000},{id:4,event_code:'EVT-2024-0022',event_name:'Vikram Anniversary',event_date:'2024-03-15',status:'completed',budget_total:350000}],
  notes:[{id:1,note:'Client prefers marigold and roses. Wife wants 3-tier cake.',note_type:'call',followup_at:'2025-10-15',added_by:'Rahul Menon',created_at:'2025-09-20T10:30:00'},{id:2,note:'Site visit to Grand Palace completed. Client approved layout.',note_type:'meeting',added_by:'Sneha Krishnan',created_at:'2025-09-10T14:00:00'}],
};
const MOCK_ACTIVITY=[
  {time:'Sep 20, 2025',title:'Phone call logged',desc:'Discussed floral arrangements and cake'},
  {time:'Sep 10, 2025',title:'Site visit completed',desc:'Client approved Grand Palace layout'},
  {time:'Sep 1, 2025',title:'Payment ₹3,00,000 received',desc:'Bank transfer — advance payment'},
  {time:'Jul 15, 2025',title:'Customer profile created',desc:'Referred by Meera Iyer'},
];
