import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageHeader, Card, Badge, Button, StatusBadge, Avatar } from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

const STAGES = [
  { key:'new',           label:'New',           color:'#6b6458', bg:'rgba(107,100,88,0.1)' },
  { key:'contacted',     label:'Contacted',     color:'#60a5fa', bg:'rgba(59,130,246,0.1)' },
  { key:'qualified',     label:'Qualified',     color:'#60a5fa', bg:'rgba(59,130,246,0.1)' },
  { key:'proposal_sent', label:'Proposal Sent', color:'#fbbf24', bg:'rgba(245,158,11,0.1)' },
  { key:'negotiation',   label:'Negotiation',   color:'#a78bfa', bg:'rgba(139,92,246,0.1)' },
  { key:'won',           label:'Won ✓',         color:'#10b981', bg:'rgba(16,185,129,0.1)' },
];

const ALL_LEADS = [
  { id:8,  name:'Sanjay Mehta',    phone:'+91-9867890123', event:'Corporate Event Dec 2025', budget:800000, stage:'new',           priority:'low',    days:2  },
  { id:5,  name:'Rohit Verma',     phone:'+91-9823456789', event:'Wedding Jan 2026',          budget:1500000,stage:'proposal_sent', priority:'medium', days:5  },
  { id:6,  name:'Aditya Singh',    phone:'+91-9645678901', event:'Corporate Gala Dec 2025',   budget:800000, stage:'qualified',     priority:'medium', days:3  },
  { id:3,  name:'Priya Sharma',    phone:'+91-9700001234', event:'Reception Feb 2026',         budget:600000, stage:'contacted',     priority:'medium', days:1  },
  { id:9,  name:'Ravi Kumar',      phone:'+91-9811112222', event:'Birthday Party Nov 2025',    budget:200000, stage:'new',           priority:'low',    days:0  },
  { id:10, name:'Lakshmi Devi',    phone:'+91-9922334455', event:'Engagement Ceremony',        budget:350000, stage:'contacted',     priority:'high',   days:4  },
  { id:11, name:'Karthik Rajan',   phone:'+91-9733445566', event:'Wedding Mar 2026',           budget:2000000,stage:'negotiation',   priority:'high',   days:6  },
  { id:1,  name:'Vikram Patel',    phone:'+91-9876543214', event:'Wedding Nov 2025',           budget:1200000,stage:'won',           priority:'vip',    days:45 },
  { id:2,  name:'Ananya Krishnan', phone:'+91-9712345678', event:'Reception Dec 2025',         budget:600000, stage:'won',           priority:'high',   days:27 },
  { id:4,  name:'Meera Iyer',      phone:'+91-9934567890', event:'Grand Wedding Jan 2026',     budget:1800000,stage:'won',           priority:'vip',    days:71 },
  { id:7,  name:'Deepika Rao',     phone:'+91-9978901234', event:'Engagement Nov 2025',        budget:350000, stage:'won',           priority:'high',   days:8  },
];

export default function LeadsPage() {
  const navigate = useNavigate();
  const [leads, setLeads] = useState(ALL_LEADS);
  const [dragging, setDragging] = useState(null);

  const byStage = (stage) => leads.filter(l => l.stage === stage);
  const totalValue = (stage) => byStage(stage).reduce((s,l) => s+l.budget, 0);

  const moveToStage = (leadId, stage) => {
    setLeads(ls => ls.map(l => l.id === leadId ? {...l, stage} : l));
    toast.success(`Lead moved to ${stage.replace('_',' ')}`);
  };

  const pBadge = { vip:'gold', high:'purple', medium:'blue', low:'gray' };

  return (
    <div>
      <PageHeader title="Lead Management" subtitle="Track and nurture your sales pipeline">
        <Button variant="outline" size="sm">📊 Reports</Button>
        <Button size="sm" onClick={() => toast('Add lead form — same as adding a customer')}>+ Add Lead</Button>
      </PageHeader>

      {/* Summary */}
      <div className="grid grid-cols-6 gap-3 mb-6">
        {STAGES.map(s => (
          <div key={s.key} className="rounded-xl p-4 text-center" style={{background:'#19233e', border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif', fontSize:20, fontWeight:700, color:s.color}}>{byStage(s.key).length}</div>
            <div style={{fontSize:10, color:'#6b6458', marginTop:2, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{s.label}</div>
            <div style={{fontSize:10, color:'#6b6458', marginTop:2}}>{fmt.lakh(totalValue(s.key))}</div>
          </div>
        ))}
      </div>

      {/* Kanban */}
      <div className="overflow-x-auto pb-4">
        <div className="flex gap-4" style={{minWidth:1200}}>
          {STAGES.map(stage => (
            <div key={stage.key} className="flex-1" style={{minWidth:200}}>
              {/* Column Header */}
              <div className="rounded-xl p-3 mb-3 flex items-center justify-between"
                style={{background:stage.bg, border:`1px solid ${stage.color}30`}}>
                <div>
                  <div style={{fontSize:13, fontWeight:600, color:stage.color}}>{stage.label}</div>
                  <div style={{fontSize:11, color:'#6b6458'}}>{byStage(stage.key).length} leads</div>
                </div>
                <div style={{fontSize:11, color:'#6b6458'}}>{fmt.lakh(totalValue(stage.key))}</div>
              </div>

              {/* Cards */}
              <div
                className="min-h-32 space-y-3"
                onDragOver={e => e.preventDefault()}
                onDrop={e => {
                  e.preventDefault();
                  if (dragging) moveToStage(dragging, stage.key);
                  setDragging(null);
                }}>
                {byStage(stage.key).map(lead => (
                  <div
                    key={lead.id}
                    draggable
                    onDragStart={() => setDragging(lead.id)}
                    onDragEnd={() => setDragging(null)}
                    className="rounded-xl p-4 cursor-pointer transition-all select-none"
                    style={{background:'#19233e', border:'1px solid rgba(201,169,110,0.08)', opacity: dragging===lead.id ? 0.5 : 1}}
                    onMouseEnter={e => e.currentTarget.style.borderColor='rgba(201,169,110,0.25)'}
                    onMouseLeave={e => e.currentTarget.style.borderColor='rgba(201,169,110,0.08)'}
                    onClick={() => navigate(`/customers/${lead.id}`)}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Avatar name={lead.name} size={28} />
                        <div style={{fontSize:13, fontWeight:500, color:'#f2ede6'}}>{lead.name}</div>
                      </div>
                      <Badge color={pBadge[lead.priority]||'gray'} size="xs">{lead.priority}</Badge>
                    </div>
                    <div style={{fontSize:12, color:'#6b6458', marginBottom:6}}>{lead.event}</div>
                    <div className="flex justify-between items-center">
                      <span style={{fontSize:12, color:'#c9a96e', fontWeight:600}}>{fmt.lakh(lead.budget)}</span>
                      <span style={{fontSize:11, color:'#6b6458'}}>{lead.days}d ago</span>
                    </div>
                    {/* Quick move buttons */}
                    <div className="flex gap-1 mt-3">
                      {stage.key !== 'won' && (
                        <button
                          onClick={e => { e.stopPropagation(); moveToStage(lead.id, 'won'); }}
                          className="flex-1 text-xs py-1 rounded"
                          style={{background:'rgba(16,185,129,0.1)', color:'#10b981', border:'1px solid rgba(16,185,129,0.2)'}}>
                          → Won
                        </button>
                      )}
                      {stage.key !== 'new' && (
                        <button
                          onClick={e => { e.stopPropagation(); toast(`Calling ${lead.name}…`); }}
                          className="flex-1 text-xs py-1 rounded"
                          style={{background:'rgba(59,130,246,0.1)', color:'#60a5fa', border:'1px solid rgba(59,130,246,0.2)'}}>
                          📞 Call
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {byStage(stage.key).length === 0 && (
                  <div className="rounded-xl p-4 text-center"
                    style={{border:'2px dashed rgba(201,169,110,0.08)', color:'#6b6458', fontSize:12}}>
                    Drop leads here
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        <Card className="p-5">
          <div style={{fontSize:11, color:'#6b6458', marginBottom:4}}>TOTAL PIPELINE VALUE</div>
          <div style={{fontFamily:'Cinzel,serif', fontSize:24, fontWeight:700, color:'#c9a96e'}}>{fmt.currency(leads.reduce((s,l)=>s+l.budget,0))}</div>
        </Card>
        <Card className="p-5">
          <div style={{fontSize:11, color:'#6b6458', marginBottom:4}}>CONVERSION RATE</div>
          <div style={{fontFamily:'Cinzel,serif', fontSize:24, fontWeight:700, color:'#10b981'}}>
            {Math.round(leads.filter(l=>l.stage==='won').length/leads.length*100)}%
          </div>
        </Card>
        <Card className="p-5">
          <div style={{fontSize:11, color:'#6b6458', marginBottom:4}}>WON VALUE</div>
          <div style={{fontFamily:'Cinzel,serif', fontSize:24, fontWeight:700, color:'#10b981'}}>
            {fmt.currency(leads.filter(l=>l.stage==='won').reduce((s,l)=>s+l.budget,0))}
          </div>
        </Card>
      </div>
    </div>
  );
}
