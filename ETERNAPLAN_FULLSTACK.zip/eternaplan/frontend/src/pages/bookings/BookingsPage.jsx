import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { bookingService } from '../../services/services';
import { PageHeader, Card, Table, StatusBadge, Button, FilterTabs, Badge, PageSpinner, EmptyState, Pagination, Modal, Input, Select } from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

const STATUS_TABS = [
  {value:'', label:'All Bookings'},
  {value:'pending', label:'Pending'},
  {value:'confirmed', label:'Confirmed'},
  {value:'in_progress', label:'In Progress'},
  {value:'completed', label:'Completed'},
  {value:'cancelled', label:'Cancelled'},
];

export default function BookingsPage() {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ status:'', page:1 });
  const [addModal, setAddModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ booking_type:'vendor', event_id:'', vendor_id:'', booking_date:'', quoted_price:'', agreed_price:'', advance_amount:'' });

  const load = async (f = filters) => {
    setLoading(true);
    try {
      const r = await bookingService.list({...f, limit:20});
      setBookings(r.data.data.bookings);
      setPagination(r.data.data.pagination);
    } catch {
      setBookings(MOCK_BOOKINGS);
      setPagination({ page:1, limit:20, total:MOCK_BOOKINGS.length, pages:1 });
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    setSaving(true);
    try {
      await bookingService.create(form);
      toast.success('Booking created!');
      setAddModal(false);
      load();
    } catch { toast.error('Failed to create booking'); }
    finally { setSaving(false); }
  };

  const handleStatusChange = async (id, status) => {
    try {
      await bookingService.updateStatus(id, { status });
      toast.success(`Booking ${status}`);
      load();
    } catch { toast.error('Failed to update'); }
  };

  const columns = [
    { key:'booking_code', label:'Code', render:v=><span style={{color:'#c9a96e', fontWeight:700, fontFamily:'DM Sans,sans-serif'}}>{v}</span> },
    { key:'event_name', label:'Event', render:(v,r)=>(
      <div>
        <div style={{color:'#f2ede6', fontWeight:500, fontSize:13}}>{v}</div>
        <div style={{fontSize:11, color:'#6b6458'}}>{r.event_code}</div>
      </div>
    )},
    { key:'vendor_name', label:'Vendor / Venue', render:(v,r)=>(
      <div>
        <div style={{color:'#9ca3af'}}>{v||r.venue_name||'—'}</div>
        {r.vendor_category && <div style={{fontSize:11}}><Badge color="blue" size="xs">{r.vendor_category}</Badge></div>}
      </div>
    )},
    { key:'booking_date', label:'Date', render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span> },
    { key:'start_time', label:'Time', render:(v,r)=> v ? <span style={{color:'#9ca3af'}}>{fmt.time(v)} – {fmt.time(r.end_time)}</span> : <span style={{color:'#6b6458'}}>All day</span> },
    { key:'quoted_price', label:'Quoted', render:v=><span style={{color:'#6b6458'}}>{fmt.currency(v)}</span> },
    { key:'agreed_price', label:'Agreed', render:v=><span style={{color:'#f2ede6', fontWeight:600}}>{fmt.currency(v)}</span> },
    { key:'advance_amount', label:'Advance', render:v=><span style={{color:'#10b981'}}>{fmt.currency(v)}</span> },
    { key:'status', label:'Status', render:v=><StatusBadge type="booking" value={v}/> },
    { key:'id', label:'', render:(_,r)=>(
      <div className="flex gap-1">
        {r.status==='pending' && <Button variant="success" size="xs" onClick={e=>{e.stopPropagation();handleStatusChange(r.id,'confirmed');}}>Confirm</Button>}
        {r.status==='confirmed' && <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();handleStatusChange(r.id,'completed');}}>Complete</Button>}
        {!['cancelled','completed'].includes(r.status) && <Button variant="danger" size="xs" onClick={e=>{e.stopPropagation();handleStatusChange(r.id,'cancelled');}}>Cancel</Button>}
      </div>
    )},
  ];

  // Stats
  const confirmed = bookings.filter(b=>b.status==='confirmed').length;
  const pending = bookings.filter(b=>b.status==='pending').length;
  const totalValue = bookings.filter(b=>!['cancelled'].includes(b.status)).reduce((s,b)=>s+(+b.agreed_price||0),0);
  const advancePaid = bookings.filter(b=>!['cancelled'].includes(b.status)).reduce((s,b)=>s+(+b.advance_amount||0),0);

  return (
    <div>
      <PageHeader title="Bookings" subtitle="Vendor and venue booking management with conflict detection">
        <Button size="sm" onClick={() => setAddModal(true)}>+ New Booking</Button>
      </PageHeader>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[
          {l:'Total Bookings', v:bookings.length, c:'#f2ede6'},
          {l:'Confirmed', v:confirmed, c:'#10b981'},
          {l:'Pending Approval', v:pending, c:'#f59e0b'},
          {l:'Total Value', v:fmt.lakh(totalValue), c:'#c9a96e'},
        ].map(({l,v,c})=>(
          <div key={l} className="rounded-xl p-4" style={{background:'#19233e', border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif', fontSize:22, fontWeight:700, color:c, lineHeight:1.2}}>{v}</div>
            <div style={{fontSize:11, color:'#6b6458', marginTop:4}}>{l}</div>
          </div>
        ))}
      </div>

      <FilterTabs tabs={STATUS_TABS} active={filters.status}
        onChange={v=>{ const f={...filters,status:v,page:1}; setFilters(f); load(f); }} />

      <Card>
        {loading
          ? <div className="py-16"><PageSpinner /></div>
          : bookings.length===0
            ? <EmptyState icon="📋" title="No bookings found" action={<Button onClick={()=>setAddModal(true)}>+ Create Booking</Button>} />
            : <>
                <Table columns={columns} data={bookings} />
                <Pagination pagination={pagination} onChange={p=>{ const f={...filters,page:p}; setFilters(f); load(f); }} />
              </>
        }
      </Card>

      {/* Conflict Detection Notice */}
      <div className="mt-4 p-4 rounded-xl flex items-start gap-3"
        style={{background:'rgba(59,130,246,0.06)', border:'1px solid rgba(59,130,246,0.15)'}}>
        <span style={{fontSize:18}}>🛡️</span>
        <div>
          <div style={{fontSize:13, fontWeight:600, color:'#60a5fa', marginBottom:4}}>Automatic Conflict Detection Active</div>
          <div style={{fontSize:12, color:'#6b6458'}}>
            EternaPlaan automatically checks venue availability when creating bookings. If a venue is already booked for the selected date and time slot, you will receive a conflict warning before confirmation.
          </div>
        </div>
      </div>

      {/* New Booking Modal */}
      <Modal open={addModal} onClose={() => setAddModal(false)} title="✦ Create New Booking" size="lg">
        <div className="grid grid-cols-2 gap-4">
          <Select label="Booking Type" value={form.booking_type} onChange={e=>setForm(f=>({...f,booking_type:e.target.value}))}
            options={[{value:'vendor',label:'Vendor Booking'},{value:'venue',label:'Venue Booking'}]} />
          <Input label="Booking Date *" type="date" value={form.booking_date} onChange={e=>setForm(f=>({...f,booking_date:e.target.value}))} />
          <Input label="Start Time" type="time" onChange={e=>setForm(f=>({...f,start_time:e.target.value}))} />
          <Input label="End Time" type="time" onChange={e=>setForm(f=>({...f,end_time:e.target.value}))} />
          <Input label="Quoted Price (₹)" type="number" value={form.quoted_price} onChange={e=>setForm(f=>({...f,quoted_price:e.target.value}))} placeholder="200000" />
          <Input label="Agreed Price (₹)" type="number" value={form.agreed_price} onChange={e=>setForm(f=>({...f,agreed_price:e.target.value}))} placeholder="180000" />
          <Input label="Advance Amount (₹)" type="number" value={form.advance_amount} onChange={e=>setForm(f=>({...f,advance_amount:e.target.value}))} placeholder="50000" className="col-span-2" />
        </div>
        <div className="mt-3 p-3 rounded-lg" style={{background:'rgba(201,169,110,0.06)', border:'1px solid rgba(201,169,110,0.12)'}}>
          <div style={{fontSize:12, color:'#9ca3af'}}>
            💡 <strong style={{color:'#c9a96e'}}>Tip:</strong> Balance amount = Agreed Price – Advance Amount = <strong style={{color:'#f2ede6'}}>{fmt.currency((+form.agreed_price||0)-(+form.advance_amount||0))}</strong>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={() => setAddModal(false)}>Cancel</Button>
          <Button onClick={handleCreate} loading={saving}>Create Booking</Button>
        </div>
      </Modal>
    </div>
  );
}

const MOCK_BOOKINGS = [
  {id:1,booking_code:'BK-2025-0001',event_id:1,event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',vendor_name:'Star Catering Services',vendor_category:'Catering',booking_date:'2025-11-15',start_time:'07:00:00',end_time:'22:00:00',quoted_price:200000,agreed_price:180000,advance_amount:50000,status:'confirmed'},
  {id:2,booking_code:'BK-2025-0002',event_id:1,event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',vendor_name:'Pixel Perfect Photography',vendor_category:'Photography',booking_date:'2025-11-15',start_time:'08:00:00',end_time:'22:00:00',quoted_price:100000,agreed_price:95000,advance_amount:30000,status:'confirmed'},
  {id:3,booking_code:'BK-2025-0003',event_id:1,event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',vendor_name:'Dream Decor Studio',vendor_category:'Decoration',booking_date:'2025-11-14',start_time:'09:00:00',end_time:'18:00:00',quoted_price:80000,agreed_price:75000,advance_amount:25000,status:'confirmed'},
  {id:4,booking_code:'BK-2025-0004',event_id:1,event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',vendor_name:'Glamour House Makeup',vendor_category:'Makeup',booking_date:'2025-11-15',start_time:'05:00:00',end_time:'10:00:00',quoted_price:20000,agreed_price:18000,advance_amount:8000,status:'confirmed'},
  {id:5,booking_code:'BK-2025-0005',event_id:2,event_name:'Ananya & Kiran Reception',event_code:'EVT-2025-0002',vendor_name:'Star Catering Services',vendor_category:'Catering',booking_date:'2025-12-05',quoted_price:90000,agreed_price:80000,advance_amount:20000,status:'pending'},
  {id:6,booking_code:'BK-2025-0006',event_id:2,event_name:'Ananya & Kiran Reception',event_code:'EVT-2025-0002',vendor_name:'Cinematic Tales Videography',vendor_category:'Videography',booking_date:'2025-12-05',quoted_price:60000,agreed_price:55000,advance_amount:15000,status:'pending'},
  {id:7,booking_code:'BK-2025-0007',event_id:4,event_name:'Kavya Birthday 30th',event_code:'EVT-2025-0004',vendor_name:'Star Catering Services',vendor_category:'Catering',booking_date:'2025-10-20',quoted_price:90000,agreed_price:85000,advance_amount:85000,status:'completed'},
  {id:8,booking_code:'BK-2025-0008',event_id:4,event_name:'Kavya Birthday 30th',event_code:'EVT-2025-0004',vendor_name:'Beat Masters DJ',vendor_category:'DJ & Music',booking_date:'2025-10-20',quoted_price:25000,agreed_price:22000,advance_amount:22000,status:'completed'},
];
