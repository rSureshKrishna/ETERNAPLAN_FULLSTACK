export { ReportsPage as default } from '../RemainingPages';
