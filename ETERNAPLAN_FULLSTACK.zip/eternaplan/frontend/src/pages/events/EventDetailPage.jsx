import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { eventService } from '../../services/services';
import {
  PageHeader, Card, CardHeader, Table, StatusBadge, Button,
  Badge, Progress, StatRow, Modal, Input, Select,
  EmptyState, PageSpinner
} from '../../components/common';
import { fmt, STATUS } from '../../utils/helpers';
import toast from 'react-hot-toast';

const TABS = ['Overview','Tasks','Bookings','Guests','Financials','Timeline'];

export default function EventDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tab, setTab] = useState('Overview');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [taskModal, setTaskModal] = useState(false);
  const [taskForm, setTaskForm] = useState({ title:'', category:'', priority:'medium', due_date:'' });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const r = await eventService.get(id); setData(r.data.data); }
    catch { setData(MOCK); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [id]);

  const completeTask = async (taskId) => {
    try { await eventService.updateTask(id, taskId, { status:'completed' }); toast.success('Task done ✅'); load(); }
    catch { toast.error('Failed'); }
  };

  const addTask = async () => {
    setSaving(true);
    try { await eventService.createTask(id, taskForm); toast.success('Task added!'); setTaskModal(false); setTaskForm({ title:'',category:'',priority:'medium',due_date:'' }); load(); }
    catch { toast.error('Failed'); }
    finally { setSaving(false); }
  };

  if (loading) return <PageSpinner />;
  if (!data) return <EmptyState icon="💐" title="Event not found" />;

  const { event, tasks=[], bookings=[], guest_summary=[], financials={} } = data;
  const rsvp = guest_summary.reduce((a,g)=>({...a,[g.rsvp_status]:+g.count}),{});
  const doneCount = tasks.filter(t=>t.status==='completed').length;
  const pct = tasks.length ? Math.round(doneCount/tasks.length*100) : 0;

  return (
    <div>
      <PageHeader title={event.event_name} subtitle={`${event.event_code} · ${fmt.date(event.event_date)} · ${event.category||'Event'}`}>
        <Button variant="outline" size="sm" onClick={()=>navigate('/events')}>← Events</Button>
        <select className="input-dark text-sm" style={{width:155,padding:'8px 12px'}} value={event.status}
          onChange={e=>eventService.update(id,{status:e.target.value}).then(()=>{toast.success('Status updated');load();}).catch(()=>toast.error('Failed'))}>
          {Object.keys(STATUS.event).map(s=><option key={s} value={s} style={{background:'#141d35'}}>{STATUS.event[s].label}</option>)}
        </select>
        <Button size="sm" onClick={()=>toast('Edit event form')}>Edit Event</Button>
      </PageHeader>

      {/* KPI strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
        {[
          {l:'Event Date',v:fmt.date(event.event_date),c:'#c9a96e'},
          {l:'Guests',v:fmt.number(event.guest_count_estimate),c:'#f2ede6'},
          {l:'Budget',v:fmt.lakh(event.budget_total),c:'#f2ede6'},
          {l:'Spent',v:fmt.lakh(event.budget_spent),c:'#f59e0b'},
          {l:'Balance Due',v:fmt.lakh(event.balance_due),c:event.balance_due>0?'#ef4444':'#10b981'},
        ].map(({l,v,c})=>(
          <div key={l} className="rounded-xl p-4" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
            <div style={{fontFamily:'Cinzel,serif',fontSize:20,fontWeight:700,color:c,lineHeight:1.2}}>{v}</div>
            <div style={{fontSize:11,color:'#6b6458',marginTop:4}}>{l}</div>
          </div>
        ))}
      </div>

      {/* Progress */}
      <div className="rounded-xl p-5 mb-5" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}>
        <div className="flex justify-between mb-2">
          <span style={{fontSize:13,color:'#9ca3af'}}>Overall Event Progress</span>
          <span style={{fontSize:13,fontWeight:600,color:'#c9a96e'}}>{pct}%</span>
        </div>
        <Progress value={pct} height={8}/>
        <div className="flex gap-5 mt-3">
          {[{l:'Completed',n:doneCount,c:'#10b981'},{l:'In Progress',n:tasks.filter(t=>t.status==='in_progress').length,c:'#3b82f6'},{l:'Pending',n:tasks.filter(t=>t.status==='pending').length,c:'#6b6458'},{l:'Critical',n:tasks.filter(t=>t.priority==='critical'&&t.status!=='completed').length,c:'#ef4444'}].map(({l,n,c})=>(
            <div key={l} className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full" style={{background:c}}/>
              <span style={{fontSize:12,color:'#9ca3af'}}>{n} {l}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-0 mb-5" style={{borderBottom:'1px solid rgba(201,169,110,0.08)'}}>
        {TABS.map(t=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{padding:'10px 20px',fontSize:13.5,fontWeight:500,background:'transparent',border:'none',cursor:'pointer',
              color:tab===t?'#c9a96e':'#6b6458',borderBottom:tab===t?'2px solid #c9a96e':'2px solid transparent',marginBottom:-1,transition:'color .2s'}}>
            {t}
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab==='Overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-5">
            <Card>
              <CardHeader title="Event Details"/>
              <div className="p-5 grid grid-cols-2 gap-x-8 gap-y-4">
                {[['Customer',`${event.customer_name} · ${event.customer_phone||''}`],['Category',event.category||'—'],['Event Date',fmt.date(event.event_date)],['Venue',event.venue_name||'—'],['Theme',event.theme||'—'],['Color Scheme',event.color_scheme||'—'],['Dress Code',event.dress_code||'—'],['Assigned Manager',event.assigned_to_name||'—']].map(([l,v])=>(
                  <div key={l}><div style={{fontSize:11,color:'#6b6458',marginBottom:2}}>{l}</div><div style={{fontSize:13,color:'#f2ede6'}}>{v||'—'}</div></div>
                ))}
              </div>
              {event.notes&&<div className="px-5 pb-4"><div style={{fontSize:11,color:'#6b6458',marginBottom:4}}>Notes</div><div style={{fontSize:13,color:'#9ca3af',lineHeight:1.6}}>{event.notes}</div></div>}
            </Card>
            <Card>
              <CardHeader title="Recent Tasks" action={<Button size="xs" onClick={()=>setTab('Tasks')}>All Tasks</Button>}/>
              <div className="p-3">
                {tasks.slice(0,5).map(t=>(
                  <div key={t.id} className="flex items-center gap-3 px-2 py-2.5" style={{borderBottom:'1px solid rgba(201,169,110,0.04)'}}>
                    <div onClick={()=>completeTask(t.id)} className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 cursor-pointer transition-all"
                      style={{border:`2px solid ${t.status==='completed'?'#c9a96e':'#3a3028'}`,background:t.status==='completed'?'#c9a96e':'transparent',color:'#030508',fontSize:10}}>
                      {t.status==='completed'&&'✓'}
                    </div>
                    <div className="flex-1">
                      <div style={{fontSize:13,color:t.status==='completed'?'#6b6458':'#f2ede6',textDecoration:t.status==='completed'?'line-through':'none'}}>{t.title}</div>
                      <div style={{fontSize:11,color:'#6b6458'}}>{t.category} · Due {fmt.date(t.due_date)}</div>
                    </div>
                    <Badge color={{critical:'red',high:'amber',medium:'blue',low:'gray'}[t.priority]||'gray'} size="xs">{t.priority}</Badge>
                  </div>
                ))}
                {tasks.length===0&&<EmptyState icon="✓" title="No tasks yet"/>}
              </div>
            </Card>
          </div>
          <div className="space-y-5">
            <Card>
              <CardHeader title="Guest RSVP"/>
              <div className="px-5 pb-3">
                <StatRow label="👥 Total Invited" value={guest_summary.reduce((s,g)=>s+(+g.count),0)}/>
                <StatRow label="✅ Attending" value={rsvp.attending||0} valueColor="#10b981"/>
                <StatRow label="❌ Declined" value={rsvp.not_attending||0} valueColor="#ef4444"/>
                <StatRow label="❓ Maybe" value={rsvp.maybe||0} valueColor="#f59e0b"/>
                <StatRow label="⏳ Pending RSVP" value={rsvp.pending||0}/>
              </div>
              <div className="px-5 pb-4"><Button variant="outline" className="w-full justify-center" size="sm" onClick={()=>setTab('Guests')}>Manage Guests</Button></div>
            </Card>
            <Card>
              <CardHeader title="Financials"/>
              <div className="px-5 pb-3">
                <StatRow label="Budget" value={fmt.currency(event.budget_total)}/>
                <StatRow label="Spent" value={fmt.currency(event.budget_spent)} valueColor="#f59e0b"/>
                <StatRow label="Received" value={fmt.currency(event.advance_paid)} valueColor="#10b981"/>
                <StatRow label="Balance Due" value={fmt.currency(event.balance_due)} valueColor={event.balance_due>0?'#ef4444':'#10b981'}/>
                <div className="mt-3"><Progress value={Math.round(event.budget_spent/Math.max(event.budget_total,1)*100)}/></div>
              </div>
            </Card>
            <Card>
              <CardHeader title="Quick Actions"/>
              <div className="p-4 space-y-2">
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>setTaskModal(true)}>➕ Add Task</Button>
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>setTab('Bookings')}>📋 Bookings</Button>
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Invoice generated')}>📄 Generate Invoice</Button>
                <Button variant="outline" className="w-full justify-start" size="sm" onClick={()=>toast('Reminders sent via WhatsApp')}>📱 Send Reminders</Button>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* TASKS */}
      {tab==='Tasks' && (
        <div>
          <div className="flex justify-between mb-4">
            <span style={{fontSize:14,color:'#9ca3af'}}>{tasks.length} tasks · {doneCount} completed</span>
            <Button size="sm" onClick={()=>setTaskModal(true)}>+ Add Task</Button>
          </div>
          <Card>
            <Table columns={[
              {key:'title',label:'Task',render:(v,r)=>(
                <div className="flex items-center gap-3">
                  <div onClick={()=>completeTask(r.id)} className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 cursor-pointer"
                    style={{border:`2px solid ${r.status==='completed'?'#c9a96e':'#3a3028'}`,background:r.status==='completed'?'#c9a96e':'transparent',color:'#030508',fontSize:10}}>
                    {r.status==='completed'&&'✓'}
                  </div>
                  <div>
                    <div style={{fontSize:13,color:r.status==='completed'?'#6b6458':'#f2ede6',textDecoration:r.status==='completed'?'line-through':'none'}}>{v}</div>
                    {r.assignee_name&&<div style={{fontSize:11,color:'#6b6458'}}>→ {r.assignee_name}</div>}
                  </div>
                </div>
              )},
              {key:'category',label:'Category',render:v=><Badge color="blue" size="xs">{v||'—'}</Badge>},
              {key:'priority',label:'Priority',render:v=><Badge color={{critical:'red',high:'amber',medium:'blue',low:'gray'}[v]||'gray'}>{v}</Badge>},
              {key:'status',label:'Status',render:v=><StatusBadge type="task" value={v}/>},
              {key:'due_date',label:'Due',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
              {key:'id',label:'',render:(_,r)=>(
                <div className="flex gap-1">
                  {r.status!=='completed'&&<Button variant="success" size="xs" onClick={()=>completeTask(r.id)}>✓</Button>}
                  <Button variant="outline" size="xs" onClick={()=>toast('Edit task')}>Edit</Button>
                </div>
              )},
            ]} data={tasks} emptyMessage="No tasks yet. Add tasks to track progress."/>
          </Card>
        </div>
      )}

      {/* BOOKINGS */}
      {tab==='Bookings' && (
        <div>
          <div className="flex justify-between mb-4">
            <span style={{fontSize:14,color:'#9ca3af'}}>{bookings.length} bookings</span>
            <Button size="sm" onClick={()=>toast('New booking form')}>+ Add Booking</Button>
          </div>
          <Card>
            <Table columns={[
              {key:'booking_code',label:'Code',render:v=><span style={{color:'#c9a96e',fontWeight:600}}>{v}</span>},
              {key:'vendor_name',label:'Vendor',render:(v,r)=><div><div style={{color:'#f2ede6'}}>{v||r.venue_name||'—'}</div><div style={{fontSize:11,color:'#6b6458'}}>{r.vendor_category}</div></div>},
              {key:'booking_date',label:'Date',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
              {key:'quoted_price',label:'Quoted',render:v=><span style={{color:'#6b6458'}}>{fmt.currency(v)}</span>},
              {key:'agreed_price',label:'Agreed',render:v=><span style={{color:'#f2ede6',fontWeight:600}}>{fmt.currency(v)}</span>},
              {key:'advance_amount',label:'Advance',render:v=><span style={{color:'#10b981'}}>{fmt.currency(v)}</span>},
              {key:'status',label:'Status',render:v=><StatusBadge type="booking" value={v}/>},
            ]} data={bookings} emptyMessage="No bookings yet for this event."/>
          </Card>
        </div>
      )}

      {/* GUESTS */}
      {tab==='Guests' && (
        <div>
          <div className="flex justify-between mb-4">
            <div className="flex gap-4">
              {[['Attending',rsvp.attending||0,'#10b981'],['Maybe',rsvp.maybe||0,'#f59e0b'],['Declined',rsvp.not_attending||0,'#ef4444'],['Pending',rsvp.pending||0,'#6b6458']].map(([l,n,c])=>(
                <div key={l} className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full" style={{background:c}}/><span style={{fontSize:13,color:'#9ca3af'}}>{n} {l}</span></div>
              ))}
            </div>
            <Button size="sm" onClick={()=>toast('Add guest form')}>+ Add Guest</Button>
          </div>
          <Card><EmptyState icon="👥" title="Guest list available" description="Open Guest Management for full list with check-in and RSVP tools." action={<Button onClick={()=>navigate('/guests')}>Open Guest Manager →</Button>}/></Card>
        </div>
      )}

      {/* FINANCIALS */}
      {tab==='Financials' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <Card>
            <CardHeader title="P&L Summary"/>
            <div className="px-5 pb-4">
              <StatRow label="Total Budget" value={fmt.currency(event.budget_total)}/>
              <StatRow label="Total Expenses" value={fmt.currency(event.budget_spent)} valueColor="#f59e0b"/>
              <StatRow label="Revenue Received" value={fmt.currency(event.advance_paid)} valueColor="#10b981"/>
              <div className="h-px my-3" style={{background:'rgba(201,169,110,0.08)'}}/>
              <StatRow label="Net Profit / Loss" value={fmt.currency(event.advance_paid - event.budget_spent)} valueColor={(event.advance_paid-event.budget_spent)>=0?'#10b981':'#ef4444'}/>
              <StatRow label="Balance Due from Client" value={fmt.currency(event.balance_due)} valueColor={event.balance_due>0?'#ef4444':'#10b981'}/>
            </div>
          </Card>
          <Card>
            <CardHeader title="Booking Allocation"/>
            <div className="px-5 pb-4">
              {bookings.map(b=>(
                <div key={b.id} className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span style={{fontSize:13,color:'#9ca3af'}}>{b.vendor_name||b.venue_name}</span>
                    <span style={{fontSize:13,color:'#f2ede6',fontWeight:600}}>{fmt.currency(b.agreed_price)}</span>
                  </div>
                  <Progress value={Math.round(b.agreed_price/Math.max(event.budget_total,1)*100)} height={4}/>
                  <div style={{fontSize:11,color:'#6b6458',marginTop:2}}>{Math.round(b.agreed_price/Math.max(event.budget_total,1)*100)}% of budget</div>
                </div>
              ))}
              {bookings.length===0&&<EmptyState icon="💰" title="No bookings yet"/>}
            </div>
          </Card>
        </div>
      )}

      {/* TIMELINE */}
      {tab==='Timeline' && (
        <Card>
          <CardHeader title="Event Timeline"/>
          <div className="p-6">
            <div className="relative pl-6">
              <div className="absolute left-2 top-0 bottom-0 w-px" style={{background:'rgba(201,169,110,0.15)'}}/>
              {MOCK_TIMELINE.map((item,i)=>(
                <div key={i} className="relative mb-6">
                  <div className="absolute -left-4 top-1.5 w-3 h-3 rounded-full" style={{background:item.done?'#c9a96e':'#19233e',border:'2px solid rgba(201,169,110,0.4)'}}/>
                  <div style={{fontSize:11,color:'#6b6458',marginBottom:2}}>{item.time}</div>
                  <div style={{fontSize:14,fontWeight:500,color:item.done?'#6b6458':'#f2ede6',textDecoration:item.done?'line-through':'none'}}>{item.title}</div>
                  {item.desc&&<div style={{fontSize:12,color:'#6b6458',marginTop:2}}>{item.desc}</div>}
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* Add Task Modal */}
      <Modal open={taskModal} onClose={()=>setTaskModal(false)} title="✦ Add Task">
        <Input label="Task Title" value={taskForm.title} onChange={e=>setTaskForm(f=>({...f,title:e.target.value}))} placeholder="e.g., Confirm catering menu"/>
        <div className="grid grid-cols-2 gap-4">
          <Select label="Category" value={taskForm.category} onChange={e=>setTaskForm(f=>({...f,category:e.target.value}))}
            options={[{value:'',label:'Select…'},{value:'Catering',label:'Catering'},{value:'Decoration',label:'Decoration'},{value:'Photography',label:'Photography'},{value:'Guest Mgmt',label:'Guest Management'},{value:'Venue',label:'Venue'},{value:'Beauty',label:'Beauty'},{value:'Entertainment',label:'Entertainment'},{value:'Finance',label:'Finance'},{value:'Other',label:'Other'}]}/>
          <Select label="Priority" value={taskForm.priority} onChange={e=>setTaskForm(f=>({...f,priority:e.target.value}))}
            options={[{value:'low',label:'Low'},{value:'medium',label:'Medium'},{value:'high',label:'High'},{value:'critical',label:'🔴 Critical'}]}/>
          <Input label="Due Date" type="date" value={taskForm.due_date} onChange={e=>setTaskForm(f=>({...f,due_date:e.target.value}))}/>
          <Input label="Due Time (optional)" type="time"/>
        </div>
        <Textarea label="Notes (optional)" placeholder="Additional context…"/>
        <div className="flex justify-end gap-3 mt-2">
          <Button variant="outline" onClick={()=>setTaskModal(false)}>Cancel</Button>
          <Button onClick={addTask} loading={saving} disabled={!taskForm.title}>Add Task ✦</Button>
        </div>
      </Modal>
    </div>
  );
}

import { Textarea } from '../../components/common';

const MOCK = {
  event:{id:1,event_code:'EVT-2025-0001',event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',event_time:'09:00:00',status:'confirmed',category:'Wedding',theme:'Royal Gold & Ivory',color_scheme:'Gold, Ivory, Blush Pink',dress_code:'Indian Formal',customer_name:'Vikram Patel',customer_phone:'+91-9876543214',venue_name:'The Grand Palace Banquet',assigned_to_name:'Rahul Menon',guest_count_estimate:500,budget_total:1200000,budget_spent:420000,advance_paid:300000,balance_due:134240,completion_pct:68,notes:'Client prefers vegetarian catering for majority of guests.'},
  tasks:[
    {id:1,title:'Confirm catering menu',category:'Catering',priority:'high',status:'completed',due_date:'2025-09-15',assignee_name:'Rahul Menon'},
    {id:2,title:'Finalize decoration theme',category:'Decoration',priority:'high',status:'completed',due_date:'2025-09-20',assignee_name:'Sneha Krishnan'},
    {id:3,title:'Send invitations to 500 guests',category:'Guest Mgmt',priority:'critical',status:'in_progress',due_date:'2025-10-01',assignee_name:'Rahul Menon'},
    {id:4,title:'Arrange mehendi artist',category:'Beauty',priority:'medium',status:'pending',due_date:'2025-10-15'},
    {id:5,title:'Coordinate DJ & Music setup',category:'Entertainment',priority:'medium',status:'pending',due_date:'2025-10-20'},
    {id:6,title:'Book baraat vehicles',category:'Transportation',priority:'high',status:'pending',due_date:'2025-10-25'},
    {id:7,title:'Wedding cake confirmation',category:'Catering',priority:'high',status:'pending',due_date:'2025-11-01'},
  ],
  bookings:[
    {id:1,booking_code:'BK-2025-0001',vendor_name:'Star Catering Services',vendor_category:'Catering',booking_date:'2025-11-15',quoted_price:200000,agreed_price:180000,advance_amount:50000,status:'confirmed'},
    {id:2,booking_code:'BK-2025-0002',vendor_name:'Pixel Perfect Photography',vendor_category:'Photography',booking_date:'2025-11-15',quoted_price:100000,agreed_price:95000,advance_amount:30000,status:'confirmed'},
    {id:3,booking_code:'BK-2025-0003',vendor_name:'Dream Decor Studio',vendor_category:'Decoration',booking_date:'2025-11-15',quoted_price:80000,agreed_price:75000,advance_amount:25000,status:'confirmed'},
    {id:4,booking_code:'BK-2025-0004',vendor_name:'Glamour House Makeup',vendor_category:'Makeup',booking_date:'2025-11-15',quoted_price:20000,agreed_price:18000,advance_amount:8000,status:'confirmed'},
  ],
  guest_summary:[{rsvp_status:'attending',count:120},{rsvp_status:'pending',count:320},{rsvp_status:'maybe',count:40},{rsvp_status:'not_attending',count:20}],
  financials:{},
};

const MOCK_TIMELINE=[
  {time:'Sep 1, 2025',title:'Event Created & Contract Signed',desc:'Initial deposit ₹3,00,000 received',done:true},
  {time:'Sep 10, 2025',title:'Venue Confirmed',desc:'The Grand Palace Banquet booked',done:true},
  {time:'Sep 15, 2025',title:'Catering & Photography Booked',done:true},
  {time:'Oct 1, 2025',title:'Guest Invitations Dispatched',desc:'500 QR invitations sent via WhatsApp',done:false},
  {time:'Oct 15, 2025',title:'RSVP Deadline',done:false},
  {time:'Nov 14, 2025',title:'Venue Setup & Rehearsal',done:false},
  {time:'Nov 15 · 9:00 AM',title:'Wedding Ceremony',desc:'Main event — 500 guests',done:false},
  {time:'Nov 15 · 7:00 PM',title:'Reception & Dinner',done:false},
  {time:'Nov 16, 2025',title:'Final Billing & Project Closure',done:false},
];
