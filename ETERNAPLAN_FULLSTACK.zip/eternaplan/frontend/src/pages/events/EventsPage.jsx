import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { eventService } from '../../services/services';
import { PageHeader, Card, Table, StatusBadge, Button, FilterTabs, Progress, Badge, Pagination, EmptyState, PageSpinner } from '../../components/common';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

const STATUS_TABS = [
  { value: '', label: 'All Events' },
  { value: 'inquiry', label: 'Inquiry' },
  { value: 'planning', label: 'Planning' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
];

export default function EventsPage() {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ status: '', search: '', page: 1 });

  const load = async (f = filters) => {
    setLoading(true);
    try {
      const r = await eventService.list({ ...f, limit: 15 });
      setEvents(r.data.data.events);
      setPagination(r.data.data.pagination);
    } catch {
      setEvents(MOCK_EVENTS);
      setPagination({ page:1, limit:15, total: MOCK_EVENTS.length, pages:1 });
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const columns = [
    { key: 'event_name', label: 'Event', render: (v, row) => (
      <div>
        <div className="font-medium" style={{color:'#f2ede6'}}>{v}</div>
        <div className="text-xs mt-0.5" style={{color:'#6b6458'}}>{row.event_code} · {row.category}</div>
      </div>
    )},
    { key: 'customer_name', label: 'Customer', render: (v, row) => (
      <div>
        <div style={{color:'#f2ede6'}}>{v}</div>
        <div className="text-xs" style={{color:'#6b6458'}}>{row.customer_phone}</div>
      </div>
    )},
    { key: 'event_date', label: 'Event Date', render: (v, row) => (
      <div>
        <div style={{color:'#f2ede6'}}>{fmt.date(v)}</div>
        <div className="text-xs" style={{color:'#6b6458'}}>{row.event_time?.substring(0,5) || ''}</div>
      </div>
    )},
    { key: 'venue_name', label: 'Venue', render: (v) => <span style={{color:'#9ca3af'}}>{v || '—'}</span> },
    { key: 'guest_count_estimate', label: 'Guests', render: (v) => <span style={{color:'#f2ede6'}}>{fmt.number(v)}</span> },
    { key: 'budget_total', label: 'Budget', render: (v, row) => (
      <div>
        <div style={{color:'#f2ede6'}}>{fmt.lakh(v)}</div>
        <div className="text-xs" style={{color:'#6b6458'}}>Spent: {fmt.lakh(row.budget_spent)}</div>
      </div>
    )},
    { key: 'completion_pct', label: 'Progress', render: (v) => (
      <div className="flex items-center gap-2" style={{minWidth:90}}>
        <Progress value={v} className="flex-1"/>
        <span className="text-xs flex-shrink-0" style={{color:'#6b6458'}}>{v}%</span>
      </div>
    )},
    { key: 'status', label: 'Status', render: (v) => <StatusBadge type="event" value={v}/> },
    { key: 'id', label: '', render: (_, row) => (
      <div className="flex gap-1">
        <Button variant="outline" size="xs" onClick={(e)=>{e.stopPropagation();navigate(`/events/${row.id}`)}}>View</Button>
        <Button variant="outline" size="xs" onClick={(e)=>{e.stopPropagation();navigate(`/events/${row.id}?edit=1`)}}>Edit</Button>
      </div>
    )},
  ];

  return (
    <div>
      <PageHeader title="Events" subtitle="Manage all event planning workflows">
        <Button variant="outline" size="sm">📥 Export</Button>
        <Button size="sm" onClick={()=>navigate('/events/new')}>+ Create Event</Button>
      </PageHeader>

      <FilterTabs tabs={STATUS_TABS} active={filters.status}
        onChange={(v)=>{ const f={...filters,status:v,page:1}; setFilters(f); load(f); }}/>

      <div className="flex gap-3 mb-4">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg flex-1 max-w-xs"
          style={{background:'#141d35',border:'1px solid rgba(201,169,110,0.08)'}}>
          <span style={{color:'#6b6458'}}>🔍</span>
          <input className="bg-transparent border-none outline-none text-sm flex-1"
            style={{color:'#f2ede6'}} placeholder="Search events, customers..."
            value={filters.search}
            onChange={e=>{const f={...filters,search:e.target.value,page:1};setFilters(f);load(f);}}/>
        </div>
        <select className="input-dark" style={{width:150}}
          onChange={e=>{ const f={...filters,sort:e.target.value}; setFilters(f); load(f); }}>
          <option value="event_date">Sort: Event Date</option>
          <option value="created_at">Sort: Created</option>
          <option value="budget_total">Sort: Budget</option>
        </select>
      </div>

      <Card>
        {loading ? <div className="py-12"><PageSpinner/></div> :
          events.length === 0 ? <EmptyState icon="💐" title="No events found" description="Create your first event to get started."/> :
          <>
            <Table columns={columns} data={events} onRowClick={(row)=>navigate(`/events/${row.id}`)}/>
            <Pagination pagination={pagination} onChange={p=>{ const f={...filters,page:p}; setFilters(f); load(f); }}/>
          </>
        }
      </Card>
    </div>
  );
}

const MOCK_EVENTS = [
  {id:1,event_code:'EVT-2025-0001',event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',event_time:'09:00',customer_name:'Vikram Patel',customer_phone:'+91-9876543214',venue_name:'Grand Palace Banquet',category:'Wedding',status:'confirmed',guest_count_estimate:500,budget_total:1200000,budget_spent:420000,completion_pct:68},
  {id:2,event_code:'EVT-2025-0002',event_name:'Ananya & Kiran Reception',event_date:'2025-12-05',event_time:'19:00',customer_name:'Ananya Krishnan',customer_phone:'+91-9712345678',venue_name:'Coastal Breeze Garden',category:'Reception',status:'planning',guest_count_estimate:300,budget_total:600000,budget_spent:150000,completion_pct:32},
  {id:3,event_code:'EVT-2025-0003',event_name:'Meera & Arjun Grand Wedding',event_date:'2026-01-18',event_time:'08:00',customer_name:'Meera Iyer',customer_phone:'+91-9934567890',venue_name:'Jade Convention Center',category:'Wedding',status:'confirmed',guest_count_estimate:800,budget_total:1800000,budget_spent:500000,completion_pct:25},
  {id:4,event_code:'EVT-2025-0004',event_name:'Kavya Birthday 30th',event_date:'2025-10-20',event_time:'18:00',customer_name:'Kavya Nambiar',customer_phone:'+91-9756789012',venue_name:'Bloom Garden Lawn',category:'Birthday',status:'completed',guest_count_estimate:150,budget_total:250000,budget_spent:248000,completion_pct:100},
  {id:5,event_code:'EVT-2025-0005',event_name:'TechSol Corporate Gala',event_date:'2025-12-20',event_time:'18:00',customer_name:'Aditya Singh',customer_phone:'+91-9645678901',venue_name:'Jade Convention Center',category:'Corporate',status:'planning',guest_count_estimate:400,budget_total:800000,budget_spent:200000,completion_pct:18},
  {id:6,event_code:'EVT-2025-0006',event_name:'Deepika & Rahul Engagement',event_date:'2025-11-01',event_time:'17:00',customer_name:'Deepika Rao',customer_phone:'+91-9978901234',venue_name:'Grand Palace Banquet',category:'Engagement',status:'in_progress',guest_count_estimate:200,budget_total:350000,budget_spent:180000,completion_pct:55},
];
