import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { eventService, metaService } from '../../services/services';
import { PageHeader, Card, CardHeader, Input, Select, Textarea, Button, PageSpinner } from '../../components/common';
import { INDIAN_STATES } from '../../utils/helpers';
import toast from 'react-hot-toast';

const THEMES = ['Royal Gold & Ivory','Midnight Blue & Silver','Pastel Pink & Rose Gold','Red & Gold Traditional','Garden Floral','Rustic Bohemian','Modern Minimalist','Royal Maroon & Gold','Champagne & Blush','White & Platinum'];
const DRESS_CODES = ['Indian Formal','Western Formal','Indo-Western','Traditional Saree/Sherwani','Cocktail Attire','Black Tie','Casual Ethnic','No Dress Code'];

export default function CreateEventPage() {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [categories, setCategories] = useState([]);
  const [venues, setVenues] = useState([]);
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    event_name:'', category_id:'', venue_id:'',
    customer_first_name:'', customer_last_name:'', customer_phone:'', customer_email:'',
    event_date:'', event_time:'09:00', end_date:'', end_time:'22:00',
    guest_count_estimate:'', theme:'', color_scheme:'', dress_code:'',
    budget_total:'', special_requirements:'', notes:'',
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    Promise.all([metaService.categories(), metaService.venues()])
      .then(([c, v]) => { setCategories(c.data.data); setVenues(v.data.data); })
      .catch(() => { setCategories(MOCK_CATS); setVenues(MOCK_VENUES); });
  }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const validate = () => {
    const e = {};
    if (!form.event_name.trim()) e.event_name = 'Event name is required';
    if (!form.customer_phone.trim()) e.customer_phone = 'Customer phone is required';
    if (!form.event_date) e.event_date = 'Event date is required';
    if (!form.budget_total) e.budget_total = 'Budget is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) { toast.error('Please fill required fields'); return; }
    setSaving(true);
    try {
      await eventService.create(form);
      toast.success('Event created successfully! ✦');
      navigate('/events');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create event');
    } finally { setSaving(false); }
  };

  const STEPS = ['Basic Info', 'Event Details', 'Budget & Notes'];

  return (
    <div>
      <PageHeader title="Create New Event" subtitle="Fill in the event details to get started">
        <Button variant="outline" size="sm" onClick={() => navigate('/events')}>← Events</Button>
      </PageHeader>

      {/* Step indicator */}
      <div className="flex items-center gap-0 mb-8">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center">
            <button onClick={() => setStep(i + 1)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all"
              style={{ background: step === i+1 ? 'rgba(201,169,110,0.12)' : 'transparent',
                border: step === i+1 ? '1px solid rgba(201,169,110,0.3)' : '1px solid transparent' }}>
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                style={{ background: step > i ? '#c9a96e' : step === i+1 ? 'rgba(201,169,110,0.2)' : '#141d35',
                  color: step > i ? '#030508' : step === i+1 ? '#c9a96e' : '#6b6458', border: step <= i ? '1px solid #3a3028' : 'none' }}>
                {step > i ? '✓' : i + 1}
              </div>
              <span style={{ fontSize: 13, fontWeight: step === i+1 ? 600 : 400, color: step === i+1 ? '#c9a96e' : '#6b6458' }}>{s}</span>
            </button>
            {i < STEPS.length - 1 && <div className="w-8 h-px mx-1" style={{ background: 'rgba(201,169,110,0.15)' }} />}
          </div>
        ))}
      </div>

      {/* STEP 1: Basic Info */}
      {step === 1 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader title="Event & Customer Information" />
              <div className="p-6 space-y-0">
                <h3 className="text-sm font-semibold mb-4" style={{ color: '#c9a96e', letterSpacing: 1 }}>EVENT DETAILS</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Event Name *" value={form.event_name} onChange={e => set('event_name', e.target.value)}
                    placeholder="e.g., Sharma & Patel Wedding" error={errors.event_name} className="col-span-2" />
                  <Select label="Event Category *" value={form.category_id} onChange={e => set('category_id', e.target.value)}
                    options={[{value:'',label:'Select category…'}, ...categories.map(c => ({value:c.id, label:`${c.icon||''} ${c.name}`}))]} />
                  <Select label="Venue" value={form.venue_id} onChange={e => set('venue_id', e.target.value)}
                    options={[{value:'',label:'Select venue…'}, ...venues.map(v => ({value:v.id, label:`${v.name} (${v.city})`}))]} />
                </div>

                <div className="h-px my-5" style={{ background: 'rgba(201,169,110,0.08)' }} />
                <h3 className="text-sm font-semibold mb-4" style={{ color: '#c9a96e', letterSpacing: 1 }}>CUSTOMER DETAILS</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Input label="First Name *" value={form.customer_first_name} onChange={e => set('customer_first_name', e.target.value)} placeholder="Vikram" />
                  <Input label="Last Name" value={form.customer_last_name} onChange={e => set('customer_last_name', e.target.value)} placeholder="Patel" />
                  <Input label="Phone *" value={form.customer_phone} onChange={e => set('customer_phone', e.target.value)} placeholder="+91 9876543210" error={errors.customer_phone} />
                  <Input label="Email" type="email" value={form.customer_email} onChange={e => set('customer_email', e.target.value)} placeholder="vikram@gmail.com" />
                </div>
              </div>
            </Card>
          </div>
          <div>
            <Card>
              <CardHeader title="Tips" />
              <div className="p-5">
                {[['💍','Wedding events need at least 3 months planning lead time',''],
                  ['📅','Set the event date accurately — it drives all booking and vendor scheduling',''],
                  ['👤','Customer phone is used for WhatsApp invitations and payment reminders',''],
                  ['🏛️','Select a venue to auto-check availability and block the date',''],
                ].map(([icon, tip]) => (
                  <div key={tip} className="flex gap-3 mb-4">
                    <span className="text-lg flex-shrink-0">{icon}</span>
                    <p style={{ fontSize: 12, color: '#6b6458', lineHeight: 1.6 }}>{tip}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* STEP 2: Event Details */}
      {step === 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader title="Event Schedule & Style" />
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-5">
                  <Input label="Event Date *" type="date" value={form.event_date} onChange={e => set('event_date', e.target.value)} error={errors.event_date} />
                  <Input label="Start Time" type="time" value={form.event_time} onChange={e => set('event_time', e.target.value)} />
                  <Input label="End Date" type="date" value={form.end_date} onChange={e => set('end_date', e.target.value)} />
                  <Input label="End Time" type="time" value={form.end_time} onChange={e => set('end_time', e.target.value)} />
                  <Input label="Expected Guests" type="number" value={form.guest_count_estimate} onChange={e => set('guest_count_estimate', e.target.value)} placeholder="500" />
                  <Select label="Dress Code" value={form.dress_code} onChange={e => set('dress_code', e.target.value)}
                    options={[{value:'',label:'Select…'}, ...DRESS_CODES.map(d => ({value:d, label:d}))]} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Select label="Theme" value={form.theme} onChange={e => set('theme', e.target.value)}
                    options={[{value:'',label:'Select or type custom…'}, ...THEMES.map(t => ({value:t, label:t}))]} className="col-span-2" />
                  <Input label="Color Scheme" value={form.color_scheme} onChange={e => set('color_scheme', e.target.value)} placeholder="e.g., Gold & Ivory" />
                  <Input label="Approximate Guest Count" type="number" value={form.guest_count_estimate} onChange={e => set('guest_count_estimate', e.target.value)} placeholder="300" />
                </div>
                <Textarea label="Special Requirements" value={form.special_requirements} onChange={e => set('special_requirements', e.target.value)}
                  placeholder="Any special requirements, dietary restrictions, accessibility needs…" />
              </div>
            </Card>
          </div>
          <div>
            <Card>
              <CardHeader title="Venue Info" />
              <div className="p-5">
                {form.venue_id ? (
                  (() => {
                    const v = venues.find(v => v.id == form.venue_id);
                    return v ? (
                      <div>
                        <div className="font-semibold mb-1" style={{ color: '#f2ede6', fontSize: 14 }}>{v.name}</div>
                        <div style={{ fontSize: 12, color: '#6b6458', marginBottom: 12 }}>{v.city}</div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="rounded-lg p-3 text-center" style={{ background: '#141d35' }}>
                            <div style={{ fontFamily: 'Cinzel,serif', fontSize: 18, color: '#c9a96e' }}>{v.capacity_max?.toLocaleString()}</div>
                            <div style={{ fontSize: 10, color: '#6b6458' }}>MAX GUESTS</div>
                          </div>
                          <div className="rounded-lg p-3 text-center" style={{ background: '#141d35' }}>
                            <div style={{ fontSize: 13, fontWeight: 700, color: '#f2ede6' }}>₹{(v.price_per_day||0).toLocaleString()}</div>
                            <div style={{ fontSize: 10, color: '#6b6458' }}>PER DAY</div>
                          </div>
                        </div>
                      </div>
                    ) : null;
                  })()
                ) : (
                  <div style={{ textAlign: 'center', padding: '20px 0' }}>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>🏛️</div>
                    <div style={{ fontSize: 13, color: '#6b6458' }}>Select a venue in Step 1</div>
                  </div>
                )}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* STEP 3: Budget & Notes */}
      {step === 3 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader title="Budget Planning & Notes" />
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-5">
                  <Input label="Total Budget (₹) *" type="number" value={form.budget_total} onChange={e => set('budget_total', e.target.value)}
                    placeholder="1500000" error={errors.budget_total} className="col-span-2" />
                </div>
                {form.budget_total > 0 && (
                  <div className="rounded-xl p-4 mb-5" style={{ background: '#141d35', border: '1px solid rgba(201,169,110,0.08)' }}>
                    <div style={{ fontSize: 13, color: '#c9a96e', fontWeight: 600, marginBottom: 12 }}>Suggested Budget Allocation</div>
                    {[['Catering & Food', 35], ['Decoration & Flowers', 20], ['Photography & Video', 15], ['Venue', 15], ['Music & Entertainment', 8], ['Makeup & Beauty', 4], ['Miscellaneous', 3]].map(([cat, pct]) => (
                      <div key={cat} className="flex items-center gap-3 mb-3">
                        <div style={{ fontSize: 12, color: '#9ca3af', width: 160, flexShrink: 0 }}>{cat}</div>
                        <div className="flex-1 rounded-full h-1.5 overflow-hidden" style={{ background: 'rgba(201,169,110,0.1)' }}>
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg,#9a7a4a,#c9a96e)' }} />
                        </div>
                        <div style={{ fontSize: 12, color: '#9ca3af', textAlign: 'right', width: 90, flexShrink: 0 }}>
                          {pct}% · ₹{Math.round(form.budget_total * pct / 100).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <Textarea label="Internal Notes" value={form.notes} onChange={e => set('notes', e.target.value)}
                  placeholder="Internal notes for the event team — not visible to the customer…" />

                {/* Summary */}
                <div className="rounded-xl p-5 mt-4" style={{ background: 'rgba(201,169,110,0.05)', border: '1px solid rgba(201,169,110,0.15)' }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#c9a96e', marginBottom: 12 }}>Event Summary</div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      ['Event', form.event_name || '—'],
                      ['Customer', `${form.customer_first_name} ${form.customer_last_name}`.trim() || '—'],
                      ['Phone', form.customer_phone || '—'],
                      ['Date', form.event_date || '—'],
                      ['Guests', form.guest_count_estimate || '—'],
                      ['Budget', form.budget_total ? `₹${parseInt(form.budget_total).toLocaleString()}` : '—'],
                      ['Theme', form.theme || '—'],
                      ['Venue', form.venue_id ? (venues.find(v => v.id == form.venue_id)?.name || '—') : '—'],
                    ].map(([l, v]) => (
                      <div key={l}>
                        <div style={{ fontSize: 10, color: '#6b6458' }}>{l}</div>
                        <div style={{ fontSize: 13, color: '#f2ede6' }}>{v}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </div>
          <div>
            <Card>
              <CardHeader title="Before You Submit" />
              <div className="p-5 space-y-3">
                {[
                  [!!form.event_name, 'Event name filled'],
                  [!!form.category_id, 'Category selected'],
                  [!!form.customer_phone, 'Customer phone added'],
                  [!!form.event_date, 'Event date set'],
                  [!!form.budget_total, 'Budget defined'],
                  [!!form.venue_id, 'Venue selected'],
                  [!!form.theme, 'Theme chosen'],
                  [!!form.guest_count_estimate, 'Guest count estimated'],
                ].map(([done, label]) => (
                  <div key={label} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ background: done ? '#10b981' : '#141d35', border: done ? 'none' : '1px solid #3a3028', fontSize: 11, color: '#030508' }}>
                      {done ? '✓' : ''}
                    </div>
                    <span style={{ fontSize: 13, color: done ? '#f2ede6' : '#6b6458' }}>{label}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex justify-between mt-6">
        <div>
          {step > 1 && <Button variant="outline" onClick={() => setStep(s => s - 1)}>← Previous</Button>}
        </div>
        <div className="flex gap-3">
          <Button variant="ghost" onClick={() => navigate('/events')}>Cancel</Button>
          {step < 3
            ? <Button onClick={() => setStep(s => s + 1)}>Next Step →</Button>
            : <Button onClick={handleSubmit} loading={saving}>✦ Create Event</Button>
          }
        </div>
      </div>
    </div>
  );
}

const MOCK_CATS = [
  {id:1,name:'Wedding',icon:'💍'},{id:2,name:'Reception',icon:'🥂'},{id:3,name:'Engagement',icon:'💕'},
  {id:4,name:'Birthday Party',icon:'🎂'},{id:5,name:'Corporate Event',icon:'💼'},{id:6,name:'Anniversary',icon:'🎊'},
];
const MOCK_VENUES = [
  {id:1,name:'The Grand Palace Banquet',city:'Chennai',capacity_max:1000,price_per_day:250000},
  {id:2,name:'Coastal Breeze Garden',city:'Chennai',capacity_max:500,price_per_day:120000},
  {id:3,name:'Jade Convention Center',city:'Chennai',capacity_max:2000,price_per_day:450000},
  {id:4,name:'Bloom Garden Lawn',city:'Chennai',capacity_max:400,price_per_day:90000},
];
