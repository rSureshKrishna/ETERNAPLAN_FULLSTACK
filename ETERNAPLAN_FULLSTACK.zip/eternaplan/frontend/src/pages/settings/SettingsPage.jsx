export { SettingsPage as default } from '../RemainingPages';
