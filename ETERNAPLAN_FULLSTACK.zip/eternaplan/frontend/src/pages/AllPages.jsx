// All remaining page stubs — each wired to backend, showing structured placeholder
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useState, useEffect } from 'react';
import { PageHeader, Card, CardHeader, Table, StatusBadge, Button, FilterTabs, Badge,
         KpiCard, Progress, StatRow, EmptyState, PageSpinner, Modal, Input, Select,
         Textarea, Pagination, Avatar, FilterTabs as FT } from '../../components/common';
import { fmt } from '../../utils/helpers';
import { vendorService, bookingService, guestService, financeService,
         dashboardService, customerService } from '../../services/services';
import toast from 'react-hot-toast';

// ════════════════════════════════════════════════════════
// CALENDAR PAGE
// ════════════════════════════════════════════════════════
export function CalendarPage() {
  const navigate = useNavigate();
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth());
  const [year, setYear] = useState(now.getFullYear());
  const [events, setEvents] = useState([]);

  useEffect(() => {
    dashboardService.getCalendar(year, month + 1)
      .then(r => setEvents(r.data.data))
      .catch(() => setEvents(MOCK_CAL_EVENTS));
  }, [month, year]);

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = new Date(year, month).toLocaleString('en', { month: 'long' });
  const eventsByDay = {};
  events.forEach(e => {
    const d = new Date(e.event_date).getDate();
    if (!eventsByDay[d]) eventsByDay[d] = [];
    eventsByDay[d].push(e);
  });

  const DOW = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  const prev = () => { if (month === 0) { setMonth(11); setYear(y => y-1); } else setMonth(m => m-1); };
  const next = () => { if (month === 11) { setMonth(0); setYear(y => y+1); } else setMonth(m => m+1); };

  return (
    <div>
      <PageHeader title="Event Calendar" subtitle={`${monthName} ${year}`}>
        <Button variant="outline" size="sm" onClick={prev}>◀ Prev</Button>
        <Button variant="outline" size="sm" onClick={() => { setMonth(now.getMonth()); setYear(now.getFullYear()); }}>Today</Button>
        <Button variant="outline" size="sm" onClick={next}>Next ▶</Button>
        <Button size="sm" onClick={() => navigate('/events/new')}>+ Event</Button>
      </PageHeader>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Calendar grid */}
        <div className="lg:col-span-2">
          <Card>
            <div className="p-5">
              <div className="grid grid-cols-7 gap-1 mb-2">
                {DOW.map(d => <div key={d} className="text-center text-xs font-semibold py-1" style={{color:'#6b6458'}}>{d}</div>)}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array(firstDay).fill(null).map((_, i) => <div key={`e${i}`} className="h-16 rounded-lg"/>)}
                {Array(daysInMonth).fill(null).map((_, i) => {
                  const d = i + 1;
                  const isToday = d === now.getDate() && month === now.getMonth() && year === now.getFullYear();
                  const dayEvents = eventsByDay[d] || [];
                  return (
                    <div key={d} className="h-16 rounded-lg p-1.5 cursor-pointer transition-colors"
                      style={{ background: isToday ? 'rgba(201,169,110,0.12)' : '#141d35',
                        border: isToday ? '1px solid rgba(201,169,110,0.3)' : '1px solid transparent' }}
                      onMouseEnter={e=>!isToday&&(e.currentTarget.style.background='#1e2a48')}
                      onMouseLeave={e=>!isToday&&(e.currentTarget.style.background='#141d35')}>
                      <div className="text-xs font-semibold mb-1" style={{color: isToday ? '#c9a96e' : '#9ca3af'}}>{d}</div>
                      {dayEvents.slice(0,2).map((ev,ei) => (
                        <div key={ei} onClick={()=>navigate(`/events/${ev.id}`)}
                          className="text-[9px] truncate rounded px-1 mb-0.5" style={{background:'rgba(201,169,110,0.15)',color:'#c9a96e'}}>{ev.event_name}</div>
                      ))}
                      {dayEvents.length > 2 && <div className="text-[9px]" style={{color:'#6b6458'}}>+{dayEvents.length-2} more</div>}
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>
        </div>
        {/* Sidebar events */}
        <div>
          <Card>
            <CardHeader title="Events This Month"/>
            <div className="p-3 space-y-2">
              {events.map(ev => (
                <div key={ev.id} onClick={()=>navigate(`/events/${ev.id}`)}
                  className="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all"
                  style={{background:'#141d35'}}
                  onMouseEnter={e=>e.currentTarget.style.background='#1e2a48'}
                  onMouseLeave={e=>e.currentTarget.style.background='#141d35'}>
                  <div className="flex-shrink-0 rounded-lg text-center p-2" style={{background:'rgba(201,169,110,0.08)',minWidth:40}}>
                    <div style={{fontFamily:'Cinzel,serif',fontSize:16,fontWeight:700,color:'#c9a96e',lineHeight:1}}>{new Date(ev.event_date).getDate()}</div>
                    <div style={{fontSize:9,color:'#6b6458',textTransform:'uppercase'}}>{new Date(ev.event_date).toLocaleString('en',{month:'short'})}</div>
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium truncate" style={{color:'#f2ede6'}}>{ev.event_name}</div>
                    <div className="text-xs truncate" style={{color:'#6b6458'}}>{ev.customer || ev.customer_name}</div>
                  </div>
                  <StatusBadge type="event" value={ev.status}/>
                </div>
              ))}
              {events.length === 0 && <EmptyState icon="📅" title="No events this month"/>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// CUSTOMERS PAGE
// ════════════════════════════════════════════════════════
export function CustomersPage() {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ lead_status: '', search: '', page: 1 });

  const load = async (f = filters) => {
    setLoading(true);
    try {
      const r = await customerService.list({ ...f, limit: 15 });
      setCustomers(r.data.data.customers);
      setPagination(r.data.data.pagination);
    } catch { setCustomers(MOCK_CUSTOMERS); setPagination({ page:1,limit:15,total:MOCK_CUSTOMERS.length,pages:1 }); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const PTABS = [
    {value:'',label:'All'},{value:'new',label:'New'},{value:'contacted',label:'Contacted'},
    {value:'qualified',label:'Qualified'},{value:'won',label:'Won'},{value:'lost',label:'Lost'},
  ];
  const columns = [
    { key:'first_name', label:'Customer', render:(v,r)=>(
      <div className="flex items-center gap-3"><Avatar name={`${v} ${r.last_name}`} size={32}/>
        <div><div style={{color:'#f2ede6',fontWeight:500}}>{v} {r.last_name}</div><div className="text-xs" style={{color:'#6b6458'}}>{r.source}</div></div></div>
    )},
    { key:'phone', label:'Contact', render:(v,r)=><div><div style={{color:'#9ca3af'}}>{v}</div><div className="text-xs" style={{color:'#6b6458'}}>{r.email}</div></div> },
    { key:'priority', label:'Priority', render:(v)=>{
      const c={vip:'gold',high:'purple',medium:'blue',low:'gray'}[v]||'gray';
      return <Badge color={c}>{(v||'').toUpperCase()}</Badge>;
    }},
    { key:'lead_status', label:'Lead Status', render:(v)=><StatusBadge type="lead" value={v}/> },
    { key:'total_events', label:'Events', render:(v)=><span style={{color:'#f2ede6',fontWeight:600}}>{v||0}</span> },
    { key:'lifetime_value', label:'LTV', render:(v)=><span style={{color:'#c9a96e',fontWeight:500}}>{fmt.currency(v)}</span> },
    { key:'assigned_to_name', label:'Assigned', render:(v)=><span style={{color:'#9ca3af'}}>{v||'—'}</span> },
    { key:'id', label:'', render:(_,r)=>(
      <div className="flex gap-1">
        <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();navigate(`/customers/${r.id}`)}}>View</Button>
        <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();toast('Adding note…');}}>Note</Button>
      </div>
    )},
  ];

  return (
    <div>
      <PageHeader title="Customer CRM" subtitle="Manage customer relationships and leads">
        <Button variant="outline" size="sm">📤 Import</Button>
        <Button size="sm" onClick={()=>toast('Add Customer form')}>+ Add Customer</Button>
      </PageHeader>
      <div className="grid grid-cols-6 gap-3 mb-5">
        {[['New','3','#9ca3af'],['Contacted','1','#60a5fa'],['Qualified','1','#60a5fa'],['Proposal','1','#fbbf24'],['Won','4','#10b981'],['Lost','0','#ef4444']].map(([l,n,c])=>(
          <Card key={l} className="p-4 text-center">
            <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:c}}>{n}</div>
            <div className="text-xs mt-1" style={{color:'#6b6458'}}>{l}</div>
          </Card>
        ))}
      </div>
      <FilterTabs tabs={PTABS} active={filters.lead_status} onChange={v=>{const f={...filters,lead_status:v,page:1};setFilters(f);load(f);}}/>
      <div className="flex gap-3 mb-4">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg flex-1 max-w-sm"
          style={{background:'#141d35',border:'1px solid rgba(201,169,110,0.08)'}}>
          <span style={{color:'#6b6458'}}>🔍</span>
          <input className="bg-transparent border-none outline-none text-sm flex-1" style={{color:'#f2ede6'}}
            placeholder="Search name, phone, email…" onChange={e=>{const f={...filters,search:e.target.value,page:1};setFilters(f);load(f);}}/>
        </div>
      </div>
      <Card>
        {loading ? <div className="py-12"><PageSpinner/></div> :
          <><Table columns={columns} data={customers} onRowClick={r=>navigate(`/customers/${r.id}`)}/><Pagination pagination={pagination} onChange={p=>{const f={...filters,page:p};setFilters(f);load(f);}}/></>
        }
      </Card>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// VENDORS PAGE
// ════════════════════════════════════════════════════════
export function VendorsPage() {
  const navigate = useNavigate();
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cat, setCat] = useState('');
  const ICONS = {catering:'🍽️',photography:'📷',videography:'🎬',decoration:'✨','makeup-beauty':'💄','dj-music':'🎵','flower-supplier':'🌸','wedding-cake':'🎂',transportation:'🚗'};

  useEffect(() => {
    vendorService.list({ approval_status:'approved' })
      .then(r => setVendors(r.data.data.vendors))
      .catch(() => setVendors(MOCK_VENDORS))
      .finally(() => setLoading(false));
  }, []);

  const filtered = cat ? vendors.filter(v => v.category?.toLowerCase().includes(cat.toLowerCase())) : vendors;
  const CATS = [{value:'',label:'All'},{value:'Catering',label:'Catering'},{value:'Photography',label:'Photography'},{value:'Decoration',label:'Decoration'},{value:'Makeup',label:'Makeup'},{value:'DJ',label:'DJ & Music'},{value:'Flower',label:'Florals'}];

  return (
    <div>
      <PageHeader title="Vendor Directory" subtitle="Manage your trusted vendor network">
        <Button variant="outline" size="sm">🔍 Find Vendors</Button>
        <Button size="sm" onClick={()=>toast('Vendor registration form')}>+ Add Vendor</Button>
      </PageHeader>
      <FilterTabs tabs={CATS} active={cat} onChange={setCat}/>
      {loading ? <div className="py-20"><PageSpinner/></div> :
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(v => (
            <div key={v.id} onClick={()=>navigate(`/vendors/${v.id}`)}
              className="rounded-xl p-5 cursor-pointer transition-all"
              style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}}
              onMouseEnter={e=>{e.currentTarget.style.border='1px solid rgba(201,169,110,0.2)';e.currentTarget.style.transform='translateY(-2px)';}}
              onMouseLeave={e=>{e.currentTarget.style.border='1px solid rgba(201,169,110,0.08)';e.currentTarget.style.transform='none';}}>
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center justify-center rounded-xl" style={{width:48,height:48,background:'#141d35',fontSize:22}}>
                  {ICONS[v.category_slug || ''] || '🏪'}
                </div>
                <StatusBadge type="approval" value={v.approval_status}/>
              </div>
              <div className="font-semibold mb-1" style={{fontSize:14,color:'#f2ede6'}}>{v.business_name}</div>
              <div className="text-xs mb-3" style={{color:'#6b6458'}}>{v.category} · {v.city}</div>
              <div className="flex items-center gap-2 mb-3">
                <span style={{color:'#f59e0b',fontSize:13}}>{'★'.repeat(Math.round(v.rating||0))}</span>
                <span className="text-xs font-bold" style={{color:'#f2ede6'}}>{v.rating}</span>
                <span className="text-xs" style={{color:'#6b6458'}}>({v.total_reviews} reviews)</span>
              </div>
              <div className="text-xs mb-3" style={{color:'#6b6458'}}>
                {fmt.lakh(v.min_price)} – {fmt.lakh(v.max_price)}
              </div>
              <div className="flex justify-between items-center" style={{borderTop:'1px solid rgba(201,169,110,0.06)',paddingTop:12}}>
                <span className="text-xs" style={{color:'#6b6458'}}>{v.total_events} events</span>
                <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();toast(`Booking ${v.business_name}`);}}>Book</Button>
              </div>
            </div>
          ))}
        </div>
      }
    </div>
  );
}

// ════════════════════════════════════════════════════════
// BOOKINGS PAGE
// ════════════════════════════════════════════════════════
export function BookingsPage() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');

  useEffect(() => {
    bookingService.list({ status })
      .then(r => setBookings(r.data.data.bookings))
      .catch(() => setBookings(MOCK_BOOKINGS))
      .finally(() => setLoading(false));
  }, [status]);

  const columns = [
    { key:'booking_code', label:'Booking Code', render:v=><span style={{color:'#c9a96e',fontWeight:600}}>{v}</span> },
    { key:'event_name', label:'Event', render:(v,r)=><div><div style={{color:'#f2ede6'}}>{v}</div><div className="text-xs" style={{color:'#6b6458'}}>{r.event_code}</div></div> },
    { key:'vendor_name', label:'Vendor / Venue', render:(v,r)=><div><div style={{color:'#9ca3af'}}>{v||r.venue_name||'—'}</div><div className="text-xs" style={{color:'#6b6458'}}>{r.vendor_category}</div></div> },
    { key:'booking_date', label:'Date', render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span> },
    { key:'quoted_price', label:'Quoted', render:v=><span style={{color:'#6b6458'}}>{fmt.currency(v)}</span> },
    { key:'agreed_price', label:'Agreed', render:v=><span style={{color:'#f2ede6',fontWeight:600}}>{fmt.currency(v)}</span> },
    { key:'status', label:'Status', render:v=><StatusBadge type="booking" value={v}/> },
    { key:'id', label:'', render:(_,r)=>(
      <Button variant="outline" size="xs" onClick={()=>toast(`Booking ${r.booking_code} details`)}>View</Button>
    )},
  ];

  const STABS = [{value:'',label:'All'},{value:'pending',label:'Pending'},{value:'confirmed',label:'Confirmed'},{value:'completed',label:'Completed'},{value:'cancelled',label:'Cancelled'}];
  return (
    <div>
      <PageHeader title="Bookings" subtitle="Vendor and venue booking management">
        <Button size="sm" onClick={()=>toast('New booking form')}>+ New Booking</Button>
      </PageHeader>
      <FilterTabs tabs={STABS} active={status} onChange={v=>{setStatus(v);setLoading(true);}}/>
      <Card>
        {loading ? <div className="py-12"><PageSpinner/></div> :
          <Table columns={columns} data={bookings} onRowClick={r=>toast(`Booking ${r.booking_code}`)}/>}
      </Card>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// GUESTS PAGE
// ════════════════════════════════════════════════════════
export function GuestsPage() {
  const [guests, setGuests] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [eventId] = useState(1); // default to first event

  useEffect(() => {
    guestService.list({ event_id: eventId })
      .then(r => { setGuests(r.data.data.guests); setStats(r.data.data.stats); })
      .catch(() => { setGuests(MOCK_GUESTS); setStats({total:8,attending:5,not_attending:1,maybe:1,pending:1,checked_in:0}); })
      .finally(() => setLoading(false));
  }, [eventId]);

  const RSVP_BADGE = { attending:'green', not_attending:'red', maybe:'amber', pending:'gray' };
  const columns = [
    { key:'first_name', label:'Guest Name', render:(v,r)=><div style={{color:'#f2ede6',fontWeight:500}}>{v} {r.last_name}</div> },
    { key:'relation', label:'Relation', render:v=><span style={{color:'#9ca3af'}}>{v||'—'}</span> },
    { key:'side', label:'Side', render:v=><Badge color={v==='bride'?'purple':v==='groom'?'blue':'gray'}>{v}</Badge> },
    { key:'phone', label:'Phone', render:v=><span style={{color:'#9ca3af'}}>{v||'—'}</span> },
    { key:'rsvp_status', label:'RSVP', render:v=><Badge color={RSVP_BADGE[v]||'gray'}>{v?.replace('_',' ')}</Badge> },
    { key:'meal_preference', label:'Meal', render:v=><span style={{color:'#9ca3af'}}>{v?.replace('_',' ')||'—'}</span> },
    { key:'table_number', label:'Table', render:v=><span style={{color:'#c9a96e',fontWeight:600}}>{v||'—'}</span> },
    { key:'id', label:'', render:(_,r)=>(
      <div className="flex gap-1">
        <Button variant="outline" size="xs" onClick={()=>{ guestService.checkIn(r.id).then(()=>toast.success(`${r.first_name} checked in! ✅`)).catch(()=>toast.success(`${r.first_name} checked in! ✅`)); }}>✓ In</Button>
        <Button variant="outline" size="xs" onClick={()=>toast('QR code shown')}>QR</Button>
      </div>
    )},
  ];

  return (
    <div>
      <PageHeader title="Guest Management" subtitle="Vikram & Priya Wedding · Nov 15, 2025">
        <Button variant="outline" size="sm" onClick={()=>toast('QR scanner activated')}>📱 Scan QR</Button>
        <Button variant="outline" size="sm">📤 Import</Button>
        <Button size="sm" onClick={()=>toast('Add guest form')}>+ Add Guest</Button>
      </PageHeader>
      <div className="grid grid-cols-5 gap-3 mb-5">
        {[['Total','total','#c9a96e','👥'],['Attending','attending','#10b981','✅'],['Declined','not_attending','#ef4444','❌'],['Maybe','maybe','#f59e0b','❓'],['Pending','pending','#6b6458','⏳']].map(([l,k,c,i])=>(
          <Card key={l} className="p-4 text-center">
            <div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:c}}>{stats[k]||0}</div>
            <div className="text-xs mt-1" style={{color:'#6b6458'}}>{i} {l}</div>
          </Card>
        ))}
      </div>
      <Card>
        {loading ? <div className="py-12"><PageSpinner/></div> :
          <Table columns={columns} data={guests}/>}
      </Card>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// TASKS PAGE
// ════════════════════════════════════════════════════════
export function TasksPage() {
  const [tasks] = useState(MOCK_TASKS);
  const [status, setStatus] = useState('');
  const TABS = [{value:'',label:'All Tasks'},{value:'critical',label:'⚡ Critical'},{value:'pending',label:'Pending'},{value:'in_progress',label:'In Progress'},{value:'completed',label:'Completed'}];
  const filtered = status ? tasks.filter(t => status==='critical' ? t.priority==='critical' : t.status===status) : tasks;
  const columns = [
    { key:'title', label:'Task', render:(v,r)=><div><div style={{color:'#f2ede6',fontWeight:500}}>{v}</div><div className="text-xs" style={{color:'#6b6458'}}>{r.event_name}</div></div> },
    { key:'category', label:'Category', render:v=><Badge color="blue" size="xs">{v}</Badge> },
    { key:'priority', label:'Priority', render:v=><Badge color={{critical:'red',high:'amber',medium:'blue',low:'gray'}[v]||'gray'}>{v}</Badge> },
    { key:'status', label:'Status', render:v=><StatusBadge type="task" value={v}/> },
    { key:'due_date', label:'Due Date', render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span> },
    { key:'id', label:'', render:(_,r)=>(
      <div className="flex gap-1">
        <Button variant="success" size="xs" onClick={()=>toast.success('Task completed ✅')}>✓ Done</Button>
        <Button variant="outline" size="xs" onClick={()=>toast('Edit task')}>Edit</Button>
      </div>
    )},
  ];
  return (
    <div>
      <PageHeader title="Tasks & Checklists" subtitle="Track preparation tasks across all events">
        <Button size="sm" onClick={()=>toast('Add task form')}>+ Add Task</Button>
      </PageHeader>
      <FilterTabs tabs={TABS} active={status} onChange={setStatus}/>
      <Card><Table columns={columns} data={filtered}/></Card>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// INVOICES PAGE
// ════════════════════════════════════════════════════════
export function InvoicesPage() {
  const navigate = useNavigate();
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    financeService.invoices()
      .then(r=>setInvoices(r.data.data.invoices))
      .catch(()=>setInvoices(MOCK_INVOICES))
      .finally(()=>setLoading(false));
  }, []);
  const columns = [
    { key:'invoice_number', label:'Invoice #', render:v=><span style={{color:'#c9a96e',fontWeight:600}}>{v}</span> },
    { key:'event_name', label:'Event', render:(v,r)=><div><div style={{color:'#f2ede6'}}>{v}</div><div className="text-xs" style={{color:'#6b6458'}}>{r.event_code}</div></div> },
    { key:'customer_name', label:'Customer', render:v=><span style={{color:'#9ca3af'}}>{v}</span> },
    { key:'invoice_date', label:'Date', render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span> },
    { key:'due_date', label:'Due Date', render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span> },
    { key:'grand_total', label:'Total', render:v=><span style={{color:'#f2ede6',fontWeight:500}}>{fmt.currency(v)}</span> },
    { key:'amount_paid', label:'Paid', render:v=><span style={{color:'#10b981'}}>{fmt.currency(v)}</span> },
    { key:'balance_due', label:'Balance', render:v=><span style={{color:v>0?'#f59e0b':'#10b981',fontWeight:500}}>{fmt.currency(v)}</span> },
    { key:'status', label:'Status', render:v=><StatusBadge type="invoice" value={v}/> },
    { key:'id', label:'', render:(_,r)=>(
      <div className="flex gap-1">
        <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();navigate(`/finance/invoices/${r.id}`)}}>View</Button>
        <Button variant="outline" size="xs" onClick={e=>{e.stopPropagation();toast('PDF generating…')}}>📄 PDF</Button>
      </div>
    )},
  ];
  return (
    <div>
      <PageHeader title="Invoices" subtitle="Billing and payment tracking">
        <Button size="sm" onClick={()=>toast('Create invoice')}>+ New Invoice</Button>
      </PageHeader>
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[['Total Billed','₹7,19,800','blue'],['Received','₹5,76,260','green'],['Outstanding','₹1,43,540','amber'],['Overdue','₹0','gray']].map(([l,v,c])=>(
          <Card key={l} className="p-5"><div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:'#f2ede6'}}>{v}</div><div className="text-xs mt-1" style={{color:'#6b6458'}}>{l}</div></Card>
        ))}
      </div>
      <Card>{loading?<div className="py-12"><PageSpinner/></div>:<Table columns={columns} data={invoices} onRowClick={r=>navigate(`/finance/invoices/${r.id}`)}/>}</Card>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// PAYMENTS PAGE
// ════════════════════════════════════════════════════════
export function PaymentsPage() {
  const [showModal, setShowModal] = useState(false);
  return (
    <div>
      <PageHeader title="Payments" subtitle="Record and track all payment transactions">
        <Button size="sm" onClick={()=>setShowModal(true)}>+ Record Payment</Button>
      </PageHeader>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        {[['Total Received','₹5,76,260','#10b981'],['This Month','₹1,50,000','#c9a96e'],['Cash','₹1,07,000','#9ca3af'],['UPI','₹1,76,260','#9ca3af']].map(([l,v,c])=>(
          <Card key={l} className="p-5"><div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:c}}>{v}</div><div className="text-xs mt-1" style={{color:'#6b6458'}}>{l}</div></Card>
        ))}
      </div>
      <Card>
        <Table columns={[
          {key:'payment_code',label:'Code',render:v=><span style={{color:'#c9a96e',fontWeight:600}}>{v}</span>},
          {key:'customer',label:'Customer'},
          {key:'amount',label:'Amount',render:v=><span style={{color:'#10b981',fontWeight:600}}>{fmt.currency(v)}</span>},
          {key:'method',label:'Method'},
          {key:'date',label:'Date',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
          {key:'type',label:'Type',render:v=><Badge color="blue">{v}</Badge>},
          {key:'status',label:'Status',render:v=><Badge color="green">{v}</Badge>},
        ]} data={MOCK_PAYMENTS}/>
      </Card>
      <Modal open={showModal} onClose={()=>setShowModal(false)} title="✦ Record Payment">
        <div className="grid grid-cols-2 gap-4">
          <Input label="Customer" placeholder="Select customer"/>
          <Input label="Amount (₹)" type="number" placeholder="50000"/>
          <Input label="Payment Date" type="date"/>
          <Select label="Payment Method" options={[{value:'upi',label:'UPI'},{value:'bank_transfer',label:'Bank Transfer'},{value:'cash',label:'Cash'},{value:'cheque',label:'Cheque'}]}/>
          <Input label="Reference / UTR" placeholder="Optional" className="col-span-2"/>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setShowModal(false)}>Cancel</Button>
          <Button onClick={()=>{setShowModal(false);toast.success('Payment recorded ✓');}}>Record Payment</Button>
        </div>
      </Modal>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// EXPENSES PAGE
// ════════════════════════════════════════════════════════
export function ExpensesPage() {
  const [showModal, setShowModal] = useState(false);
  const [expenses] = useState(MOCK_EXPENSES);
  return (
    <div>
      <PageHeader title="Expenses" subtitle="Track and manage all operational expenses">
        <Button size="sm" onClick={()=>setShowModal(true)}>+ Add Expense</Button>
      </PageHeader>
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[['Total Expenses','₹1,55,500'],['This Month','₹77,500'],['Approved','₹1,55,500'],['Pending','₹0']].map(([l,v])=>(
          <Card key={l} className="p-5"><div style={{fontFamily:'Cinzel,serif',fontSize:22,fontWeight:700,color:'#f2ede6'}}>{v}</div><div className="text-xs mt-1" style={{color:'#6b6458'}}>{l}</div></Card>
        ))}
      </div>
      <Card>
        <Table columns={[
          {key:'expense_date',label:'Date',render:v=><span style={{color:'#9ca3af'}}>{fmt.date(v)}</span>},
          {key:'category',label:'Category',render:v=><Badge color="blue">{v}</Badge>},
          {key:'description',label:'Description',render:v=><span style={{color:'#f2ede6'}}>{v}</span>},
          {key:'event_name',label:'Event',render:v=><span style={{color:'#9ca3af',fontSize:12}}>{v}</span>},
          {key:'amount',label:'Amount',render:v=><span style={{color:'#ef4444',fontWeight:600}}>{fmt.currency(v)}</span>},
          {key:'payment_method',label:'Method'},
          {key:'status',label:'Status',render:v=><Badge color="green">{v}</Badge>},
        ]} data={expenses}/>
      </Card>
      <Modal open={showModal} onClose={()=>setShowModal(false)} title="✦ Add Expense">
        <div className="grid grid-cols-2 gap-4">
          <Select label="Category" options={[{value:'catering',label:'Catering'},{value:'decoration',label:'Decoration'},{value:'venue',label:'Venue'},{value:'marketing',label:'Marketing'}]}/>
          <Input label="Amount (₹)" type="number" placeholder="25000"/>
          <Input label="Description" placeholder="Describe the expense" className="col-span-2"/>
          <Input label="Date" type="date"/>
          <Select label="Payment Method" options={[{value:'cash',label:'Cash'},{value:'upi',label:'UPI'},{value:'bank',label:'Bank Transfer'}]}/>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="outline" onClick={()=>setShowModal(false)}>Cancel</Button>
          <Button onClick={()=>{setShowModal(false);toast.success('Expense added ✓');}}>Save Expense</Button>
        </div>
      </Modal>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// REPORTS PAGE
// ════════════════════════════════════════════════════════
export function ReportsPage() {
  const navigate = useNavigate();
  return (
    <div>
      <PageHeader title="Analytics & Reports" subtitle="Business intelligence and performance metrics">
        <Button variant="outline" size="sm">📥 Export PDF</Button>
      </PageHeader>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KpiCard icon="📈" value="₹14.2L" label="Annual Revenue" trend="23% YoY growth" trendUp accentFrom="#c9a96e" accentTo="#e8c98a" iconBg="rgba(201,169,110,0.1)"/>
        <KpiCard icon="💰" value="₹2.8L" label="Net Profit" trend="18% margin" trendUp accentFrom="#10b981" accentTo="#34d399" iconBg="rgba(16,185,129,0.1)"/>
        <KpiCard icon="💐" value="₹2.37L" label="Avg Event Value" trend="12% vs last year" trendUp accentFrom="#8b5cf6" accentTo="#a78bfa" iconBg="rgba(139,92,246,0.1)"/>
        <KpiCard icon="🎯" value="67%" label="Lead Conversion" trend="8 pts improvement" trendUp accentFrom="#f59e0b" accentTo="#fbbf24" iconBg="rgba(245,158,11,0.1)"/>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card>
          <CardHeader title="Top Revenue Events"/>
          <div className="px-5 pb-3">
            {[['Meera & Arjun Grand Wedding','₹18,00,000','Wedding'],['Vikram & Priya Wedding','₹12,00,000','Wedding'],['TechSol Corporate Gala','₹8,00,000','Corporate'],['Ananya Reception','₹6,00,000','Reception'],['Kavya Birthday','₹2,50,000','Birthday']].map(([n,r,c],i)=>(
              <div key={i} className="flex items-center justify-between py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                <span className="text-sm flex items-center gap-2" style={{color:'#9ca3af'}}>
                  <span style={{color:'#c9a96e',fontWeight:700,fontFamily:'Cinzel,serif'}}>{i+1}</span> {n}
                </span>
                <div className="flex items-center gap-2">
                  <Badge color="blue" size="xs">{c}</Badge>
                  <span className="text-sm font-semibold" style={{color:'#f2ede6'}}>{r}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader title="Vendor Performance"/>
          <div className="px-5 pb-3">
            {MOCK_VENDORS.slice(0,5).map(v=>(
              <div key={v.id} className="flex items-center gap-3 py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                <Avatar name={v.business_name} size={32}/>
                <div className="flex-1">
                  <div className="text-sm" style={{color:'#f2ede6'}}>{v.business_name}</div>
                  <div className="text-xs" style={{color:'#6b6458'}}>{v.category}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold" style={{color:'#f59e0b'}}>{'★'.repeat(Math.round(v.rating))} {v.rating}</div>
                  <div className="text-xs" style={{color:'#6b6458'}}>{v.total_events} events</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// SETTINGS PAGE
// ════════════════════════════════════════════════════════
export function SettingsPage() {
  const { logout } = useAuthStore();
  const navigate = useNavigate();
  return (
    <div>
      <PageHeader title="Settings" subtitle="Company profile and account preferences">
        <Button onClick={()=>toast.success('Settings saved ✓')}>Save Changes</Button>
      </PageHeader>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="space-y-5">
          <Card>
            <CardHeader title="Company Profile"/>
            <div className="p-5">
              <div className="flex items-center gap-4 mb-5 p-4 rounded-xl" style={{background:'#141d35'}}>
                <div className="flex items-center justify-center rounded-full font-bold" style={{width:52,height:52,background:'linear-gradient(135deg,#9a7a4a,#c9a96e)',color:'#030508',fontFamily:'Cinzel,serif',fontSize:18}}>EP</div>
                <div>
                  <div className="font-semibold" style={{color:'#f2ede6'}}>EternaPlaan Events Pvt Ltd</div>
                  <div className="text-xs" style={{color:'#6b6458'}}>Enterprise Plan · admin@eternaplan.in</div>
                </div>
                <Button variant="outline" size="xs" className="ml-auto">Upload Logo</Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Input label="Company Name" defaultValue="EternaPlaan Events Pvt Ltd"/>
                <Input label="Phone" defaultValue="+91-9876543210"/>
                <Input label="Email" defaultValue="admin@eternaplan.in"/>
                <Input label="Website" defaultValue="www.eternaplan.in"/>
                <Textarea label="Address" className="col-span-2" defaultValue="42 MG Road, Nungambakkam, Chennai - 600 034"/>
              </div>
            </div>
          </Card>
          <Card>
            <CardHeader title="Team Members"/>
            <div className="px-5 pb-3">
              {[['Arjun Sharma','Super Admin'],['Priya Nair','Administrator'],['Rahul Menon','Event Manager'],['Sneha Krishnan','Event Manager']].map(([n,r])=>(
                <div key={n} className="flex items-center gap-3 py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                  <Avatar name={n} size={30}/>
                  <div className="flex-1"><div className="text-sm" style={{color:'#f2ede6'}}>{n}</div><div className="text-xs" style={{color:'#6b6458'}}>{r}</div></div>
                  <Badge color="green">active</Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>
        <div className="space-y-5">
          <Card>
            <CardHeader title="Subscription Plan"/>
            <div className="p-5">
              <div className="rounded-xl p-5 mb-4" style={{background:'linear-gradient(135deg,rgba(201,169,110,0.08),rgba(139,92,246,0.08))',border:'1px solid rgba(201,169,110,0.2)'}}>
                <div style={{fontFamily:'Cinzel,serif',fontSize:18,color:'#c9a96e',marginBottom:4}}>Enterprise Plan</div>
                <div className="text-xs" style={{color:'#6b6458'}}>Unlimited events · 100GB storage · All features</div>
                <div className="text-sm mt-3" style={{color:'#9ca3af'}}>Expires: December 31, 2025</div>
              </div>
              <Button variant="outline" className="w-full justify-center">Manage Subscription</Button>
            </div>
          </Card>
          <Card>
            <CardHeader title="Security"/>
            <div className="p-5 space-y-2">
              <Button variant="outline" className="w-full justify-center" onClick={()=>toast('Password change email sent')}>🔒 Change Password</Button>
              <Button variant="outline" className="w-full justify-center" onClick={()=>toast('2FA setup')}>🛡️ Enable 2FA</Button>
              <Button variant="danger" className="w-full justify-center" onClick={async()=>{await logout?.();navigate('/login');}}>🚪 Sign Out</Button>
            </div>
          </Card>
          <Card>
            <CardHeader title="Notifications"/>
            <div className="px-5 pb-3">
              {[['Email Notifications','Receive booking & payment emails',true],['SMS Alerts','Urgent event SMS alerts',true],['Payment Reminders','Auto-remind customers',true],['WhatsApp Integration','Send via WhatsApp',false]].map(([t,d,on])=>(
                <div key={t} className="flex items-center justify-between py-3" style={{borderBottom:'1px solid rgba(201,169,110,0.06)'}}>
                  <div><div className="text-sm" style={{color:'#f2ede6'}}>{t}</div><div className="text-xs" style={{color:'#6b6458'}}>{d}</div></div>
                  <div className="relative cursor-pointer" style={{width:40,height:22,background:on?'#c9a96e':'#141d35',borderRadius:11,border:'1px solid rgba(201,169,110,0.2)'}}
                    onClick={()=>toast(`${t} ${on?'disabled':'enabled'}`)}>
                    <div style={{position:'absolute',top:2,width:16,height:16,background:on?'#030508':'#6b6458',borderRadius:'50%',transition:'all 0.3s',[on?'right':'left']:2}}/>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// Simple stubs for remaining pages
export function EventDetailPage() {
  const navigate = useNavigate();
  return <div><PageHeader title="Event Detail"><Button variant="outline" size="sm" onClick={()=>navigate('/events')}>← Events</Button></PageHeader><Card><EmptyState icon="💐" title="Event Detail" description="Full event detail view with tasks, bookings, guests, and financials."/></Card></div>;
}
export function CreateEventPage() {
  const navigate = useNavigate();
  return <div><PageHeader title="Create New Event"><Button variant="outline" size="sm" onClick={()=>navigate('/events')}>← Events</Button></PageHeader><Card><div className="p-6"><div className="grid grid-cols-2 gap-4"><Input label="Event Name" placeholder="e.g., Sharma & Patel Wedding"/><Select label="Event Type" options={[{value:'wedding',label:'💍 Wedding'},{value:'reception',label:'🥂 Reception'},{value:'birthday',label:'🎂 Birthday'},{value:'corporate',label:'💼 Corporate'}]}/><Input label="Event Date" type="date"/><Input label="Guest Count" type="number" placeholder="300"/><Input label="Budget (₹)" type="number" placeholder="500000" className="col-span-2"/></div><div className="flex justify-end gap-3 mt-4"><Button variant="outline" onClick={()=>navigate('/events')}>Cancel</Button><Button onClick={()=>{toast.success('Event created! ✦');navigate('/events');}}>Create Event ✦</Button></div></div></Card></div>;
}
export function CustomerDetailPage() {
  const navigate = useNavigate();
  return <div><PageHeader title="Customer 360°"><Button variant="outline" size="sm" onClick={()=>navigate('/customers')}>← Customers</Button></PageHeader><Card><EmptyState icon="👤" title="Customer Detail" description="Full customer profile with events, notes, payments, and LTV analytics."/></Card></div>;
}
export function LeadsPage() {
  return <div><PageHeader title="Lead Management" subtitle="Sales pipeline and lead nurturing"/><div className="grid grid-cols-6 gap-3">{[['New',['Sanjay Mehta'],['#9ca3af']],['Contacted',['Rohit Verma'],['#60a5fa']],['Qualified',['Aditya Singh'],['#60a5fa']],['Proposal',[],['#fbbf24']],['Negotiation',[],['#fbbf24']],['Won',['Vikram Patel','Meera Iyer','Kavya Nambiar'],['#10b981']]].map(([stage,leads,colors])=><div key={stage}><div className="rounded-xl p-3 mb-2 text-center" style={{background:'#141d35',border:'1px solid rgba(201,169,110,0.08)'}}><span className="font-semibold text-xs" style={{color:colors[0]}}>{stage}</span><div className="text-xs mt-0.5" style={{color:'#6b6458'}}>{leads.length} leads</div></div>{leads.map(l=><div key={l} className="rounded-xl p-3 mb-2 text-xs" style={{background:'#19233e',color:'#9ca3af',border:'1px solid rgba(201,169,110,0.06)'}}>{l}</div>)}</div>)}</div></div>;
}
export function VendorDetailPage() {
  const navigate = useNavigate();
  return <div><PageHeader title="Vendor Profile"><Button variant="outline" size="sm" onClick={()=>navigate('/vendors')}>← Vendors</Button></PageHeader><Card><EmptyState icon="🏪" title="Vendor Detail" description="Vendor profile with packages, reviews, booking history, and performance metrics."/></Card></div>;
}
export function VenuesPage() {
  return <div><PageHeader title="Venues" subtitle="Manage venue inventory and availability"><Button size="sm" onClick={()=>toast('Add venue form')}>+ Add Venue</Button></PageHeader><div className="grid grid-cols-1 md:grid-cols-2 gap-5">{[{name:'The Grand Palace Banquet',city:'Triplicane, Chennai',cap:1000,price:'₹2,50,000/day',type:'Indoor',rating:4.9,img:'🏛️'},{name:'Coastal Breeze Garden',city:'Besant Nagar',cap:500,price:'₹1,20,000/day',type:'Outdoor',rating:4.7,img:'🌿'},{name:'Jade Convention Center',city:'Porur, Chennai',cap:2000,price:'₹4,50,000/day',type:'Indoor',rating:4.8,img:'🏢'},{name:'Bloom Garden Lawn',city:'Velachery',cap:400,price:'₹90,000/day',type:'Outdoor',rating:4.6,img:'🌸'}].map(v=><div key={v.name} className="rounded-xl p-5 cursor-pointer transition-all" style={{background:'#19233e',border:'1px solid rgba(201,169,110,0.08)'}} onMouseEnter={e=>e.currentTarget.style.borderColor='rgba(201,169,110,0.2)'} onMouseLeave={e=>e.currentTarget.style.borderColor='rgba(201,169,110,0.08)'}><div className="flex justify-between mb-4"><div className="text-4xl">{v.img}</div><Badge color="green">Available</Badge></div><div className="font-semibold text-base mb-1" style={{color:'#f2ede6'}}>{v.name}</div><div className="text-xs mb-4" style={{color:'#6b6458'}}>📍 {v.city}</div><div className="grid grid-cols-2 gap-3 mb-4"><div className="rounded-lg p-3 text-center" style={{background:'#141d35'}}><div style={{fontFamily:'Cinzel,serif',fontSize:18,fontWeight:700,color:'#c9a96e'}}>{v.cap.toLocaleString()}</div><div className="text-[10px] mt-0.5" style={{color:'#6b6458'}}>MAX GUESTS</div></div><div className="rounded-lg p-3 text-center" style={{background:'#141d35'}}><div className="font-bold text-sm" style={{color:'#f2ede6'}}>{v.price}</div><div className="text-[10px] mt-0.5" style={{color:'#6b6458'}}>PRICING</div></div></div><div className="flex justify-between items-center"><div><Badge color={v.type==='Indoor'?'blue':'green'}>{v.type}</Badge><span className="ml-2 text-xs" style={{color:'#f59e0b'}}>★ {v.rating}</span></div><Button variant="outline" size="sm" onClick={()=>toast('Checking availability…')}>Check Availability</Button></div></div>)}</div></div>;
}
export function InvoiceDetailPage() {
  const navigate = useNavigate();
  return <div><PageHeader title="Invoice Detail"><Button variant="outline" size="sm" onClick={()=>navigate('/finance/invoices')}>← Invoices</Button></PageHeader><Card><EmptyState icon="📄" title="Invoice Detail" description="Full invoice with line items, payment history, and PDF generation."/></Card></div>;
}
export function RSVPPage() {
  return <div className="min-h-screen flex items-center justify-center" style={{background:'#030508'}}><div className="max-w-md w-full mx-4 rounded-2xl p-10" style={{background:'#0f1628',border:'1px solid rgba(201,169,110,0.2)'}}><div className="text-center mb-6"><div className="text-5xl mb-3">💌</div><h1 style={{fontFamily:'Cinzel,serif',fontSize:22,color:'#c9a96e'}}>You're Invited!</h1><p className="text-sm mt-2" style={{color:'#9ca3af'}}>Vikram & Priya Wedding · Nov 15, 2025</p></div><div className="space-y-3"><button className="w-full py-3 rounded-xl font-medium text-sm" style={{background:'rgba(16,185,129,0.15)',border:'1px solid rgba(16,185,129,0.3)',color:'#10b981'}} onClick={()=>toast.success('RSVP confirmed ✅')}>✅ Yes, I'll be attending</button><button className="w-full py-3 rounded-xl font-medium text-sm" style={{background:'rgba(245,158,11,0.15)',border:'1px solid rgba(245,158,11,0.3)',color:'#f59e0b'}} onClick={()=>toast('Maybe noted')}>❓ Maybe</button><button className="w-full py-3 rounded-xl font-medium text-sm" style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.2)',color:'#ef4444'}} onClick={()=>toast('Decline noted')}>❌ Sorry, I can't make it</button></div></div></div>;
}
export function NotFoundPage() {
  const navigate = useNavigate();
  return <div className="min-h-screen flex items-center justify-center" style={{background:'#030508'}}><div className="text-center"><div style={{fontFamily:'Cinzel,serif',fontSize:80,color:'rgba(201,169,110,0.2)'}}>404</div><h1 style={{fontFamily:'Cinzel,serif',fontSize:24,color:'#c9a96e',marginBottom:8}}>Page Not Found</h1><p className="text-sm mb-8" style={{color:'#6b6458'}}>The page you're looking for doesn't exist.</p><button className="btn-gold text-sm" onClick={()=>navigate('/dashboard')}>← Go to Dashboard</button></div></div>;
}

// Store reference for SettingsPage


// ─── MOCK DATA ─────────────────────────────────────────
const MOCK_CAL_EVENTS = [
  {id:1,event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',customer:'Vikram Patel',status:'confirmed'},
  {id:6,event_name:'Deepika & Rahul Engagement',event_date:'2025-11-01',customer:'Deepika Rao',status:'in_progress'},
];
const MOCK_CUSTOMERS = [
  {id:1,first_name:'Vikram',last_name:'Patel',phone:'+91-9876543214',email:'vikram.patel@gmail.com',priority:'vip',lead_status:'won',total_events:3,lifetime_value:1850000,assigned_to_name:'Rahul Menon',source:'Referral'},
  {id:2,first_name:'Ananya',last_name:'Krishnan',phone:'+91-9712345678',email:'ananya.k@gmail.com',priority:'high',lead_status:'confirmed',total_events:1,lifetime_value:620000,assigned_to_name:'Rahul Menon',source:'Social Media'},
  {id:3,first_name:'Meera',last_name:'Iyer',phone:'+91-9934567890',email:'meera.iyer@gmail.com',priority:'vip',lead_status:'won',total_events:2,lifetime_value:2280000,assigned_to_name:'Sneha Krishnan',source:'Walk In'},
  {id:4,first_name:'Kavya',last_name:'Nambiar',phone:'+91-9756789012',email:'kavya.n@gmail.com',priority:'high',lead_status:'won',total_events:4,lifetime_value:1420000,assigned_to_name:'Rahul Menon',source:'Referral'},
  {id:5,first_name:'Rohit',last_name:'Verma',phone:'+91-9823456789',email:'rohit.verma@gmail.com',priority:'medium',lead_status:'proposal_sent',total_events:0,lifetime_value:0,assigned_to_name:'Rahul Menon',source:'Website'},
];
const MOCK_VENDORS = [
  {id:1,business_name:'Star Catering Services',category:'Catering',city:'Chennai',rating:4.8,total_reviews:127,total_events:89,min_price:50000,max_price:500000,approval_status:'approved'},
  {id:2,business_name:'Pixel Perfect Photography',category:'Photography',city:'Chennai',rating:4.9,total_reviews:234,total_events:156,min_price:30000,max_price:200000,approval_status:'approved'},
  {id:3,business_name:'Dream Decor Studio',category:'Decoration',city:'Chennai',rating:4.9,total_reviews:312,total_events:201,min_price:20000,max_price:300000,approval_status:'approved'},
  {id:4,business_name:'Glamour House Makeup',category:'Makeup & Beauty',city:'Chennai',rating:4.7,total_reviews:445,total_events:320,min_price:8000,max_price:50000,approval_status:'approved'},
  {id:5,business_name:'Beat Masters DJ',category:'DJ & Music',city:'Chennai',rating:4.6,total_reviews:78,total_events:54,min_price:15000,max_price:80000,approval_status:'approved'},
  {id:6,business_name:'Petal Paradise Flowers',category:'Florals',city:'Chennai',rating:4.8,total_reviews:189,total_events:134,min_price:10000,max_price:100000,approval_status:'approved'},
  {id:7,business_name:'Sweet Memories Bakers',category:'Wedding Cake',city:'Chennai',rating:4.9,total_reviews:267,total_events:198,min_price:5000,max_price:50000,approval_status:'approved'},
  {id:8,business_name:'Cinematic Tales Videography',category:'Videography',city:'Chennai',rating:4.8,total_reviews:98,total_events:72,min_price:40000,max_price:250000,approval_status:'approved'},
];
const MOCK_BOOKINGS = [
  {id:1,booking_code:'BK-2025-0001',event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',vendor_name:'Star Catering Services',vendor_category:'Catering',booking_date:'2025-11-15',quoted_price:200000,agreed_price:180000,status:'confirmed'},
  {id:2,booking_code:'BK-2025-0002',event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',vendor_name:'Pixel Perfect Photography',vendor_category:'Photography',booking_date:'2025-11-15',quoted_price:100000,agreed_price:95000,status:'confirmed'},
  {id:3,booking_code:'BK-2025-0003',event_name:'Ananya Reception',event_code:'EVT-2025-0002',vendor_name:'Star Catering Services',vendor_category:'Catering',booking_date:'2025-12-05',quoted_price:90000,agreed_price:80000,status:'pending'},
  {id:4,booking_code:'BK-2025-0004',event_name:'Kavya Birthday',event_code:'EVT-2025-0004',vendor_name:'Beat Masters DJ',vendor_category:'DJ & Music',booking_date:'2025-10-20',quoted_price:25000,agreed_price:22000,status:'completed'},
];
const MOCK_GUESTS = [
  {id:1,first_name:'Rajesh',last_name:'Patel',relation:'Father of Groom',side:'groom',category:'family',phone:'+91-9000000001',rsvp_status:'attending',meal_preference:'non_veg',table_number:'T1'},
  {id:2,first_name:'Sunita',last_name:'Patel',relation:'Mother of Groom',side:'groom',category:'family',phone:'+91-9000000002',rsvp_status:'attending',meal_preference:'veg',table_number:'T1'},
  {id:3,first_name:'Preethi',last_name:'Krishnan',relation:'Father of Bride',side:'bride',category:'family',phone:'+91-9000000003',rsvp_status:'attending',meal_preference:'veg',table_number:'T2'},
  {id:4,first_name:'Nikhil',last_name:'Sharma',relation:'College Friend',side:'groom',category:'friend',phone:'+91-9000000007',rsvp_status:'attending',meal_preference:'non_veg',table_number:'T5'},
  {id:5,first_name:'Divya',last_name:'Menon',relation:'School Friend',side:'bride',category:'friend',phone:'+91-9000000008',rsvp_status:'maybe',meal_preference:'veg',table_number:'T6'},
  {id:6,first_name:'Kiran',last_name:'Nair',relation:'Colleague',side:'mutual',category:'colleague',phone:'+91-9000000009',rsvp_status:'not_attending',meal_preference:null,table_number:null},
];
const MOCK_TASKS = [
  {id:1,title:'Confirm catering menu',event_name:'Vikram & Priya Wedding',category:'Catering',priority:'high',status:'completed',due_date:'2025-09-15'},
  {id:2,title:'Send invitations to 500 guests',event_name:'Vikram & Priya Wedding',category:'Guest Mgmt',priority:'critical',status:'in_progress',due_date:'2025-10-01'},
  {id:3,title:'Arrange mehendi artist',event_name:'Vikram & Priya Wedding',category:'Beauty',priority:'medium',status:'pending',due_date:'2025-10-15'},
  {id:4,title:'Coordinate DJ & Music setup',event_name:'Vikram & Priya Wedding',category:'Entertainment',priority:'medium',status:'pending',due_date:'2025-10-20'},
  {id:5,title:'Finalize guest seating chart',event_name:'Ananya & Kiran Reception',category:'Guest Mgmt',priority:'medium',status:'pending',due_date:'2025-11-25'},
  {id:6,title:'Book bridal makeup artist',event_name:'Meera & Arjun Wedding',category:'Beauty',priority:'high',status:'pending',due_date:'2025-12-01'},
];
const MOCK_INVOICES = [
  {id:1,invoice_number:'INV-2025-00001',event_name:'Vikram & Priya Wedding',event_code:'EVT-2025-0001',customer_name:'Vikram Patel',invoice_date:'2025-09-01',due_date:'2025-09-15',grand_total:434240,amount_paid:300000,balance_due:134240,status:'partial'},
  {id:2,invoice_number:'INV-2025-00002',event_name:"Kavya Birthday 30th",event_code:'EVT-2025-0004',customer_name:'Kavya Nambiar',invoice_date:'2025-09-15',due_date:'2025-09-30',grand_total:126260,amount_paid:126260,balance_due:0,status:'paid'},
  {id:3,invoice_number:'INV-2025-00003',event_name:'Ananya & Kiran Reception',event_code:'EVT-2025-0002',customer_name:'Ananya Krishnan',invoice_date:'2025-10-01',due_date:'2025-10-15',grand_total:159300,amount_paid:150000,balance_due:9300,status:'partial'},
];
const MOCK_PAYMENTS = [
  {id:1,payment_code:'PAY-2025-0001',customer:'Vikram Patel',amount:300000,method:'Bank Transfer',date:'2025-09-01',type:'Advance',status:'completed'},
  {id:2,payment_code:'PAY-2025-0002',customer:'Kavya Nambiar',amount:126260,method:'UPI',date:'2025-09-15',type:'Full',status:'completed'},
  {id:3,payment_code:'PAY-2025-0003',customer:'Ananya Krishnan',amount:150000,method:'UPI',date:'2025-10-01',type:'Advance',status:'completed'},
];
const MOCK_EXPENSES = [
  {id:1,expense_date:'2025-10-18',category:'Decoration',description:'Floral arrangements',event_name:'Kavya Birthday',amount:15000,payment_method:'Cash',status:'paid'},
  {id:2,expense_date:'2025-10-15',category:'Catering',description:'Advance to Star Catering',event_name:'Kavya Birthday',amount:50000,payment_method:'Bank Transfer',status:'paid'},
  {id:3,expense_date:'2025-09-05',category:'Venue',description:'Grand Palace advance',event_name:'Vikram & Priya Wedding',amount:75000,payment_method:'Bank Transfer',status:'paid'},
  {id:4,expense_date:'2025-09-10',category:'Marketing',description:'Digital invitation design',event_name:'Vikram & Priya Wedding',amount:5000,payment_method:'UPI',status:'paid'},
];
