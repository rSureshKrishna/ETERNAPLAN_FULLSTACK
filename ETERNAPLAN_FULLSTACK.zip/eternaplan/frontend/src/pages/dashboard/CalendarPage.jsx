import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { dashboardService } from '../../services/services';
import { PageHeader, Card, CardHeader, StatusBadge, Button, PageSpinner } from '../../components/common';
import { fmt } from '../../utils/helpers';

const DOW = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

export default function CalendarPage() {
  const navigate = useNavigate();
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const r = await dashboardService.getCalendar(year, month + 1);
      setEvents(r.data.data);
    } catch {
      setEvents(MOCK_EVENTS.filter(e => {
        const d = new Date(e.event_date);
        return d.getFullYear() === year && d.getMonth() === month;
      }));
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [year, month]);

  const prev = () => { if (month===0) { setMonth(11); setYear(y=>y-1); } else setMonth(m=>m-1); };
  const next = () => { if (month===11) { setMonth(0); setYear(y=>y+1); } else setMonth(m=>m+1); };

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const prevDays = new Date(year, month, 0).getDate();

  const byDay = {};
  events.forEach(e => {
    const d = new Date(e.event_date).getDate();
    if (!byDay[d]) byDay[d] = [];
    byDay[d].push(e);
  });

  const catColor = {
    Wedding:'#c9a96e', Reception:'#8b5cf6', Engagement:'#ec4899',
    Birthday:'#f59e0b', Corporate:'#3b82f6', Anniversary:'#10b981',
  };

  const selectedEvents = selected ? (byDay[selected]||[]) : [];

  return (
    <div>
      <PageHeader title="Event Calendar" subtitle={`${MONTHS[month]} ${year}`}>
        <Button variant="outline" size="sm" onClick={prev}>◀ Prev</Button>
        <Button variant="outline" size="sm" onClick={() => { setMonth(now.getMonth()); setYear(now.getFullYear()); }}>Today</Button>
        <Button variant="outline" size="sm" onClick={next}>Next ▶</Button>
        <Button size="sm" onClick={() => navigate('/events/new')}>+ New Event</Button>
      </PageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Calendar Grid */}
        <div className="lg:col-span-3">
          <Card>
            <div className="p-5">
              {/* Header row */}
              <div className="grid grid-cols-7 mb-2">
                {DOW.map(d => (
                  <div key={d} className="text-center py-2" style={{fontSize:11, fontWeight:700, color:'#6b6458', letterSpacing:0.5}}>{d}</div>
                ))}
              </div>
              {/* Day cells */}
              <div className="grid grid-cols-7 gap-1">
                {/* Prev month */}
                {Array(firstDay).fill(null).map((_,i) => (
                  <div key={`p${i}`} className="min-h-20 rounded-lg p-1.5" style={{background:'transparent'}}>
                    <div style={{fontSize:12, color:'rgba(107,100,88,0.3)'}}>{prevDays - firstDay + i + 1}</div>
                  </div>
                ))}
                {/* Current month */}
                {Array(daysInMonth).fill(null).map((_,i) => {
                  const d = i+1;
                  const isToday = d===now.getDate() && month===now.getMonth() && year===now.getFullYear();
                  const isSelected = d === selected;
                  const dayEvents = byDay[d] || [];
                  return (
                    <div
                      key={d}
                      className="min-h-20 rounded-lg p-1.5 cursor-pointer transition-all"
                      style={{
                        background: isSelected ? 'rgba(201,169,110,0.15)' : isToday ? 'rgba(201,169,110,0.08)' : '#141d35',
                        border: isSelected ? '1px solid rgba(201,169,110,0.5)' : isToday ? '1px solid rgba(201,169,110,0.3)' : '1px solid transparent',
                      }}
                      onMouseEnter={e => !isToday && !isSelected && (e.currentTarget.style.background='#1e2a48')}
                      onMouseLeave={e => !isToday && !isSelected && (e.currentTarget.style.background='#141d35')}
                      onClick={() => setSelected(d === selected ? null : d)}>
                      <div className="flex justify-between items-start mb-1">
                        <span style={{
                          fontSize:13, fontWeight: isToday||isSelected ? 700 : 400,
                          color: isToday||isSelected ? '#c9a96e' : '#9ca3af',
                          background: isToday ? '#c9a96e' : 'transparent',
                          color: isToday ? '#030508' : isSelected ? '#c9a96e' : '#9ca3af',
                          width:22, height:22, display:'flex', alignItems:'center', justifyContent:'center',
                          borderRadius:'50%',
                        }}>{d}</span>
                        {dayEvents.length > 0 && (
                          <span className="text-xs font-bold px-1 rounded"
                            style={{background:'rgba(201,169,110,0.2)', color:'#c9a96e', fontSize:9}}>{dayEvents.length}</span>
                        )}
                      </div>
                      {dayEvents.slice(0,2).map((ev,ei) => (
                        <div
                          key={ei}
                          onClick={e => { e.stopPropagation(); navigate(`/events/${ev.id}`); }}
                          className="text-xs rounded px-1.5 py-0.5 mb-0.5 truncate"
                          style={{
                            background: `${catColor[ev.category||'Wedding']}20`,
                            color: catColor[ev.category||'Wedding'],
                            fontSize:10, border:`1px solid ${catColor[ev.category||'Wedding']}30`,
                          }}>
                          {ev.event_name}
                        </div>
                      ))}
                      {dayEvents.length > 2 && (
                        <div style={{fontSize:9, color:'#6b6458', marginTop:1}}>+{dayEvents.length-2} more</div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>

          {/* Selected Day Events */}
          {selected && selectedEvents.length > 0 && (
            <div className="mt-4">
              <h3 style={{fontFamily:'Cormorant Garamond,serif', fontSize:18, color:'#f2ede6', marginBottom:12}}>
                {MONTHS[month]} {selected} — {selectedEvents.length} event{selectedEvents.length>1?'s':''}
              </h3>
              {selectedEvents.map(ev => (
                <div key={ev.id}
                  onClick={() => navigate(`/events/${ev.id}`)}
                  className="flex items-center gap-4 p-4 rounded-xl mb-3 cursor-pointer transition-all"
                  style={{background:'#19233e', border:'1px solid rgba(201,169,110,0.08)'}}
                  onMouseEnter={e => e.currentTarget.style.borderColor='rgba(201,169,110,0.25)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor='rgba(201,169,110,0.08)'}>
                  <div className="w-1 self-stretch rounded-full flex-shrink-0"
                    style={{background: catColor[ev.category||'Wedding']}} />
                  <div className="flex-1 min-w-0">
                    <div style={{fontSize:14, fontWeight:500, color:'#f2ede6'}}>{ev.event_name}</div>
                    <div style={{fontSize:12, color:'#6b6458'}}>{ev.customer_name || ev.customer} · {fmt.time(ev.event_time)}</div>
                  </div>
                  <StatusBadge type="event" value={ev.status} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Legend */}
          <Card>
            <CardHeader title="Event Types" />
            <div className="px-5 pb-4 space-y-2">
              {Object.entries(catColor).map(([cat, color]) => (
                <div key={cat} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{background:color}} />
                  <span style={{fontSize:13, color:'#9ca3af'}}>{cat}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader title="This Month" />
            <div className="px-3 pb-3">
              {loading ? <div className="py-4 text-center" style={{color:'#6b6458',fontSize:12}}>Loading…</div>
                : events.length === 0
                  ? <div className="py-4 text-center" style={{color:'#6b6458',fontSize:12}}>No events this month</div>
                  : events.map(ev => (
                    <div key={ev.id}
                      onClick={() => navigate(`/events/${ev.id}`)}
                      className="flex items-center gap-3 p-3 rounded-xl mb-2 cursor-pointer transition-all"
                      style={{background:'#141d35'}}
                      onMouseEnter={e => e.currentTarget.style.background='#1e2a48'}
                      onMouseLeave={e => e.currentTarget.style.background='#141d35'}>
                      <div className="rounded-lg text-center py-1.5 px-2 flex-shrink-0"
                        style={{background:'rgba(201,169,110,0.08)', border:'1px solid rgba(201,169,110,0.15)', minWidth:44}}>
                        <div style={{fontFamily:'Cinzel,serif', fontSize:16, fontWeight:700, color:'#c9a96e', lineHeight:1}}>
                          {new Date(ev.event_date).getDate()}
                        </div>
                        <div style={{fontSize:9, color:'#6b6458', letterSpacing:1, textTransform:'uppercase'}}>
                          {MONTHS[new Date(ev.event_date).getMonth()].slice(0,3)}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <div style={{fontSize:12, fontWeight:500, color:'#f2ede6', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>
                          {ev.event_name}
                        </div>
                        <div style={{fontSize:10, color:'#6b6458'}}>{ev.category}</div>
                      </div>
                    </div>
                  ))
              }
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

const MOCK_EVENTS = [
  {id:1,event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',event_time:'09:00:00',status:'confirmed',category:'Wedding',customer_name:'Vikram Patel'},
  {id:6,event_name:'Deepika & Rahul Engagement',event_date:'2025-11-01',event_time:'17:00:00',status:'in_progress',category:'Engagement',customer_name:'Deepika Rao'},
  {id:2,event_name:'Ananya & Kiran Reception',event_date:'2025-12-05',event_time:'19:00:00',status:'planning',category:'Reception',customer_name:'Ananya Krishnan'},
  {id:5,event_name:'TechSol Corporate Gala',event_date:'2025-12-20',event_time:'18:00:00',status:'planning',category:'Corporate',customer_name:'Aditya Singh'},
  {id:3,event_name:'Meera & Arjun Grand Wedding',event_date:'2026-01-18',event_time:'08:00:00',status:'confirmed',category:'Wedding',customer_name:'Meera Iyer'},
];
