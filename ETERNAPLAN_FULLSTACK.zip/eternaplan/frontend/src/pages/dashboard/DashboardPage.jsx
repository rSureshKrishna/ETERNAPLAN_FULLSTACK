import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Chart, registerables } from 'chart.js';
import { dashboardService } from '../../services/services';
import { KpiCard, Card, CardHeader, StatusBadge, Progress, PageSpinner, StatRow, EmptyState } from '../../components/common';
import { fmt } from '../../utils/helpers';

Chart.register(...registerables);

const CHART_DEFAULTS = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { backgroundColor:'#141d35', borderColor:'rgba(201,169,110,0.3)', borderWidth:1, titleColor:'#f2ede6', bodyColor:'#9ca3af' } },
  scales: {
    x: { grid:{ color:'rgba(201,169,110,0.05)' }, ticks:{ color:'#6b6458', font:{size:11} } },
    y: { grid:{ color:'rgba(201,169,110,0.05)' }, ticks:{ color:'#6b6458', font:{size:11} } },
  },
};

export default function DashboardPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const revenueRef = useRef(); const categoryRef = useRef(); const methodsRef = useRef();
  const charts = useRef({});

  useEffect(() => {
    dashboardService.getOverview()
      .then(r => setData(r.data.data))
      .catch(() => {
        // Use mock data when API not available
        setData(MOCK_DATA);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!data) return;
    const destroy = (key) => { try { charts.current[key]?.destroy(); } catch {} };

    // Revenue chart
    if (revenueRef.current) {
      destroy('revenue');
      const months = data.monthly_revenue?.map(m => m.month_label) || MOCK_DATA.monthly_revenue.map(m=>m.month_label);
      const rev    = data.monthly_revenue?.map(m => +m.revenue) || MOCK_DATA.monthly_revenue.map(m=>m.revenue);
      const exp    = data.monthly_revenue?.map(m => +m.expenses) || MOCK_DATA.monthly_revenue.map(m=>m.expenses);
      charts.current.revenue = new Chart(revenueRef.current, {
        type:'line',
        data:{ labels:months, datasets:[
          { label:'Revenue', data:rev, borderColor:'#c9a96e', backgroundColor:'rgba(201,169,110,0.08)', fill:true, tension:0.4, pointRadius:3, borderWidth:2 },
          { label:'Expenses',data:exp, borderColor:'rgba(239,68,68,0.6)', backgroundColor:'rgba(239,68,68,0.04)', fill:true, tension:0.4, pointRadius:3, borderWidth:1.5, borderDash:[4,4] },
        ]},
        options:{ ...CHART_DEFAULTS, plugins:{ ...CHART_DEFAULTS.plugins, legend:{ display:true, labels:{ color:'#9ca3af', font:{size:11}, boxWidth:10, padding:16 } } } },
      });
    }
    // Category donut
    if (categoryRef.current) {
      destroy('category');
      const cats = data.category_distribution || MOCK_DATA.category_distribution;
      charts.current.category = new Chart(categoryRef.current, {
        type:'doughnut',
        data:{ labels:cats.map(c=>c.name), datasets:[{ data:cats.map(c=>c.count), backgroundColor:['#c9a96e','#8b5cf6','#3b82f6','#f59e0b','#ec4899','#10b981'], borderWidth:0, hoverOffset:6 }] },
        options:{ responsive:true, maintainAspectRatio:false, cutout:'65%', plugins:{ legend:{ position:'bottom', labels:{ color:'#9ca3af', font:{size:11}, padding:10, boxWidth:10 } }, tooltip:CHART_DEFAULTS.plugins.tooltip } },
      });
    }
    // Payment methods bar
    if (methodsRef.current) {
      destroy('methods');
      const pm = data.payment_methods || MOCK_DATA.payment_methods;
      charts.current.methods = new Chart(methodsRef.current, {
        type:'bar',
        data:{ labels:pm.map(p=>p.payment_method), datasets:[{ data:pm.map(p=>+p.total), backgroundColor:'rgba(201,169,110,0.7)', borderRadius:6, borderSkipped:false }] },
        options:{ ...CHART_DEFAULTS },
      });
    }
    return () => { Object.values(charts.current).forEach(c => { try{c.destroy()}catch{} }); };
  }, [data]);

  if (loading) return <PageSpinner />;

  const kpi = data?.kpi || MOCK_DATA.kpi;
  const upcoming = data?.upcoming_events || MOCK_DATA.upcoming_events;
  const activities = data?.recent_activities || MOCK_DATA.recent_activities;
  const tasks = data?.task_summary || MOCK_DATA.task_summary;
  const outstanding = data?.outstanding_balances || MOCK_DATA.outstanding_balances;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 style={{fontFamily:'Cormorant Garamond,serif',fontSize:28,fontWeight:600,color:'#f2ede6'}}>Dashboard</h1>
          <p className="text-sm mt-1" style={{color:'#6b6458'}}>Welcome back — here's what's happening today</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-gold text-sm" onClick={()=>navigate('/events/new')}>+ New Event</button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KpiCard icon="💰" value={fmt.lakh(kpi.total_revenue)} label="Total Revenue 2025" trend="23.4% vs last year" trendUp accentFrom="#c9a96e" accentTo="#e8c98a" iconBg="rgba(201,169,110,0.1)"/>
        <KpiCard icon="💐" value={kpi.total_events} label="Active Events" trend="2 new this month" trendUp accentFrom="#8b5cf6" accentTo="#a78bfa" iconBg="rgba(139,92,246,0.1)"/>
        <KpiCard icon="👥" value={kpi.total_customers} label="Total Customers" trend="3 new this month" trendUp accentFrom="#10b981" accentTo="#34d399" iconBg="rgba(16,185,129,0.1)"/>
        <KpiCard icon="🏪" value={kpi.total_vendors} label="Active Vendors" trend="2 pending approval" trendUp={false} accentFrom="#f59e0b" accentTo="#fbbf24" iconBg="rgba(245,158,11,0.1)"/>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5 mb-5">
        <div className="lg:col-span-3">
          <Card>
            <CardHeader title="Revenue & Expenses — 2025" />
            <div className="p-5"><div style={{height:220,position:'relative'}}><canvas ref={revenueRef}/></div></div>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Card>
            <CardHeader title="Events by Category" />
            <div className="p-5"><div style={{height:220,position:'relative'}}><canvas ref={categoryRef}/></div></div>
          </Card>
        </div>
      </div>

      {/* Content Row */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5 mb-5">
        {/* Upcoming Events */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader title="Upcoming Events" action={
              <button className="text-xs px-3 py-1.5 rounded-lg" style={{color:'#c9a96e',background:'rgba(201,169,110,0.1)',border:'1px solid rgba(201,169,110,0.2)'}} onClick={()=>navigate('/events')}>View All</button>
            }/>
            <div className="p-3">
              {upcoming.map(ev => (
                <div key={ev.id} onClick={()=>navigate(`/events/${ev.id}`)}
                  className="flex items-center gap-4 p-3 rounded-xl mb-2 cursor-pointer transition-colors"
                  style={{background:'#141d35',border:'1px solid rgba(201,169,110,0.06)'}}
                  onMouseEnter={e=>e.currentTarget.style.borderColor='rgba(201,169,110,0.15)'}
                  onMouseLeave={e=>e.currentTarget.style.borderColor='rgba(201,169,110,0.06)'}>
                  <div className="flex-shrink-0 rounded-xl text-center py-2 px-3" style={{background:'rgba(201,169,110,0.08)',border:'1px solid rgba(201,169,110,0.15)'}}>
                    <div style={{fontFamily:'Cinzel,serif',fontSize:20,fontWeight:700,color:'#c9a96e',lineHeight:1}}>
                      {new Date(ev.event_date).getDate()}
                    </div>
                    <div style={{fontSize:10,color:'#6b6458',letterSpacing:1,textTransform:'uppercase'}}>
                      {new Date(ev.event_date).toLocaleString('en',{month:'short'})}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate" style={{fontSize:13.5,color:'#f2ede6'}}>{ev.event_name}</div>
                    <div className="text-xs mt-0.5 truncate" style={{color:'#6b6458'}}>👤 {ev.customer_name || ev.customer} · {ev.days_away} days away</div>
                    <div className="mt-2 flex items-center gap-2">
                      <Progress value={ev.completion_pct} className="flex-1" />
                      <span style={{fontSize:11,color:'#6b6458'}}>{ev.completion_pct}%</span>
                    </div>
                  </div>
                  <StatusBadge type="event" value={ev.status}/>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right column */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          <Card>
            <CardHeader title="Task Overview"/>
            <div className="px-5 pb-3">
              <StatRow label="⚡ Critical Open" value={tasks.critical_open} valueColor="#ef4444"/>
              <StatRow label="⏳ Pending"       value={tasks.pending}/>
              <StatRow label="🔄 In Progress"   value={tasks.in_progress} valueColor="#3b82f6"/>
              <StatRow label="✅ Completed"      value={tasks.completed} valueColor="#10b981"/>
              <StatRow label="⚠️ Overdue"       value={tasks.overdue} valueColor="#f59e0b"/>
            </div>
          </Card>
          <Card>
            <CardHeader title="Outstanding Balances"/>
            <div className="px-5 pb-3">
              {(outstanding || []).slice(0,3).map((o,i)=>(
                <StatRow key={i} label={o.customer_name || o.customer} value={fmt.currency(o.balance_due)} valueColor="#f59e0b"/>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card>
          <CardHeader title="Payment Methods"/>
          <div className="p-5"><div style={{height:180,position:'relative'}}><canvas ref={methodsRef}/></div></div>
        </Card>
        <Card>
          <CardHeader title="Recent Activity"/>
          <div className="px-5 py-3">
            {(activities || MOCK_DATA.activities).slice(0,5).map((a,i)=>(
              <div key={i} className="flex gap-3 pb-4 relative">
                <div className="flex-shrink-0 w-2 h-2 rounded-full mt-1.5" style={{background:'#c9a96e'}}/>
                <div>
                  <div className="text-xs font-medium" style={{color:'#f2ede6'}}>{a.action || a.description}</div>
                  <div className="text-xs mt-0.5" style={{color:'#6b6458'}}>{a.user_name || a.user} · {a.created_at || a.time}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// Mock data for offline demo
const MOCK_DATA = {
  kpi:{ total_revenue:1420000, total_events:6, total_customers:7, total_vendors:10, upcoming_events:5 },
  monthly_revenue:[
    {month_label:'Jan',revenue:42000,expenses:25000},{month_label:'Feb',revenue:58000,expenses:30000},
    {month_label:'Mar',revenue:38000,expenses:20000},{month_label:'Apr',revenue:72000,expenses:40000},
    {month_label:'May',revenue:91000,expenses:50000},{month_label:'Jun',revenue:68000,expenses:38000},
    {month_label:'Jul',revenue:84000,expenses:45000},{month_label:'Aug',revenue:110000,expenses:60000},
    {month_label:'Sep',revenue:96000,expenses:52000},{month_label:'Oct',revenue:128000,expenses:70000},
    {month_label:'Nov',revenue:145000,expenses:80000},{month_label:'Dec',revenue:162000,expenses:85000},
  ],
  category_distribution:[
    {name:'Wedding',count:35,color:'#c9a96e'},{name:'Reception',count:20,color:'#8b5cf6'},
    {name:'Corporate',count:15,color:'#3b82f6'},{name:'Birthday',count:18,color:'#f59e0b'},
    {name:'Engagement',count:12,color:'#ec4899'},
  ],
  payment_methods:[
    {payment_method:'Bank Transfer',total:375000},{payment_method:'UPI',total:176260},
    {payment_method:'Cash',total:107000},{payment_method:'Cheque',total:67800},
  ],
  upcoming_events:[
    {id:1,event_name:'Vikram & Priya Wedding',event_date:'2025-11-15',customer:'Vikram Patel',status:'confirmed',completion_pct:68,days_away:7},
    {id:2,event_name:'Ananya & Kiran Reception',event_date:'2025-12-05',customer:'Ananya Krishnan',status:'planning',completion_pct:32,days_away:27},
    {id:3,event_name:'Meera & Arjun Grand Wedding',event_date:'2026-01-18',customer:'Meera Iyer',status:'confirmed',completion_pct:25,days_away:71},
    {id:5,event_name:'TechSol Corporate Gala',event_date:'2025-12-20',customer:'Aditya Singh',status:'planning',completion_pct:18,days_away:42},
  ],
  task_summary:{critical_open:2,pending:5,in_progress:3,completed:8,overdue:1},
  outstanding_balances:[
    {customer:'Vikram Patel',balance_due:134240},{customer:'Ananya Krishnan',balance_due:9300},
  ],
  activities:[
    {description:'Payment ₹3,00,000 received',user:'Priya Nair',time:'2 hours ago'},
    {description:'New booking BK-2025-0001 confirmed',user:'Rahul Menon',time:'5 hours ago'},
    {description:'Guest list updated — 48 guests added',user:'Sneha Krishnan',time:'Yesterday'},
    {description:'Invoice INV-0003 sent to Ananya',user:'Priya Nair',time:'Yesterday'},
    {description:'Vendor review approved for Star Catering',user:'Priya Nair',time:'2 days ago'},
  ],
};
