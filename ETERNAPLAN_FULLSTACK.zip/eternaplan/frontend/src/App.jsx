import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import AppLayout from './components/layout/AppLayout';
import LoginPage       from './pages/auth/LoginPage';
import RegisterPage    from './pages/auth/RegisterPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import ResetPasswordPage  from './pages/auth/ResetPasswordPage';
import DashboardPage   from './pages/dashboard/DashboardPage';
import CalendarPage    from './pages/dashboard/CalendarPage';
import EventsPage      from './pages/events/EventsPage';
import EventDetailPage from './pages/events/EventDetailPage';
import CreateEventPage from './pages/events/CreateEventPage';
import CustomersPage   from './pages/customers/CustomersPage';
import CustomerDetailPage from './pages/customers/CustomerDetailPage';
import LeadsPage       from './pages/customers/LeadsPage';
import VendorsPage     from './pages/vendors/VendorsPage';
import VendorDetailPage from './pages/vendors/VendorDetailPage';
import VenuesPage      from './pages/vendors/VenuesPage';
import BookingsPage    from './pages/bookings/BookingsPage';
import GuestsPage      from './pages/guests/GuestsPage';
import RSVPPage        from './pages/guests/RSVPPage';
import TasksPage       from './pages/tasks/TasksPage';
import InvoicesPage    from './pages/finance/InvoicesPage';
import InvoiceDetailPage from './pages/finance/InvoiceDetailPage';
import PaymentsPage    from './pages/finance/PaymentsPage';
import ExpensesPage    from './pages/finance/ExpensesPage';
import ReportsPage     from './pages/reports/ReportsPage';
import SettingsPage    from './pages/settings/SettingsPage';
import NotFoundPage    from './pages/NotFoundPage';

// Route guard
const ProtectedRoute = ({ children, roles }) => {
  const { user, isAuthenticated } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user?.role)) return <Navigate to="/dashboard" replace />;
  return children;
};

const PublicRoute = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : children;
};

export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/login"          element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/register"       element={<PublicRoute><RegisterPage /></PublicRoute>} />
      <Route path="/forgot-password"element={<PublicRoute><ForgotPasswordPage /></PublicRoute>} />
      <Route path="/reset-password" element={<PublicRoute><ResetPasswordPage /></PublicRoute>} />
      <Route path="/rsvp/:code"     element={<RSVPPage />} />

      {/* Protected — all under AppLayout */}
      <Route path="/" element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard"          element={<DashboardPage />} />
        <Route path="calendar"           element={<CalendarPage />} />
        <Route path="events"             element={<EventsPage />} />
        <Route path="events/new"         element={<CreateEventPage />} />
        <Route path="events/:id"         element={<EventDetailPage />} />
        <Route path="customers"          element={<CustomersPage />} />
        <Route path="customers/:id"      element={<CustomerDetailPage />} />
        <Route path="leads"              element={<LeadsPage />} />
        <Route path="vendors"            element={<VendorsPage />} />
        <Route path="vendors/:id"        element={<VendorDetailPage />} />
        <Route path="venues"             element={<VenuesPage />} />
        <Route path="bookings"           element={<BookingsPage />} />
        <Route path="guests"             element={<GuestsPage />} />
        <Route path="tasks"              element={<TasksPage />} />
        <Route path="finance/invoices"   element={<InvoicesPage />} />
        <Route path="finance/invoices/:id" element={<InvoiceDetailPage />} />
        <Route path="finance/payments"   element={<PaymentsPage />} />
        <Route path="finance/expenses"   element={<ExpensesPage />} />
        <Route path="reports"            element={<ReportsPage />} />
        <Route path="settings"           element={<SettingsPage />} />
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
