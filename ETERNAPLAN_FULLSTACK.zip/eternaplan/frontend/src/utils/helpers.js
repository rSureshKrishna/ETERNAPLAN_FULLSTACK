// utils/helpers.js

export const fmt = {
  currency: (n, curr = 'INR') =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: curr, maximumFractionDigits: 0 }).format(n || 0),

  number: (n) => new Intl.NumberFormat('en-IN').format(n || 0),

  date: (d, opts = {}) =>
    d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', ...opts }) : '—',

  dateTime: (d) =>
    d ? new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—',

  time: (t) => t ? t.substring(0, 5) : '—',

  percent: (n) => `${(n || 0).toFixed(1)}%`,

  lakh: (n) => {
    if (!n) return '₹0';
    if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)}Cr`;
    if (n >= 100000)   return `₹${(n / 100000).toFixed(1)}L`;
    if (n >= 1000)     return `₹${(n / 1000).toFixed(0)}K`;
    return `₹${n}`;
  },

  daysFrom: (d) => {
    if (!d) return null;
    return Math.ceil((new Date(d) - new Date()) / (1000 * 60 * 60 * 24));
  },

  initials: (name) => name ? name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2) : '??',
};

// Status badge config
export const STATUS = {
  event: {
    inquiry:     { label: 'Inquiry',     color: 'amber' },
    planning:    { label: 'Planning',    color: 'blue' },
    confirmed:   { label: 'Confirmed',   color: 'green' },
    in_progress: { label: 'In Progress', color: 'purple' },
    completed:   { label: 'Completed',   color: 'gray' },
    cancelled:   { label: 'Cancelled',   color: 'red' },
    postponed:   { label: 'Postponed',   color: 'amber' },
  },
  booking: {
    pending:     { label: 'Pending',     color: 'amber' },
    confirmed:   { label: 'Confirmed',   color: 'green' },
    in_progress: { label: 'In Progress', color: 'blue' },
    completed:   { label: 'Completed',   color: 'gray' },
    cancelled:   { label: 'Cancelled',   color: 'red' },
    no_show:     { label: 'No Show',     color: 'red' },
  },
  invoice: {
    draft:    { label: 'Draft',    color: 'gray' },
    sent:     { label: 'Sent',     color: 'blue' },
    viewed:   { label: 'Viewed',   color: 'purple' },
    partial:  { label: 'Partial',  color: 'amber' },
    paid:     { label: 'Paid',     color: 'green' },
    overdue:  { label: 'Overdue',  color: 'red' },
    cancelled:{ label: 'Cancelled',color: 'gray' },
  },
  lead: {
    new:           { label: 'New',           color: 'gray' },
    contacted:     { label: 'Contacted',     color: 'blue' },
    qualified:     { label: 'Qualified',     color: 'blue' },
    proposal_sent: { label: 'Proposal Sent', color: 'amber' },
    negotiation:   { label: 'Negotiation',   color: 'amber' },
    won:           { label: 'Won',           color: 'green' },
    lost:          { label: 'Lost',          color: 'red' },
    dormant:       { label: 'Dormant',       color: 'gray' },
  },
  task: {
    pending:     { label: 'Pending',     color: 'gray' },
    in_progress: { label: 'In Progress', color: 'blue' },
    completed:   { label: 'Completed',   color: 'green' },
    blocked:     { label: 'Blocked',     color: 'red' },
    cancelled:   { label: 'Cancelled',   color: 'gray' },
  },
  rsvp: {
    pending:       { label: 'Pending',       color: 'gray' },
    attending:     { label: 'Attending',     color: 'green' },
    not_attending: { label: 'Not Attending', color: 'red' },
    maybe:         { label: 'Maybe',         color: 'amber' },
  },
  approval: {
    pending:   { label: 'Pending',   color: 'amber' },
    approved:  { label: 'Approved',  color: 'green' },
    rejected:  { label: 'Rejected',  color: 'red' },
    suspended: { label: 'Suspended', color: 'gray' },
  },
};

export const BADGE_COLORS = {
  green:  'bg-green-500/10 text-green-400 border border-green-500/25',
  blue:   'bg-blue-500/10 text-blue-400 border border-blue-500/25',
  amber:  'bg-amber-500/10 text-amber-400 border border-amber-500/25',
  red:    'bg-red-500/10 text-red-400 border border-red-500/25',
  purple: 'bg-purple-500/10 text-purple-400 border border-purple-500/25',
  gold:   'bg-gold-500/10 text-gold-400 border border-gold-500/25',
  gray:   'bg-white/5 text-gray-400 border border-white/10',
};

export const PRIORITY_COLORS = {
  critical: 'red',
  high:     'amber',
  medium:   'blue',
  low:      'gray',
};

export const EVENT_CATEGORY_ICONS = {
  wedding:        '💍',
  reception:      '🥂',
  engagement:     '💕',
  'birthday-party': '🎂',
  'corporate-event':'💼',
  'baby-shower':  '👶',
  anniversary:    '🎊',
  conference:     '🎤',
};

export const VENDOR_ICONS = {
  catering:       '🍽️',
  photography:    '📷',
  videography:    '🎬',
  decoration:     '✨',
  'makeup-beauty':'💄',
  'dj-music':     '🎵',
  'flower-supplier':'🌸',
  'wedding-cake': '🎂',
  transportation: '🚗',
  lighting:       '💡',
  invitations:    '✉️',
  security:       '🛡️',
  'tent-canopy':  '⛺',
  'sound-system': '🔊',
};

export const PAYMENT_METHODS = [
  { value: 'cash',          label: 'Cash' },
  { value: 'upi',           label: 'UPI' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'cheque',        label: 'Cheque' },
  { value: 'card',          label: 'Card' },
  { value: 'online',        label: 'Online Gateway' },
  { value: 'other',         label: 'Other' },
];

export const MEAL_PREFS = [
  { value: 'veg',           label: '🥦 Vegetarian' },
  { value: 'non_veg',       label: '🍗 Non-Vegetarian' },
  { value: 'vegan',         label: '🌱 Vegan' },
  { value: 'jain',          label: '🙏 Jain' },
  { value: 'no_preference', label: 'No Preference' },
];

export const INDIAN_STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
  'Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka',
  'Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram',
  'Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana',
  'Tripura','Uttar Pradesh','Uttarakhand','West Bengal',
  'Delhi','Jammu & Kashmir','Ladakh','Puducherry','Chandigarh',
];

export const truncate = (str, n = 40) => str && str.length > n ? str.substring(0, n) + '…' : str;

export const classNames = (...classes) => classes.filter(Boolean).join(' ');

export const sleep = (ms) => new Promise(r => setTimeout(r, ms));

export const debounce = (fn, delay = 300) => {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
};
