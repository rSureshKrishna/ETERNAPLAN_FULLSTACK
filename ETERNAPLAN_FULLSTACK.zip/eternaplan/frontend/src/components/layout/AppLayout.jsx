import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { fmt } from '../../utils/helpers';
import toast from 'react-hot-toast';

const NAV = [
  { section: 'Overview', items: [
    { path: '/dashboard', icon: '⬡', label: 'Dashboard' },
    { path: '/calendar',  icon: '📅', label: 'Calendar', badge: null },
  ]},
  { section: 'Planning', items: [
    { path: '/events',    icon: '💐', label: 'Events' },
    { path: '/bookings',  icon: '📋', label: 'Bookings' },
    { path: '/guests',    icon: '👥', label: 'Guests' },
    { path: '/tasks',     icon: '✓',  label: 'Tasks' },
  ]},
  { section: 'CRM', items: [
    { path: '/customers', icon: '👤', label: 'Customers' },
    { path: '/leads',     icon: '🎯', label: 'Leads' },
  ]},
  { section: 'Vendors', items: [
    { path: '/vendors',   icon: '🏪', label: 'Vendors' },
    { path: '/venues',    icon: '🏛️', label: 'Venues' },
  ]},
  { section: 'Finance', items: [
    { path: '/finance/invoices', icon: '📄', label: 'Invoices' },
    { path: '/finance/payments', icon: '💳', label: 'Payments' },
    { path: '/finance/expenses', icon: '💰', label: 'Expenses' },
  ]},
  { section: 'System', items: [
    { path: '/reports',   icon: '📊', label: 'Analytics' },
    { path: '/settings',  icon: '⚙',  label: 'Settings' },
  ]},
];

export default function AppLayout() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    toast.success('Signed out successfully');
    navigate('/login');
  };

  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <div className="flex min-h-screen" style={{ background: '#030508' }}>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── Sidebar ── */}
      <aside
        className={`fixed top-0 left-0 bottom-0 z-50 flex flex-col transition-transform duration-300
          lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
        style={{ width: 260, background: '#070b14', borderRight: '1px solid rgba(201,169,110,0.08)' }}
      >
        {/* Logo */}
        <div className="px-5 py-6" style={{ borderBottom: '1px solid rgba(201,169,110,0.08)' }}>
          <div style={{ fontFamily: 'Cinzel,serif', fontSize: 16, fontWeight: 700, color: '#c9a96e', letterSpacing: 2 }}>
            ✦ ETERNAPLAAN
          </div>
          <div style={{ fontSize: 10, color: '#6b6458', letterSpacing: 1.5, marginTop: 3, textTransform: 'uppercase' }}>
            Event Excellence Platform
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          {NAV.map(({ section, items }) => (
            <div key={section} className="mb-5">
              <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: 2, color: '#6b6458', padding: '0 8px', marginBottom: 4, textTransform: 'uppercase' }}>
                {section}
              </div>
              {items.map(({ path, icon, label, badge }) => {
                const active = isActive(path);
                return (
                  <button
                    key={path}
                    onClick={() => { navigate(path); setSidebarOpen(false); }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-0.5 text-left transition-all relative"
                    style={{
                      fontSize: 13.5,
                      fontWeight: active ? 500 : 400,
                      color: active ? '#c9a96e' : '#9ca3af',
                      background: active ? 'rgba(201,169,110,0.08)' : 'transparent',
                      border: active ? '1px solid rgba(201,169,110,0.12)' : '1px solid transparent',
                    }}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-3/5 rounded-r"
                        style={{ background: '#c9a96e' }} />
                    )}
                    <span style={{ fontSize: 15, width: 20, textAlign: 'center', flexShrink: 0 }}>{icon}</span>
                    <span>{label}</span>
                    {badge && (
                      <span className="ml-auto text-xs font-bold px-1.5 py-0.5 rounded-full"
                        style={{ background: '#c9a96e', color: '#030508', fontSize: 10 }}>
                        {badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User footer */}
        <div className="p-3" style={{ borderTop: '1px solid rgba(201,169,110,0.08)' }}>
          <div className="flex items-center gap-3 p-2.5 rounded-lg cursor-pointer"
            style={{ background: '#0f1628' }}
            onClick={() => navigate('/settings')}>
            <div className="flex items-center justify-center rounded-full text-sm font-bold flex-shrink-0"
              style={{ width: 34, height: 34, background: 'linear-gradient(135deg,#9a7a4a,#c9a96e)', color: '#030508', fontFamily: 'Cinzel,serif' }}>
              {fmt.initials(user?.name || '')}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate" style={{ color: '#f2ede6' }}>{user?.name}</div>
              <div className="text-xs truncate" style={{ color: '#6b6458', textTransform: 'capitalize' }}>{user?.role?.replace('_', ' ')}</div>
            </div>
            <button onClick={(e) => { e.stopPropagation(); handleLogout(); }}
              className="text-xs px-2 py-1 rounded" style={{ color: '#6b6458' }}
              title="Sign out">⎋</button>
          </div>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-h-screen" style={{ marginLeft: 260 }}>
        {/* Topbar */}
        <header className="sticky top-0 z-30 flex items-center gap-4 px-7"
          style={{ height: 68, background: '#0f1628', borderBottom: '1px solid rgba(201,169,110,0.08)' }}>
          <button className="lg:hidden" onClick={() => setSidebarOpen(true)} style={{ color: '#9ca3af', fontSize: 20 }}>☰</button>

          <div className="flex-1" />

          {/* Search */}
          <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-lg"
            style={{ background: '#141d35', border: '1px solid rgba(201,169,110,0.08)', width: 260 }}>
            <span style={{ color: '#6b6458' }}>🔍</span>
            <input className="bg-transparent border-none outline-none text-sm w-full"
              style={{ color: '#f2ede6' }} placeholder="Search events, customers…" />
          </div>

          {/* Actions */}
          <button onClick={() => navigate('/events/new')}
            className="btn-gold hidden sm:flex" style={{ fontSize: 13 }}>
            + New Event
          </button>

          <button className="flex items-center justify-center rounded-lg relative"
            style={{ width: 38, height: 38, background: '#141d35', border: '1px solid rgba(201,169,110,0.08)', color: '#9ca3af', fontSize: 16 }}
            onClick={() => toast('3 new notifications', { icon: '🔔' })}>
            🔔
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full" style={{ background: '#ef4444' }} />
          </button>
        </header>

        {/* Page content */}
        <main className="flex-1 p-7 overflow-y-auto" style={{ background: '#0a0f1e' }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
