// components/common/index.jsx
import { BADGE_COLORS, STATUS } from '../../utils/helpers';

// ─── Badge ───────────────────────────────────────────────
export function Badge({ color = 'gray', children, size = 'sm' }) {
  const cls = BADGE_COLORS[color] || BADGE_COLORS.gray;
  return (
    <span className={`inline-flex items-center rounded-full font-semibold ${cls} ${size === 'xs' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-0.5 text-[11px]'}`}>
      {children}
    </span>
  );
}

export function StatusBadge({ type, value }) {
  const cfg = STATUS[type]?.[value] || { label: value, color: 'gray' };
  return <Badge color={cfg.color}>{cfg.label}</Badge>;
}

// ─── Button ──────────────────────────────────────────────
export function Button({ variant = 'gold', size = 'md', children, className = '', loading, disabled, ...props }) {
  const base = 'inline-flex items-center gap-2 rounded-lg font-medium transition-all cursor-pointer border-none outline-none disabled:opacity-50';
  const sizes = { xs: 'px-2.5 py-1 text-xs', sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2 text-sm', lg: 'px-5 py-2.5 text-sm' };
  const variants = {
    gold:    'btn-gold',
    outline: 'bg-transparent border border-white/10 text-gray-300 hover:border-gold-500/40 hover:text-gold-400',
    ghost:   'bg-transparent text-gray-400 hover:text-white hover:bg-white/5',
    danger:  'bg-red-500/10 border border-red-500/25 text-red-400 hover:bg-red-500/20',
    success: 'bg-green-500/10 border border-green-500/25 text-green-400 hover:bg-green-500/20',
  };
  return (
    <button disabled={disabled || loading} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...props}>
      {loading ? <span className="animate-spin">⟳</span> : children}
    </button>
  );
}

// ─── Card ────────────────────────────────────────────────
export function Card({ children, className = '', hover = false }) {
  return (
    <div className={`card-dark rounded-xl ${hover ? 'hover:border-gold-500/20 transition-colors cursor-pointer' : ''} ${className}`}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, action, className = '' }) {
  return (
    <div className={`flex items-center justify-between px-6 py-4 border-b border-white/5 ${className}`}>
      <div>
        <h3 style={{ fontFamily: 'Cormorant Garamond,serif', fontSize: 17, fontWeight: 600, color: '#f2ede6' }}>{title}</h3>
        {subtitle && <p className="text-xs mt-0.5" style={{ color: '#6b6458' }}>{subtitle}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}

// ─── KPI Card ────────────────────────────────────────────
export function KpiCard({ icon, value, label, trend, trendUp, accentFrom, accentTo, iconBg }) {
  return (
    <div className="rounded-xl p-5 relative overflow-hidden transition-all hover:-translate-y-0.5"
      style={{ background: '#19233e', border: '1px solid rgba(201,169,110,0.08)' }}>
      <div className="absolute top-0 left-0 right-0 h-0.5"
        style={{ background: `linear-gradient(90deg,${accentFrom},${accentTo})` }} />
      <div className="flex items-center justify-center rounded-xl mb-3.5"
        style={{ width: 44, height: 44, background: iconBg, fontSize: 20 }}>
        {icon}
      </div>
      <div style={{ fontFamily: 'Cinzel,serif', fontSize: 28, fontWeight: 700, color: '#f2ede6', lineHeight: 1, marginBottom: 4 }}>
        {value}
      </div>
      <div style={{ fontSize: 12, color: '#6b6458', fontWeight: 500 }}>{label}</div>
      {trend && (
        <div className="flex items-center gap-1 mt-2" style={{ fontSize: 12, color: trendUp ? '#10b981' : '#ef4444' }}>
          {trendUp ? '▲' : '▼'} {trend}
        </div>
      )}
    </div>
  );
}

// ─── Table ───────────────────────────────────────────────
export function Table({ columns, data, onRowClick, emptyMessage = 'No records found.' }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key} className="text-left px-4 py-3 whitespace-nowrap"
                style={{ fontSize: 10, fontWeight: 600, letterSpacing: 1.5, color: '#6b6458',
                  textTransform: 'uppercase', borderBottom: '1px solid rgba(201,169,110,0.08)' }}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="text-center py-12" style={{ color: '#6b6458' }}>
                {emptyMessage}
              </td>
            </tr>
          ) : data.map((row, i) => (
            <tr key={row.id || i}
              onClick={() => onRowClick?.(row)}
              className={`transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
              style={{ borderBottom: '1px solid rgba(201,169,110,0.04)' }}
              onMouseEnter={(e) => e.currentTarget.style.background = '#1e2a48'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
              {columns.map((col) => (
                <td key={col.key} className="px-4 py-3.5" style={{ fontSize: 13, color: '#9ca3af', verticalAlign: 'middle' }}>
                  {col.render ? col.render(row[col.key], row) : (row[col.key] ?? '—')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Modal ───────────────────────────────────────────────
export function Modal({ open, onClose, title, children, size = 'md' }) {
  if (!open) return null;
  const widths = { sm: 420, md: 540, lg: 700, xl: 900 };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(4px)' }}
      onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="rounded-2xl p-8 w-full overflow-y-auto max-h-[90vh]"
        style={{ maxWidth: widths[size], background: '#0f1628',
          border: '1px solid rgba(201,169,110,0.2)', boxShadow: '0 32px 80px rgba(0,0,0,0.7)' }}>
        <div className="flex items-center justify-between mb-6 pb-4"
          style={{ borderBottom: '1px solid rgba(201,169,110,0.08)' }}>
          <h2 style={{ fontFamily: 'Cormorant Garamond,serif', fontSize: 22, fontWeight: 600, color: '#f2ede6' }}>
            {title}
          </h2>
          <button onClick={onClose} style={{ color: '#6b6458', fontSize: 20, lineHeight: 1 }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── Spinner ─────────────────────────────────────────────
export function Spinner({ size = 'md' }) {
  const s = { sm: 16, md: 24, lg: 40 }[size];
  return (
    <div className="flex items-center justify-center">
      <div className="animate-spin rounded-full border-2 border-transparent"
        style={{ width: s, height: s, borderTopColor: '#c9a96e', borderRightColor: 'rgba(201,169,110,0.3)' }} />
    </div>
  );
}

export function PageSpinner() {
  return (
    <div className="flex-1 flex items-center justify-center min-h-64">
      <div className="text-center">
        <Spinner size="lg" />
        <p className="mt-4 text-sm" style={{ color: '#6b6458' }}>Loading…</p>
      </div>
    </div>
  );
}

// ─── Form Input ──────────────────────────────────────────
export function Input({ label, error, className = '', ...props }) {
  return (
    <div className={`mb-4 ${className}`}>
      {label && <label className="block mb-1.5" style={{ fontSize: 12, fontWeight: 500, color: '#6b6458' }}>{label}</label>}
      <input className="input-dark" {...props} />
      {error && <p className="mt-1 text-xs" style={{ color: '#ef4444' }}>{error}</p>}
    </div>
  );
}

export function Select({ label, error, options = [], className = '', ...props }) {
  return (
    <div className={`mb-4 ${className}`}>
      {label && <label className="block mb-1.5" style={{ fontSize: 12, fontWeight: 500, color: '#6b6458' }}>{label}</label>}
      <select className="input-dark cursor-pointer" {...props}>
        {options.map((o) => (
          <option key={o.value} value={o.value} style={{ background: '#141d35' }}>{o.label}</option>
        ))}
      </select>
      {error && <p className="mt-1 text-xs" style={{ color: '#ef4444' }}>{error}</p>}
    </div>
  );
}

export function Textarea({ label, error, className = '', ...props }) {
  return (
    <div className={`mb-4 ${className}`}>
      {label && <label className="block mb-1.5" style={{ fontSize: 12, fontWeight: 500, color: '#6b6458' }}>{label}</label>}
      <textarea className="input-dark resize-y min-h-[80px]" {...props} />
      {error && <p className="mt-1 text-xs" style={{ color: '#ef4444' }}>{error}</p>}
    </div>
  );
}

// ─── Progress Bar ────────────────────────────────────────
export function Progress({ value = 0, height = 6, className = '' }) {
  return (
    <div className={`rounded-full overflow-hidden ${className}`}
      style={{ background: '#141d35', height }}>
      <div className="h-full rounded-full transition-all duration-500"
        style={{ width: `${Math.min(100, value)}%`, background: 'linear-gradient(90deg,#9a7a4a,#c9a96e)' }} />
    </div>
  );
}

// ─── Page Header ─────────────────────────────────────────
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div>
        <h1 style={{ fontFamily: 'Cormorant Garamond,serif', fontSize: 28, fontWeight: 600, color: '#f2ede6' }}>
          {title}
        </h1>
        {subtitle && <p className="mt-1 text-sm" style={{ color: '#6b6458' }}>{subtitle}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}

// ─── Empty State ─────────────────────────────────────────
export function EmptyState({ icon = '📭', title = 'No data', description, action }) {
  return (
    <div className="text-center py-16">
      <div className="text-5xl mb-4 opacity-40">{icon}</div>
      <h3 className="text-base font-medium mb-1" style={{ color: '#9ca3af' }}>{title}</h3>
      {description && <p className="text-sm mb-4" style={{ color: '#6b6458' }}>{description}</p>}
      {action}
    </div>
  );
}

// ─── Stats Row ───────────────────────────────────────────
export function StatRow({ label, value, valueColor }) {
  return (
    <div className="flex items-center justify-between py-3" style={{ borderBottom: '1px solid rgba(201,169,110,0.06)' }}>
      <span className="text-sm" style={{ color: '#9ca3af' }}>{label}</span>
      <span className="text-sm font-semibold" style={{ color: valueColor || '#f2ede6' }}>{value}</span>
    </div>
  );
}

// ─── Filter Tabs ─────────────────────────────────────────
export function FilterTabs({ tabs, active, onChange }) {
  return (
    <div className="flex items-center gap-1.5 flex-wrap mb-5">
      {tabs.map((t) => (
        <button key={t.value}
          onClick={() => onChange(t.value)}
          className="px-4 py-1.5 rounded-full text-xs font-medium transition-all"
          style={{
            border: '1px solid',
            borderColor: active === t.value ? 'rgba(201,169,110,0.4)' : 'rgba(255,255,255,0.08)',
            background: active === t.value ? 'rgba(201,169,110,0.1)' : 'transparent',
            color: active === t.value ? '#c9a96e' : '#9ca3af',
          }}>
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ─── Avatar ──────────────────────────────────────────────
export function Avatar({ name = '', size = 36 }) {
  const initials = name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2);
  return (
    <div className="flex items-center justify-center rounded-full font-bold flex-shrink-0"
      style={{ width: size, height: size, background: 'linear-gradient(135deg,#9a7a4a,#c9a96e)',
        color: '#030508', fontFamily: 'Cinzel,serif', fontSize: size * 0.35 }}>
      {initials}
    </div>
  );
}

// ─── Pagination ──────────────────────────────────────────
export function Pagination({ pagination, onChange }) {
  if (!pagination || pagination.pages <= 1) return null;
  const { page, pages, total, limit } = pagination;
  return (
    <div className="flex items-center justify-between px-4 py-3" style={{ borderTop: '1px solid rgba(201,169,110,0.06)' }}>
      <span className="text-xs" style={{ color: '#6b6458' }}>
        Showing {(page - 1) * limit + 1}–{Math.min(page * limit, total)} of {total}
      </span>
      <div className="flex gap-1">
        <Button variant="outline" size="xs" disabled={page <= 1} onClick={() => onChange(page - 1)}>← Prev</Button>
        {[...Array(Math.min(pages, 5))].map((_, i) => {
          const p = i + 1;
          return (
            <Button key={p} variant={p === page ? 'gold' : 'outline'} size="xs" onClick={() => onChange(p)}>{p}</Button>
          );
        })}
        <Button variant="outline" size="xs" disabled={page >= pages} onClick={() => onChange(page + 1)}>Next →</Button>
      </div>
    </div>
  );
}
