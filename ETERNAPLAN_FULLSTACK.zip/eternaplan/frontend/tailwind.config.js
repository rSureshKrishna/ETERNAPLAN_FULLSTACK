/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        gold: {
          50:  '#fdf9f0',
          100: '#f9efd8',
          200: '#f2d9a8',
          300: '#e8c98a',
          400: '#d9b06b',
          500: '#c9a96e',
          600: '#b8913a',
          700: '#9a7a4a',
          800: '#7a5e32',
          900: '#5c4420',
        },
        void:    '#030508',
        deep:    '#070b14',
        base:    '#0a0f1e',
        surface: '#0f1628',
        elevated:'#141d35',
        card:    '#19233e',
      },
      fontFamily: {
        serif:  ['Cormorant Garamond', 'Georgia', 'serif'],
        sans:   ['DM Sans', 'system-ui', 'sans-serif'],
        display:['Cinzel', 'Georgia', 'serif'],
      },
      boxShadow: {
        gold: '0 0 40px rgba(201,169,110,0.08)',
        'gold-lg': '0 8px 32px rgba(201,169,110,0.2)',
      },
      animation: {
        'breathe': 'breathe 6s ease-in-out infinite',
        'spin-slow': 'spin 20s linear infinite',
      },
      keyframes: {
        breathe: {
          '0%,100%': { transform: 'scale(1)' },
          '50%':     { transform: 'scale(1.15)' },
        },
      },
    },
  },
  plugins: [],
};
