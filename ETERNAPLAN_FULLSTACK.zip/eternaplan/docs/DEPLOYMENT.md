# EternaPlaan™ — Deployment Guide

## Table of Contents
1. [Local Development Setup](#1-local-development-setup)
2. [Database Setup](#2-database-setup)
3. [Backend Deployment](#3-backend-deployment)
4. [Frontend Deployment](#4-frontend-deployment)
5. [Docker Production Deployment](#5-docker-production-deployment)
6. [SSL Certificate Setup](#6-ssl-certificate-setup)
7. [Environment Variables Reference](#7-environment-variables-reference)
8. [Monitoring & Logging](#8-monitoring--logging)
9. [Backup Strategy](#9-backup-strategy)
10. [Scaling Guide](#10-scaling-guide)

---

## 1. Local Development Setup

### Prerequisites
- Node.js ≥ 18.0.0
- MySQL 8.0+
- Git

```bash
# Clone repository
git clone https://github.com/yourorg/eternaplan.git
cd eternaplan

# Install backend dependencies
cd backend
cp .env.example .env
# Edit .env with your local values
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### Start Development Servers

**Terminal 1 – Backend:**
```bash
cd backend
npm run dev
# API running at http://localhost:5000
```

**Terminal 2 – Frontend:**
```bash
cd frontend
npm run dev
# App running at http://localhost:3000
```

---

## 2. Database Setup

### Create Database & Run Schema
```bash
# Connect to MySQL
mysql -u root -p

# In MySQL shell:
CREATE DATABASE eternaplan_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'eternaplan'@'localhost' IDENTIFIED BY 'your_strong_password';
GRANT ALL PRIVILEGES ON eternaplan_db.* TO 'eternaplan'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Run schema
mysql -u root -p eternaplan_db < database/schema.sql

# Load sample data
mysql -u root -p eternaplan_db < database/seed.sql
```

### Verify Setup
```bash
mysql -u root -p eternaplan_db -e "SHOW TABLES;"
# Should list all 25 tables

mysql -u root -p eternaplan_db -e "SELECT COUNT(*) FROM events;"
# Should return 6
```

---

## 3. Backend Deployment

### Environment Variables
```bash
cd backend
cp .env.example .env
nano .env  # Fill in all values
```

### Production Build & Start
```bash
cd backend
npm ci --only=production
NODE_ENV=production node src/server.js

# Or with PM2 (recommended):
npm install -g pm2
pm2 start src/server.js --name "eternaplan-api" --instances 2
pm2 save
pm2 startup
```

### PM2 Config (ecosystem.config.js)
```javascript
module.exports = {
  apps: [{
    name: 'eternaplan-api',
    script: 'src/server.js',
    cwd: '/var/www/eternaplan/backend',
    instances: 2,
    exec_mode: 'cluster',
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/pm2/eternaplan-error.log',
    out_file: '/var/log/pm2/eternaplan-out.log',
    max_memory_restart: '500M',
  }]
};
```

---

## 4. Frontend Deployment

### Build for Production
```bash
cd frontend
npm run build
# Output in frontend/dist/
```

### Serve with Nginx
```nginx
server {
    listen 80;
    server_name app.eternaplan.in;
    root /var/www/eternaplan/frontend/dist;
    index index.html;

    # SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API proxy
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

---

## 5. Docker Production Deployment

### Quick Start
```bash
# Clone repo
git clone https://github.com/yourorg/eternaplan.git
cd eternaplan

# Configure environment
cp backend/.env.example backend/.env
nano backend/.env  # Set all production values

# Create .env for docker-compose
cat > .env << 'EOF'
DB_ROOT_PASSWORD=strongrootpassword
DB_NAME=eternaplan_db
DB_USER=eternaplan
DB_PASSWORD=strongdbpassword
JWT_SECRET=<64-char-random-string>
JWT_REFRESH_SECRET=<64-char-random-string>
FRONTEND_URL=https://app.eternaplan.in
REDIS_PASSWORD=strongredispassword
EOF

# Build and launch all services
docker-compose up -d --build

# Verify services are running
docker-compose ps

# View logs
docker-compose logs -f backend
docker-compose logs -f db
```

### Service URLs
| Service   | Internal               | External         |
|-----------|------------------------|------------------|
| Frontend  | http://frontend:80     | https://app.domain.com |
| API       | http://backend:5000    | https://app.domain.com/api |
| MySQL     | mysql://db:3306        | localhost:3307 (admin only) |
| Redis     | redis://redis:6379     | Internal only    |

### Useful Docker Commands
```bash
# Restart a specific service
docker-compose restart backend

# Access database shell
docker-compose exec db mysql -u root -p eternaplan_db

# Access backend shell
docker-compose exec backend sh

# View backend logs (last 100 lines)
docker-compose logs --tail=100 backend

# Scale backend horizontally (load balanced by Nginx)
docker-compose up -d --scale backend=3

# Update and redeploy backend only
docker-compose build backend
docker-compose up -d backend

# Full system update
git pull
docker-compose down
docker-compose up -d --build
```

---

## 6. SSL Certificate Setup

### Option A: Let's Encrypt (Free)
```bash
# Install certbot
apt-get install certbot python3-certbot-nginx

# Obtain certificate
certbot --nginx -d eternaplan.in -d app.eternaplan.in

# Auto-renewal
certbot renew --dry-run
# Add to crontab: 0 12 * * * /usr/bin/certbot renew --quiet
```

### Option B: Self-Signed (Dev/Staging)
```bash
mkdir -p docker/nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout docker/nginx/ssl/eternaplan.key \
  -out docker/nginx/ssl/eternaplan.crt \
  -subj "/C=IN/ST=Tamil Nadu/L=Chennai/O=EternaPlaan/CN=app.eternaplan.in"
```

---

## 7. Environment Variables Reference

### Backend `.env`
| Variable | Required | Description |
|---|---|---|
| `NODE_ENV` | ✅ | `development` or `production` |
| `PORT` | ✅ | API server port (default: 5000) |
| `DB_HOST` | ✅ | MySQL host |
| `DB_NAME` | ✅ | Database name |
| `DB_USER` | ✅ | Database user |
| `DB_PASSWORD` | ✅ | Database password |
| `JWT_SECRET` | ✅ | Min 32 chars (use `openssl rand -hex 32`) |
| `JWT_REFRESH_SECRET` | ✅ | Different from JWT_SECRET |
| `JWT_EXPIRES_IN` | — | Default: `15m` |
| `JWT_REFRESH_EXPIRES_IN` | — | Default: `7d` |
| `CLOUDINARY_CLOUD_NAME` | ✅ | Cloudinary account |
| `CLOUDINARY_API_KEY` | ✅ | Cloudinary API key |
| `CLOUDINARY_API_SECRET` | ✅ | Cloudinary secret |
| `SMTP_HOST` | ✅ | SMTP server (e.g., smtp.gmail.com) |
| `SMTP_PORT` | — | Default: 587 |
| `SMTP_USER` | ✅ | SMTP username |
| `SMTP_PASS` | ✅ | SMTP password or App Password |
| `EMAIL_FROM` | — | Sender email address |
| `TWILIO_ACCOUNT_SID` | — | For SMS alerts |
| `TWILIO_AUTH_TOKEN` | — | Twilio auth token |
| `TWILIO_FROM_NUMBER` | — | Twilio phone number |
| `BCRYPT_ROUNDS` | — | Default: 12 |
| `RATE_LIMIT_MAX` | — | Default: 100 req/window |
| `FRONTEND_URL` | ✅ | For CORS (e.g., https://app.eternaplan.in) |

### Generate Secrets
```bash
# Generate JWT secrets
openssl rand -hex 32  # Use output for JWT_SECRET
openssl rand -hex 32  # Use output for JWT_REFRESH_SECRET
```

---

## 8. Monitoring & Logging

### Log Files (Backend)
```
backend/logs/
├── combined-YYYY-MM-DD.log    # All logs
├── error-YYYY-MM-DD.log       # Errors only
```

### Nginx Logs (Docker)
```bash
docker-compose exec nginx tail -f /var/log/nginx/access.log
docker-compose exec nginx tail -f /var/log/nginx/error.log
```

### MySQL Slow Query Log
```bash
docker-compose exec db tail -f /var/log/mysql/slow.log
```

### Health Check Endpoint
```bash
curl https://api.eternaplan.in/health
# Returns: {"status":"healthy","uptime":...}
```

---

## 9. Backup Strategy

### Automated MySQL Backup
```bash
#!/bin/bash
# backup.sh - Run via cron daily at 2 AM
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/mysql"
mkdir -p $BACKUP_DIR

docker-compose exec -T db mysqldump \
  -u root -p${DB_ROOT_PASSWORD} \
  --single-transaction \
  --routines \
  --triggers \
  eternaplan_db | gzip > "$BACKUP_DIR/eternaplan_$DATE.sql.gz"

# Keep last 30 days
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete

echo "Backup completed: eternaplan_$DATE.sql.gz"
```

```bash
# Add to crontab
crontab -e
# 0 2 * * * /var/www/eternaplan/backup.sh >> /var/log/eternaplan-backup.log 2>&1
```

### Restore from Backup
```bash
gunzip -c /backups/mysql/eternaplan_20251101_020000.sql.gz | \
  docker-compose exec -T db mysql -u root -p${DB_ROOT_PASSWORD} eternaplan_db
```

---

## 10. Scaling Guide

### Horizontal Scaling (Backend)
```bash
# Scale to 3 backend instances (Nginx load-balances automatically)
docker-compose up -d --scale backend=3

# Update nginx upstream to use round-robin across instances
# (Already configured in docker/nginx/nginx.conf)
```

### Database Optimization
```sql
-- Check slow queries
SHOW PROCESSLIST;

-- Analyze table statistics
ANALYZE TABLE events, customers, bookings, payments;

-- Check index usage
EXPLAIN SELECT * FROM events WHERE company_id=1 AND event_date >= CURDATE();

-- Optimize tables periodically
OPTIMIZE TABLE events, customers, bookings, guests;
```

### CDN Integration (Cloudinary already handles media)
For static assets, point your CDN (Cloudflare/AWS CloudFront) to your Nginx server for automatic caching of JS/CSS/images.

---

## Default Login Credentials

| Role | Email | Password |
|---|---|---|
| Super Admin | superadmin@eternaplan.in | Password@123 |
| Admin | admin@eternaplan.in | Password@123 |
| Event Manager | manager1@eternaplan.in | Password@123 |

> ⚠️ **Change all default passwords immediately after first login in production.**

---

*EternaPlaan™ Deployment Guide v1.0 — © 2025*
