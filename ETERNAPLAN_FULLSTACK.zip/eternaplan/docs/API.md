# EternaPlaan™ API Documentation
**Base URL:** `https://api.eternaplan.in/api/v1`  
**Version:** 1.0.0 | **Auth:** Bearer JWT

---

## Authentication

### POST /auth/register
Register a new company + admin user.
```json
// Request
{ "first_name":"Priya","last_name":"Nair","email":"admin@co.in","phone":"+919876543210","password":"Pass@1234","company_name":"My Events Co" }
// Response 201
{ "success":true,"message":"Registration successful. OTP sent.","data":{"user_id":1,"email":"admin@co.in"} }
```

### POST /auth/login
```json
// Request
{ "email":"admin@eternaplan.in","password":"Password@123" }
// Response 200
{ "success":true,"data":{ "token":"eyJ...", "user":{ "id":2,"name":"Priya Nair","role":"admin","permissions":{...},"company":{...} } } }
```
*Sets `refreshToken` httpOnly cookie.*

### POST /auth/refresh
Auto-reads `refreshToken` cookie. Returns new `accessToken`.

### POST /auth/verify-otp
```json
{ "email":"user@co.in","otp":"482910" }
```

### POST /auth/forgot-password
```json
{ "email":"user@co.in" }
```

### POST /auth/reset-password
```json
{ "token":"<reset_token>","password":"NewPass@123" }
```

### POST /auth/logout — 🔒 Auth required
Clears refresh token.

### GET /auth/me — 🔒 Auth required
Returns current user profile.

---

## Dashboard

### GET /dashboard/overview — 🔒 Admin+
Query params: `?year=2025`

Returns: `kpi`, `monthly_revenue`, `event_status`, `category_distribution`, `top_vendors`, `recent_activities`, `upcoming_events`, `customer_growth`, `task_summary`, `payment_methods`, `outstanding_balances`

### GET /dashboard/reports/monthly — 🔒 Admin+
Query params: `?month=11&year=2025`

### GET /dashboard/calendar — 🔒 Auth
Query params: `?year=2025&month=11`

---

## Events

### GET /events — 🔒 Auth
| Param | Type | Description |
|---|---|---|
| page | int | Page number (default 1) |
| limit | int | Per page (default 20) |
| status | string | `inquiry\|planning\|confirmed\|in_progress\|completed\|cancelled` |
| category_id | int | Filter by category |
| assigned_to | int | Filter by manager |
| search | string | Full-text search |
| from_date | date | Event date from |
| to_date | date | Event date to |
| sort | string | `event_date\|created_at\|budget_total` |
| order | string | `ASC\|DESC` |

```json
// Response 200
{
  "success": true,
  "data": {
    "events": [
      { "id":1,"event_code":"EVT-2025-0001","event_name":"Vikram & Priya Wedding",
        "event_date":"2025-11-15","status":"confirmed","customer_name":"Vikram Patel",
        "venue_name":"Grand Palace","budget_total":1200000,"completion_pct":68 }
    ],
    "pagination": { "page":1,"limit":20,"total":6,"pages":1 }
  }
}
```

### POST /events — 🔒 Manager+
```json
{
  "customer_id": 1, "category_id": 1, "venue_id": 1,
  "event_name": "Sharma Wedding", "event_date": "2026-03-15",
  "event_time": "09:00:00", "guest_count_estimate": 400,
  "theme": "Royal Gold", "budget_total": 1500000,
  "assigned_to": 3, "notes": "Client prefers vegetarian catering"
}
// Response 201
{ "success":true,"message":"Event created.","data":{"id":7,"event_code":"EVT-2025-0007"} }
```

### GET /events/upcoming — 🔒 Auth
Returns next 10 upcoming events with days remaining.

### GET /events/:id — 🔒 Auth
Returns full event detail: event + tasks + bookings + guest summary + financials.

### PUT /events/:id — 🔒 Manager+
Update any allowed event fields. Send only changed fields.

### DELETE /events/:id — 🔒 Admin+
Cannot delete `completed` or `in_progress` events.

### POST /events/:id/tasks — 🔒 Auth
```json
{ "title":"Confirm catering menu","category":"Catering","priority":"high","assigned_to":3,"due_date":"2025-10-01" }
```

### PATCH /events/:id/tasks/:taskId — 🔒 Auth
```json
{ "status":"completed" }
```

---

## Customers

### GET /customers — 🔒 Auth
| Param | Type | Description |
|---|---|---|
| search | string | Name/phone/email search |
| lead_status | string | `new\|contacted\|qualified\|proposal_sent\|won\|lost` |
| priority | string | `low\|medium\|high\|vip` |
| source | string | `walk_in\|referral\|website\|social_media\|phone` |
| assigned_to | int | Manager ID |

### POST /customers — 🔒 Manager+
```json
{
  "first_name":"Rahul","last_name":"Mehta","email":"rahul@gmail.com",
  "phone":"+919876543210","source":"referral","priority":"high",
  "lead_status":"new","assigned_to":3
}
```

### GET /customers/:id — 🔒 Auth
Returns customer + events history + notes.

### PUT /customers/:id — 🔒 Manager+

### POST /customers/:id/notes — 🔒 Auth
```json
{ "note":"Client wants floral theme. Follow up by Friday.","note_type":"followup","followup_at":"2025-10-15T10:00:00" }
```

---

## Vendors

### GET /vendors — 🔒 Auth
| Param | Type | Description |
|---|---|---|
| search | string | Business/contact name |
| category_id | int | Vendor category |
| city | string | City filter |
| approval_status | string | `pending\|approved\|rejected` |
| rating_min | float | Minimum rating |

### GET /vendors/:id — 🔒 Auth
Returns vendor + packages + reviews.

### PATCH /vendors/:id/approve — 🔒 Admin+
```json
{ "approval_status":"approved" }
```

---

## Bookings

### GET /bookings — 🔒 Auth
Query: `event_id`, `vendor_id`, `status`, `from_date`, `to_date`

### POST /bookings — 🔒 Manager+
```json
{
  "event_id": 1, "vendor_id": 1, "package_id": 2,
  "booking_type": "vendor", "booking_date": "2025-11-15",
  "start_time": "07:00:00", "end_time": "22:00:00",
  "quoted_price": 200000, "agreed_price": 180000,
  "advance_amount": 50000
}
// Conflict detection runs automatically for venue bookings
// Response 201
{ "success":true,"data":{"id":9,"booking_code":"BK-2025-0009"} }
```

### PATCH /bookings/:id/status — 🔒 Auth
```json
{ "status":"cancelled","cancellation_reason":"Postponed to next year" }
```

---

## Guests

### GET /guests — 🔒 Auth
Query: `event_id` (required), `rsvp_status`, `side`, `category`, `search`

### POST /guests — 🔒 Auth
```json
{
  "event_id":1,"first_name":"Vikram","last_name":"Shah",
  "phone":"+919876540001","relation":"College Friend","side":"groom",
  "category":"friend","meal_preference":"non_veg","table_number":"T5"
}
// Returns: invitation_code + qr_url
```

### POST /guests/bulk-import — 🔒 Auth
```json
{ "event_id":1,"guests":[{"first_name":"A","last_name":"B","phone":"...","side":"bride"},…] }
```

### PATCH /guests/rsvp/:code — 🌐 Public (for RSVP links)
```json
{ "rsvp_status":"attending","meal_preference":"veg" }
```

### PATCH /guests/:id/check-in — 🔒 Auth

---

## Finance

### GET /finance/invoices — 🔒 Auth
Query: `status`, `event_id`, `customer_id`

### GET /finance/invoices/:id — 🔒 Auth
Returns invoice + line items + payment history.

### POST /finance/payments — 🔒 Admin+
```json
{
  "invoice_id":1,"customer_id":1,"amount":50000,
  "payment_date":"2025-10-15","payment_method":"upi",
  "payment_ref":"UPI-TXN-00001","payment_type":"installment"
}
```

### GET /finance/expenses — 🔒 Auth
Query: `event_id`, `category`

### POST /finance/expenses — 🔒 Auth
```json
{
  "event_id":1,"category":"Decoration","description":"Stage backdrop",
  "amount":25000,"expense_date":"2025-10-20","payment_method":"cash"
}
```

---

## Meta / Utility

### GET /meta/categories — 🔒 Auth
All active event categories.

### GET /meta/vendor-categories — 🔒 Auth
All vendor category types.

### GET /meta/venues — 🔒 Auth
All available venues.

---

## Error Responses

All errors follow:
```json
{ "success":false,"message":"Human-readable error","errors":[...optional validation array] }
```

| Status | Meaning |
|---|---|
| 400 | Bad Request / Validation Error |
| 401 | Authentication Required |
| 403 | Insufficient Permissions |
| 404 | Resource Not Found |
| 409 | Conflict (duplicate / slot taken) |
| 422 | Validation Failed |
| 423 | Account Locked |
| 429 | Rate Limit Exceeded |
| 500 | Internal Server Error |

---

## Rate Limits

| Endpoint | Limit |
|---|---|
| `/auth/login` | 10 req / 15 min |
| `/auth/register` | 10 req / 15 min |
| All other `/api/` | 100 req / 15 min |
