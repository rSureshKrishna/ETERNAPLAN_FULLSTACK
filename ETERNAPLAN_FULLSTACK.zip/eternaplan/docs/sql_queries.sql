-- ============================================================
-- EternaPlaan™ — SQL Query Documentation
-- Advanced queries demonstrating all required SQL concepts
-- ============================================================

USE eternaplan_db;

-- ══════════════════════════════════════════════════════════
-- 1. INNER JOIN — Events with customer and venue details
-- ══════════════════════════════════════════════════════════
SELECT
    e.event_code,
    e.event_name,
    e.event_date,
    CONCAT(c.first_name, ' ', c.last_name) AS customer,
    c.phone,
    v.name AS venue,
    v.capacity_max,
    ec.name AS category
FROM events e
INNER JOIN customers c ON e.customer_id = c.id
INNER JOIN event_categories ec ON e.category_id = ec.id
INNER JOIN venues v ON e.venue_id = v.id
WHERE e.company_id = 1
  AND e.event_date >= CURDATE()
ORDER BY e.event_date ASC;

-- ══════════════════════════════════════════════════════════
-- 2. LEFT JOIN — All customers with their event count
--    (includes customers with 0 events)
-- ══════════════════════════════════════════════════════════
SELECT
    CONCAT(c.first_name, ' ', c.last_name) AS customer,
    c.phone,
    c.lead_status,
    COUNT(e.id)        AS total_events,
    COALESCE(SUM(e.budget_total), 0) AS total_budget
FROM customers c
LEFT JOIN events e ON c.id = e.customer_id AND e.status != 'cancelled'
WHERE c.company_id = 1
GROUP BY c.id
ORDER BY total_events DESC;

-- ══════════════════════════════════════════════════════════
-- 3. RIGHT JOIN — All vendor categories with vendor count
-- ══════════════════════════════════════════════════════════
SELECT
    vc.name AS category,
    vc.icon,
    COUNT(v.id) AS vendor_count,
    AVG(v.rating) AS avg_rating,
    SUM(v.total_events) AS total_events_served
FROM vendors v
RIGHT JOIN vendor_categories vc ON v.category_id = vc.id
GROUP BY vc.id
ORDER BY vendor_count DESC;

-- ══════════════════════════════════════════════════════════
-- 4. FULL JOIN SIMULATION (LEFT UNION RIGHT)
--    All vendors and all bookings (even unmatched)
-- ══════════════════════════════════════════════════════════
SELECT
    v.business_name,
    v.phone AS vendor_phone,
    b.booking_code,
    b.booking_date,
    b.agreed_price,
    b.status AS booking_status
FROM vendors v
LEFT JOIN bookings b ON v.id = b.vendor_id

UNION

SELECT
    v.business_name,
    v.phone AS vendor_phone,
    b.booking_code,
    b.booking_date,
    b.agreed_price,
    b.status AS booking_status
FROM vendors v
RIGHT JOIN bookings b ON v.id = b.vendor_id
WHERE v.id IS NULL;

-- ══════════════════════════════════════════════════════════
-- 5. GROUP BY + HAVING — Vendors with > 5 bookings
-- ══════════════════════════════════════════════════════════
SELECT
    v.business_name,
    vc.name AS category,
    COUNT(b.id)        AS total_bookings,
    SUM(b.agreed_price) AS total_revenue,
    AVG(b.agreed_price) AS avg_booking_value
FROM bookings b
JOIN vendors v ON b.vendor_id = v.id
JOIN vendor_categories vc ON v.category_id = vc.id
WHERE b.company_id = 1
  AND b.status IN ('confirmed', 'completed')
GROUP BY v.id
HAVING total_bookings > 2
ORDER BY total_revenue DESC;

-- ══════════════════════════════════════════════════════════
-- 6. COMPLEX AGGREGATION — Monthly revenue + profit/loss
-- ══════════════════════════════════════════════════════════
SELECT
    DATE_FORMAT(p.payment_date, '%Y-%m') AS month,
    COUNT(DISTINCT i.event_id)           AS events_billed,
    SUM(p.amount)                        AS total_revenue,
    (SELECT COALESCE(SUM(ex.amount), 0)
     FROM expenses ex
     WHERE ex.company_id = i.company_id
       AND DATE_FORMAT(ex.expense_date, '%Y-%m') = DATE_FORMAT(p.payment_date, '%Y-%m')
    )                                    AS total_expenses,
    SUM(p.amount) - (
        SELECT COALESCE(SUM(ex.amount), 0)
        FROM expenses ex
        WHERE ex.company_id = i.company_id
          AND DATE_FORMAT(ex.expense_date, '%Y-%m') = DATE_FORMAT(p.payment_date, '%Y-%m')
    )                                    AS net_profit,
    COUNT(DISTINCT p.id)                 AS transactions,
    ROUND(AVG(p.amount), 2)              AS avg_transaction
FROM payments p
JOIN invoices i ON p.invoice_id = i.id
WHERE i.company_id = 1
  AND p.status = 'completed'
GROUP BY DATE_FORMAT(p.payment_date, '%Y-%m')
ORDER BY month DESC;

-- ══════════════════════════════════════════════════════════
-- 7. NESTED SUBQUERY — Events over company average budget
-- ══════════════════════════════════════════════════════════
SELECT
    e.event_code,
    e.event_name,
    e.budget_total,
    e.event_date,
    CONCAT(c.first_name, ' ', c.last_name) AS customer
FROM events e
JOIN customers c ON e.customer_id = c.id
WHERE e.budget_total > (
    SELECT AVG(budget_total)
    FROM events
    WHERE company_id = e.company_id
      AND status != 'cancelled'
)
  AND e.company_id = 1
ORDER BY e.budget_total DESC;

-- ══════════════════════════════════════════════════════════
-- 8. CORRELATED SUBQUERY — Customers with above-avg events
-- ══════════════════════════════════════════════════════════
SELECT
    c.id,
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    c.total_events,
    c.priority,
    (SELECT MAX(e.event_date)
     FROM events e
     WHERE e.customer_id = c.id) AS last_event_date,
    fn_get_customer_ltv(c.id)   AS lifetime_value
FROM customers c
WHERE c.total_events > (
    SELECT AVG(total_events)
    FROM customers
    WHERE company_id = c.company_id
      AND total_events > 0
)
  AND c.company_id = 1
ORDER BY c.total_events DESC;

-- ══════════════════════════════════════════════════════════
-- 9. CTE — Upcoming events with progress + financials
-- ══════════════════════════════════════════════════════════
WITH EventProgress AS (
    SELECT
        e.id,
        e.event_name,
        e.event_date,
        e.budget_total,
        COUNT(et.id)                                         AS total_tasks,
        SUM(CASE WHEN et.status = 'completed' THEN 1 ELSE 0 END) AS done_tasks,
        ROUND(
            SUM(CASE WHEN et.status = 'completed' THEN 1 ELSE 0 END) * 100.0
            / NULLIF(COUNT(et.id), 0), 1
        )                                                    AS pct_complete
    FROM events e
    LEFT JOIN event_tasks et ON e.id = et.event_id
    WHERE e.company_id = 1
      AND e.event_date >= CURDATE()
      AND e.status NOT IN ('cancelled', 'completed')
    GROUP BY e.id
),
EventPayments AS (
    SELECT
        i.event_id,
        COALESCE(SUM(p.amount), 0) AS amount_received
    FROM invoices i
    LEFT JOIN payments p ON i.id = p.invoice_id AND p.status = 'completed'
    WHERE i.company_id = 1
    GROUP BY i.event_id
)
SELECT
    ep.event_name,
    ep.event_date,
    DATEDIFF(ep.event_date, CURDATE()) AS days_remaining,
    ep.total_tasks,
    ep.done_tasks,
    ep.pct_complete,
    ep.budget_total,
    COALESCE(pay.amount_received, 0)   AS received,
    ep.budget_total - COALESCE(pay.amount_received, 0) AS outstanding,
    CONCAT(c.first_name, ' ', c.last_name)             AS customer
FROM EventProgress ep
JOIN events e ON ep.id = e.id
JOIN customers c ON e.customer_id = c.id
LEFT JOIN EventPayments pay ON ep.id = pay.event_id
ORDER BY ep.event_date ASC;

-- ══════════════════════════════════════════════════════════
-- 10. WINDOW FUNCTIONS — Revenue trends & ranking
-- ══════════════════════════════════════════════════════════

-- Running total + month-over-month growth
SELECT
    month_label,
    total_revenue,
    total_expenses,
    SUM(total_revenue) OVER (
        ORDER BY month_key
        ROWS UNBOUNDED PRECEDING
    )                                                          AS cumulative_revenue,
    LAG(total_revenue, 1) OVER (ORDER BY month_key)           AS prev_month_revenue,
    ROUND(
        (total_revenue - LAG(total_revenue, 1) OVER (ORDER BY month_key))
        / NULLIF(LAG(total_revenue, 1) OVER (ORDER BY month_key), 0) * 100, 1
    )                                                          AS mom_growth_pct,
    RANK() OVER (ORDER BY total_revenue DESC)                  AS revenue_rank,
    AVG(total_revenue) OVER (
        ORDER BY month_key
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    )                                                          AS moving_avg_3m
FROM vw_revenue_dashboard
ORDER BY month_key;

-- Vendor revenue rank within category
SELECT
    v.business_name,
    vc.name                                        AS category,
    SUM(b.agreed_price)                            AS total_revenue,
    RANK() OVER (
        PARTITION BY v.category_id
        ORDER BY SUM(b.agreed_price) DESC
    )                                              AS category_rank,
    DENSE_RANK() OVER (ORDER BY SUM(b.agreed_price) DESC) AS overall_rank,
    NTILE(4) OVER (ORDER BY SUM(b.agreed_price) DESC)     AS quartile
FROM bookings b
JOIN vendors v ON b.vendor_id = v.id
JOIN vendor_categories vc ON v.category_id = vc.id
WHERE b.status = 'completed'
GROUP BY v.id;

-- ══════════════════════════════════════════════════════════
-- 11. TRANSACTION — Record payment and update invoice
-- ══════════════════════════════════════════════════════════
START TRANSACTION;

-- Insert payment record
INSERT INTO payments (
    company_id, invoice_id, customer_id, payment_code,
    amount, payment_date, payment_method, status, payment_type
) VALUES (
    1, 1, 1, 'PAY-2025-9999',
    50000.00, CURDATE(), 'upi', 'completed', 'installment'
);

-- Trigger handles invoice update automatically, but manual update example:
UPDATE invoices
SET
    amount_paid  = amount_paid  + 50000.00,
    balance_due  = GREATEST(balance_due - 50000.00, 0),
    status       = CASE
                     WHEN (balance_due - 50000.00) <= 0 THEN 'paid'
                     WHEN (balance_due - 50000.00) < grand_total THEN 'partial'
                     ELSE status
                   END,
    updated_at   = NOW()
WHERE id = 1;

-- Update customer lifetime value
UPDATE customers c
SET total_revenue = (
    SELECT COALESCE(SUM(p2.amount), 0)
    FROM payments p2
    JOIN invoices i2 ON p2.invoice_id = i2.id
    JOIN events e2 ON i2.event_id = e2.id
    WHERE e2.customer_id = c.id AND p2.status = 'completed'
)
WHERE c.id = 1;

COMMIT;
-- ROLLBACK;   -- Use if any step fails

-- ══════════════════════════════════════════════════════════
-- 12. CURSOR EXAMPLE — Process overdue invoices in batch
-- ══════════════════════════════════════════════════════════
DELIMITER //
CREATE PROCEDURE sp_mark_overdue_invoices()
BEGIN
    DECLARE v_done     INT DEFAULT FALSE;
    DECLARE v_inv_id   INT;
    DECLARE v_cust_id  INT;
    DECLARE v_balance  DECIMAL(14,2);
    DECLARE v_count    INT DEFAULT 0;

    DECLARE overdue_cursor CURSOR FOR
        SELECT id, customer_id, balance_due
        FROM invoices
        WHERE status NOT IN ('paid','cancelled')
          AND due_date < CURDATE()
          AND balance_due > 0;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    OPEN overdue_cursor;

    process_loop: LOOP
        FETCH overdue_cursor INTO v_inv_id, v_cust_id, v_balance;
        IF v_done THEN LEAVE process_loop; END IF;

        -- Mark invoice overdue
        UPDATE invoices SET status = 'overdue' WHERE id = v_inv_id;

        -- Insert overdue notification
        INSERT INTO notifications (
            user_id, title, message, type, entity_type, entity_id
        )
        SELECT u.id,
               'Invoice Overdue',
               CONCAT('Invoice #', inv.invoice_number, ' is overdue. Balance: ₹', FORMAT(v_balance,0)),
               'payment', 'invoice', v_inv_id
        FROM invoices inv
        JOIN customers c ON inv.customer_id = c.id
        JOIN users u ON c.assigned_to = u.id
        WHERE inv.id = v_inv_id;

        SET v_count = v_count + 1;
    END LOOP;

    CLOSE overdue_cursor;

    SELECT v_count AS invoices_marked_overdue;
END //
DELIMITER ;

-- ══════════════════════════════════════════════════════════
-- 13. COMPOSITE KEY & FOREIGN KEY INTEGRITY CHECK
-- ══════════════════════════════════════════════════════════

-- Verify all FK relationships
SELECT
    TABLE_NAME,
    COLUMN_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = 'eternaplan_db'
  AND REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY TABLE_NAME;

-- ══════════════════════════════════════════════════════════
-- 14. QUERY OPTIMIZATION — EXPLAIN analysis examples
-- ══════════════════════════════════════════════════════════

-- Check index usage for common queries
EXPLAIN FORMAT=JSON
SELECT e.id, e.event_name, e.event_date, e.status
FROM events e
WHERE e.company_id = 1
  AND e.event_date BETWEEN '2025-01-01' AND '2025-12-31'
  AND e.status = 'confirmed'
ORDER BY e.event_date;

-- Analyze slow query (should use composite index idx_events_company_date)
EXPLAIN
SELECT * FROM events
WHERE company_id = 1
  AND event_date >= CURDATE()
ORDER BY event_date ASC
LIMIT 10;

-- ══════════════════════════════════════════════════════════
-- 15. CASCADING RULES DEMO — Delete event cascades to tasks
-- ══════════════════════════════════════════════════════════
-- When event is deleted: tasks, venue_bookings auto-deleted (ON DELETE CASCADE)
-- When customer is deleted: events remain (ON DELETE RESTRICT → prevents orphan-free delete)
-- When user (assigned_to) is deleted: event.assigned_to → NULL (ON DELETE SET NULL)

-- Test cascade (DO NOT RUN IN PRODUCTION):
-- DELETE FROM events WHERE id = 999; -- cascades to event_tasks, venue_bookings, activity_feed

-- ══════════════════════════════════════════════════════════
-- 16. INDEX EFFECTIVENESS — Check fragmentation
-- ══════════════════════════════════════════════════════════
SELECT
    TABLE_NAME,
    INDEX_NAME,
    COLUMN_NAME,
    CARDINALITY,
    SEQ_IN_INDEX
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'eternaplan_db'
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;

-- Show table sizes and index sizes
SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH/1024/1024, 2)  AS data_mb,
    ROUND(INDEX_LENGTH/1024/1024, 2) AS index_mb,
    TABLE_ROWS                        AS est_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'eternaplan_db'
ORDER BY DATA_LENGTH DESC;

-- ══════════════════════════════════════════════════════════
-- 17. GUEST ANALYTICS — RSVP breakdown with meal counts
-- ══════════════════════════════════════════════════════════
SELECT
    e.event_name,
    e.event_date,
    COUNT(g.id)                                          AS total_invited,
    SUM(g.rsvp_status = 'attending')                    AS attending,
    SUM(g.rsvp_status = 'not_attending')                AS declined,
    SUM(g.rsvp_status = 'maybe')                        AS maybe,
    SUM(g.rsvp_status = 'pending')                      AS pending,
    SUM(g.meal_preference = 'veg')                      AS veg,
    SUM(g.meal_preference = 'non_veg')                  AS non_veg,
    SUM(g.meal_preference = 'vegan')                    AS vegan,
    SUM(g.meal_preference = 'jain')                     AS jain,
    SUM(g.has_plus_one = 1 AND g.rsvp_status='attending') AS plus_ones,
    SUM(g.checked_in = 1)                               AS checked_in,
    ROUND(SUM(g.checked_in=1)*100.0/NULLIF(SUM(g.rsvp_status='attending'),0),1) AS checkin_rate_pct
FROM guests g
JOIN events e ON g.event_id = e.id
WHERE e.company_id = 1
GROUP BY e.id
ORDER BY e.event_date;

-- ══════════════════════════════════════════════════════════
-- 18. VENDOR PERFORMANCE REPORT — Full analysis
-- ══════════════════════════════════════════════════════════
SELECT
    vp.business_name,
    vp.category,
    vp.city,
    vp.rating,
    vp.total_reviews,
    vp.total_bookings,
    vp.completed_bookings,
    vp.cancelled_bookings,
    ROUND(vp.completed_bookings * 100.0 / NULLIF(vp.total_bookings,0), 1) AS completion_rate_pct,
    FORMAT(vp.total_revenue, 0)        AS total_revenue_fmt,
    FORMAT(vp.avg_booking_value, 0)    AS avg_booking_value_fmt,
    CASE
        WHEN vp.rating >= 4.8 THEN '⭐ Elite'
        WHEN vp.rating >= 4.5 THEN '★ Premium'
        WHEN vp.rating >= 4.0 THEN 'Standard'
        ELSE 'Needs Review'
    END                                AS tier
FROM vw_vendor_performance vp
ORDER BY vp.total_revenue DESC;

-- ══════════════════════════════════════════════════════════
-- 19. BUDGET VARIANCE ANALYSIS
-- ══════════════════════════════════════════════════════════
SELECT
    e.event_code,
    e.event_name,
    e.event_date,
    e.budget_total,
    e.budget_spent,
    e.budget_total - e.budget_spent                   AS variance,
    ROUND((e.budget_spent / NULLIF(e.budget_total,0)) * 100, 1) AS utilization_pct,
    CASE
        WHEN e.budget_spent > e.budget_total THEN 'OVER BUDGET 🔴'
        WHEN e.budget_spent > e.budget_total * 0.90 THEN 'NEAR LIMIT 🟡'
        WHEN e.budget_spent > e.budget_total * 0.70 THEN 'ON TRACK 🟢'
        ELSE 'UNDER UTILIZED ⚪'
    END                                               AS budget_status,
    COALESCE(
        (SELECT SUM(ex.amount) FROM expenses ex WHERE ex.event_id = e.id AND ex.category = 'Catering'), 0
    )                                                 AS catering_spend,
    COALESCE(
        (SELECT SUM(ex.amount) FROM expenses ex WHERE ex.event_id = e.id AND ex.category = 'Decoration'), 0
    )                                                 AS decor_spend
FROM events e
WHERE e.company_id = 1
  AND e.status != 'cancelled'
ORDER BY utilization_pct DESC;

-- ══════════════════════════════════════════════════════════
-- 20. MULTI-TABLE AGGREGATION — Admin financial summary
-- ══════════════════════════════════════════════════════════
SELECT
    'FINANCIAL SUMMARY' AS report_section,
    YEAR(CURDATE())     AS year,
    (SELECT COUNT(*) FROM events WHERE company_id=1 AND YEAR(event_date)=YEAR(CURDATE())) AS total_events,
    (SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN invoices i ON p.invoice_id=i.id
     WHERE i.company_id=1 AND p.status='completed' AND YEAR(p.payment_date)=YEAR(CURDATE())) AS total_revenue,
    (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE company_id=1 AND YEAR(expense_date)=YEAR(CURDATE())) AS total_expenses,
    (SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN invoices i ON p.invoice_id=i.id
     WHERE i.company_id=1 AND p.status='completed' AND YEAR(p.payment_date)=YEAR(CURDATE()))
    - (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE company_id=1 AND YEAR(expense_date)=YEAR(CURDATE())) AS net_profit,
    (SELECT COALESCE(SUM(balance_due),0) FROM invoices WHERE company_id=1 AND status NOT IN('paid','cancelled')) AS total_outstanding,
    (SELECT COUNT(*) FROM customers WHERE company_id=1) AS total_customers,
    (SELECT COUNT(*) FROM vendors WHERE company_id=1 AND approval_status='approved') AS active_vendors;
