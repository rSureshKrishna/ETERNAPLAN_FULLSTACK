-- ============================================================
-- EternaPlान™ - Sample Seed Data
-- ============================================================

USE eternaplan_db;

-- Companies
INSERT INTO companies (name, slug, email, phone, address, city, state, subscription_plan) VALUES
('EternaPlan Events Pvt Ltd', 'eternaplan', 'admin@eternaplan.in', '+91-9876543210', '42 MG Road, Nungambakkam', 'Chennai', 'Tamil Nadu', 'enterprise'),
('Royal Weddings & Events',   'royal-weddings', 'info@royalweddings.in', '+91-9812345678', '15 Park Street', 'Mumbai', 'Maharashtra', 'professional');

-- Users (passwords are bcrypt hash of 'Password@123')
INSERT INTO users (company_id, role_id, first_name, last_name, email, phone, password_hash, status, email_verified) VALUES
(1, 1, 'Arjun',    'Sharma',      'superadmin@eternaplan.in',   '+91-9876543210', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMlJFs68suWkpITQhKuHqJMKGe', 'active', 1),
(1, 2, 'Priya',    'Nair',        'admin@eternaplan.in',         '+91-9876543211', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMlJFs68suWkpITQhKuHqJMKGe', 'active', 1),
(1, 3, 'Rahul',    'Menon',       'manager1@eternaplan.in',      '+91-9876543212', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMlJFs68suWkpITQhKuHqJMKGe', 'active', 1),
(1, 3, 'Sneha',    'Krishnan',    'manager2@eternaplan.in',      '+91-9876543213', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMlJFs68suWkpITQhKuHqJMKGe', 'active', 1),
(1, 5, 'Vikram',   'Patel',       'customer1@example.com',       '+91-9876543214', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMlJFs68suWkpITQhKuHqJMKGe', 'active', 1),
(1, 4, 'Suresh',   'Catering',    'suresh@starcatering.com',     '+91-9876543215', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMlJFs68suWkpITQhKuHqJMKGe', 'active', 1);

-- Venues
INSERT INTO venues (company_id, name, description, address, city, state, capacity_min, capacity_max, indoor_outdoor, base_price, price_per_day, contact_name, contact_phone) VALUES
(1, 'The Grand Palace Banquet',    'Luxurious heritage banquet hall with gold decor and chandeliers', '12 Anna Salai, Triplicane', 'Chennai', 'Tamil Nadu', 100, 1000, 'indoor',  150000.00, 250000.00, 'Mr. Rajesh', '+91-9810001001'),
(1, 'Coastal Breeze Garden',       'Beachside open-air venue with stunning sea views',               'East Coast Road, Besant Nagar', 'Chennai', 'Tamil Nadu', 50,  500, 'outdoor', 80000.00,  120000.00, 'Mrs. Latha',  '+91-9810001002'),
(1, 'The Jade Convention Center',  'Modern air-conditioned convention center with multiple halls',   'Porur, Bangalore Highway',      'Chennai', 'Tamil Nadu', 200, 2000, 'indoor',  300000.00, 450000.00, 'Mr. Kumar',   '+91-9810001003'),
(1, 'Bloom Garden Lawn',           'Lush green garden perfect for daytime ceremonies',               'Velachery Main Road',           'Chennai', 'Tamil Nadu', 50,  400, 'outdoor', 60000.00,  90000.00,  'Ms. Preethi', '+91-9810001004');

-- Vendors
INSERT INTO vendors (company_id, category_id, business_name, contact_name, email, phone, city, description, min_price, max_price, approval_status, rating, total_reviews) VALUES
(1, 1,  'Star Catering Services',      'Suresh Kumar',   'suresh@starcatering.com',    '+91-9900001001', 'Chennai', 'Premium South Indian & Continental catering for 50-2000 guests', 50000,  500000,  'approved', 4.8, 127),
(1, 1,  'Royal Feast Caterers',        'Mohan Raj',      'mohan@royalfeast.com',       '+91-9900001002', 'Chennai', 'Specializing in North Indian and Mughlai cuisine',               40000,  400000,  'approved', 4.6, 89),
(1, 2,  'Pixel Perfect Photography',   'Arun Nair',      'arun@pixelperfect.com',      '+91-9900001003', 'Chennai', 'Award-winning wedding and portrait photography studio',          30000,  200000,  'approved', 4.9, 234),
(1, 2,  'Moments Forever Studio',      'Deepa Sharma',   'deepa@momentsforever.com',   '+91-9900001004', 'Chennai', 'Cinematic wedding photography with a documentary style',         25000,  150000,  'approved', 4.7, 156),
(1, 3,  'Cinematic Tales Videography', 'Karthik Rajan',  'karthik@cinematictales.com', '+91-9900001005', 'Chennai', '4K Cinematic wedding films, drone coverage, highlight reels',    40000,  250000,  'approved', 4.8, 98),
(1, 4,  'Dream Decor Studio',          'Anjali Menon',   'anjali@dreamdecor.com',      '+91-9900001006', 'Chennai', 'Luxury floral and theme decorations for all occasions',          20000,  300000,  'approved', 4.9, 312),
(1, 5,  'Glamour House Makeup',        'Lakshmi Devi',   'lakshmi@glamourhouse.com',   '+91-9900001007', 'Chennai', 'Bridal makeup, hair styling, and grooming packages',             8000,   50000,   'approved', 4.7, 445),
(1, 6,  'Beat Masters DJ',             'Vikram DJ',      'vikram@beatmasters.com',      '+91-9900001008', 'Chennai', 'Professional DJ with premium sound system and lighting',         15000,  80000,   'approved', 4.6, 78),
(1, 7,  'Petal Paradise Flowers',      'Geetha Floral',  'geetha@petalparadise.com',   '+91-9900001009', 'Chennai', 'Fresh flower arrangements, garlands, stage decorations',         10000,  100000,  'approved', 4.8, 189),
(1, 8,  'Sweet Memories Bakers',       'Ramya Baker',    'ramya@sweetmemories.com',    '+91-9900001010', 'Chennai', 'Custom wedding and celebration cakes with premium fondant',      5000,   50000,   'approved', 4.9, 267);

-- Vendor Packages
INSERT INTO vendor_packages (vendor_id, name, price, price_type, description, inclusions, min_guests, max_guests, is_popular) VALUES
(1, 'Silver Feast Package',   80000,  'fixed', 'Basic catering for 200 guests',       '["200 plates", "5 starters", "4 main course", "dessert", "water"]', 150, 200, 0),
(1, 'Gold Wedding Package',   180000, 'fixed', 'Premium catering for 500 guests',     '["500 plates", "8 starters", "6 main course", "dessert counter", "live counters"]', 400, 500, 1),
(1, 'Platinum Grand Package', 350000, 'fixed', 'Ultra-premium for 1000 guests',       '["1000 plates", "12 starters", "8 main", "live counters", "ice cream", "chef service"]', 800, 1000, 0),
(3, 'Classic Wedding',        45000,  'fixed', 'Full day wedding photography',         '["8 hrs coverage", "500 edited photos", "USB delivery", "1 album"]', NULL, NULL, 0),
(3, 'Premium Cinematic',      95000,  'fixed', 'Photography + Videography combo',      '["12 hrs coverage", "1000 edited photos", "highlight video", "2 albums", "drone"]', NULL, NULL, 1),
(6, 'Elegant Decor Package',  75000,  'fixed', 'Stage + Hall decoration',              '["Stage backdrop", "Floral arrangements", "Table centerpieces", "Aisle decor", "LED lighting"]', 200, 500, 1),
(7, 'Bridal Glam Package',    18000,  'fixed', 'Bridal makeup and hair for wedding',   '["Bridal makeup", "Hair styling", "Saree draping", "Touch-up kit"]', NULL, NULL, 1);

-- Customers
INSERT INTO customers (company_id, user_id, first_name, last_name, email, phone, source, lead_status, priority, assigned_to, anniversary_date) VALUES
(1, 5, 'Vikram',    'Patel',      'vikram.patel@gmail.com',     '+91-9876543214', 'referral',     'won',         'vip',    3, '2020-03-15'),
(1, NULL,'Ananya',   'Krishnan',  'ananya.k@gmail.com',         '+91-9712345678', 'social_media', 'confirmed',   'high',   3, NULL),
(1, NULL,'Rohit',    'Verma',     'rohit.verma@gmail.com',       '+91-9823456789', 'website',      'proposal_sent','medium',3, NULL),
(1, NULL,'Meera',    'Iyer',      'meera.iyer@gmail.com',        '+91-9934567890', 'walk_in',      'won',         'vip',    4, '2021-06-20'),
(1, NULL,'Aditya',   'Singh',     'aditya.singh@gmail.com',      '+91-9645678901', 'phone',        'qualified',   'medium', 4, NULL),
(1, NULL,'Kavya',    'Nambiar',   'kavya.n@gmail.com',           '+91-9756789012', 'referral',     'won',         'high',   3, '2019-11-08'),
(1, NULL,'Sanjay',   'Mehta',     'sanjay.mehta@gmail.com',      '+91-9867890123', 'website',      'contacted',   'low',    3, NULL),
(1, NULL,'Deepika',  'Rao',       'deepika.rao@gmail.com',       '+91-9978901234', 'social_media', 'won',         'high',   4, '2022-02-14');

-- Events
INSERT INTO events (company_id, customer_id, category_id, venue_id, assigned_to, event_name, event_code, event_date, event_time, end_date, guest_count_estimate, theme, status, budget_total, advance_paid) VALUES
(1, 1, 1, 1, 3, 'Vikram & Priya Wedding Ceremony',       'EVT-2025-0001', '2025-11-15', '09:00:00', '2025-11-15', 500, 'Royal Gold & Ivory',     'confirmed',   1200000.00, 300000.00),
(1, 2, 2, 2, 3, 'Ananya & Kiran Reception',              'EVT-2025-0002', '2025-12-05', '19:00:00', '2025-12-05', 300, 'Midnight Blue & Silver', 'planning',    600000.00,  150000.00),
(1, 4, 1, 3, 4, 'Meera & Arjun Grand Wedding',           'EVT-2025-0003', '2026-01-18', '08:00:00', '2026-01-19', 800, 'Pastel Pink & Gold',     'confirmed',   1800000.00, 500000.00),
(1, 6, 4, 4, 3, 'Kavya Birthday Celebration - 30th',     'EVT-2025-0004', '2025-10-20', '18:00:00', '2025-10-20', 150, 'Champagne & Rose Gold',  'completed',   250000.00,  250000.00),
(1, 5, 5, 3, 4, 'TechSol Annual Corporate Gala 2025',    'EVT-2025-0005', '2025-12-20', '18:00:00', '2025-12-20', 400, 'Black & Gold Corporate', 'planning',    800000.00,  200000.00),
(1, 8, 3, 1, 3, 'Deepika & Rahul Engagement Ceremony',   'EVT-2025-0006', '2025-11-01', '17:00:00', '2025-11-01', 200, 'Floral & Pastel',        'in_progress', 350000.00,  100000.00);

-- Event Tasks
INSERT INTO event_tasks (event_id, assigned_to, title, category, priority, status, due_date) VALUES
(1, 3, 'Confirm catering menu',           'Catering',     'high',     'completed', '2025-09-15'),
(1, 3, 'Finalize decoration theme',       'Decoration',   'high',     'completed', '2025-09-20'),
(1, 3, 'Send invitations to 500 guests',  'Guest Mgmt',   'critical', 'in_progress','2025-10-01'),
(1, 4, 'Confirm photographer booking',    'Photography',  'high',     'completed', '2025-09-10'),
(1, 4, 'Arrange mehendi artist',          'Beauty',       'medium',   'pending',   '2025-10-15'),
(1, 3, 'Coordinate DJ & Music',           'Entertainment','medium',   'pending',   '2025-10-20'),
(2, 3, 'Venue setup walkthrough',         'Venue',        'high',     'pending',   '2025-11-20'),
(2, 4, 'Finalize guest seating chart',    'Guest Mgmt',   'medium',   'pending',   '2025-11-25'),
(3, 4, 'Book bridal makeup artist',       'Beauty',       'high',     'pending',   '2025-12-01'),
(3, 4, 'Confirm 2-day catering package',  'Catering',     'critical', 'pending',   '2025-12-10');

-- Bookings
INSERT INTO bookings (company_id, event_id, vendor_id, package_id, booking_code, booking_type, booking_date, quoted_price, agreed_price, advance_amount, status, approval_status) VALUES
(1, 1, 1, 2, 'BK-2025-0001', 'vendor', '2025-11-15', 200000.00, 180000.00, 50000.00,  'confirmed', 'approved'),
(1, 1, 3, 5, 'BK-2025-0002', 'vendor', '2025-11-15', 100000.00, 95000.00,  30000.00,  'confirmed', 'approved'),
(1, 1, 6, 6, 'BK-2025-0003', 'vendor', '2025-11-15', 80000.00,  75000.00,  25000.00,  'confirmed', 'approved'),
(1, 1, 7, 7, 'BK-2025-0004', 'vendor', '2025-11-15', 20000.00,  18000.00,  8000.00,   'confirmed', 'approved'),
(1, 2, 1, 1, 'BK-2025-0005', 'vendor', '2025-12-05', 90000.00,  80000.00,  20000.00,  'pending',   'pending'),
(1, 2, 5, NULL,'BK-2025-0006', 'vendor', '2025-12-05', 60000.00,  55000.00,  15000.00,  'pending',   'approved'),
(1, 4, 1, 1, 'BK-2025-0007', 'vendor', '2025-10-20', 90000.00,  85000.00,  85000.00,  'completed', 'approved'),
(1, 4, 8, NULL,'BK-2025-0008', 'vendor', '2025-10-20', 25000.00,  22000.00,  22000.00,  'completed', 'approved');

-- Invoices
INSERT INTO invoices (company_id, event_id, customer_id, invoice_number, invoice_date, due_date, subtotal, tax_rate, tax_amount, grand_total, amount_paid, balance_due, status) VALUES
(1, 1, 1, 'INV-2025-00001', '2025-09-01', '2025-09-15', 368000.00, 18.00, 66240.00,  434240.00, 300000.00, 134240.00, 'partial'),
(1, 4, 6, 'INV-2025-00002', '2025-09-15', '2025-09-30', 107000.00, 18.00, 19260.00,  126260.00, 126260.00,       0.00, 'paid'),
(1, 2, 2, 'INV-2025-00003', '2025-10-01', '2025-10-15', 135000.00, 18.00, 24300.00,  159300.00, 150000.00,   9300.00, 'partial');

-- Invoice Items
INSERT INTO invoice_items (invoice_id, booking_id, description, category, quantity, unit_price, subtotal, total) VALUES
(1, 1, 'Gold Wedding Catering Package (500 guests)', 'Catering',     1, 180000.00, 180000.00, 180000.00),
(1, 2, 'Premium Cinematic Photography+Video',        'Photography',  1, 95000.00,  95000.00,  95000.00),
(1, 3, 'Elegant Stage & Hall Decoration',            'Decoration',   1, 75000.00,  75000.00,  75000.00),
(1, 4, 'Bridal Glam Makeup Package',                 'Makeup',       1, 18000.00,  18000.00,  18000.00),
(2, 7, 'Silver Feast Catering (150 guests)',          'Catering',     1, 85000.00,  85000.00,  85000.00),
(2, 8, 'DJ Beat Masters - 6 Hours',                  'DJ & Music',   1, 22000.00,  22000.00,  22000.00);

-- Payments
INSERT INTO payments (company_id, invoice_id, customer_id, payment_code, amount, payment_date, payment_method, payment_ref, status, payment_type) VALUES
(1, 1, 1, 'PAY-2025-0001', 300000.00, '2025-09-01', 'bank_transfer', 'NEFT-REF-001', 'completed', 'advance'),
(1, 2, 6, 'PAY-2025-0002', 126260.00, '2025-09-15', 'upi',           'UPI-9900001',  'completed', 'full'),
(1, 3, 2, 'PAY-2025-0003', 150000.00, '2025-10-01', 'upi',           'UPI-9900002',  'completed', 'advance');

-- Guests (Sample for Event 1)
INSERT INTO guests (event_id, first_name, last_name, email, phone, relation, side, category, rsvp_status, meal_preference, table_number) VALUES
(1, 'Rajesh',    'Patel',     'rajesh.p@gmail.com',    '+91-9000000001', 'Father of Groom', 'groom', 'family', 'attending',     'non_veg', 'T1'),
(1, 'Sunita',    'Patel',     'sunita.p@gmail.com',    '+91-9000000002', 'Mother of Groom', 'groom', 'family', 'attending',     'veg',     'T1'),
(1, 'Preethi',   'Krishnan',  'preethi.k@gmail.com',   '+91-9000000003', 'Father of Bride', 'bride', 'family', 'attending',     'veg',     'T2'),
(1, 'Savitha',   'Krishnan',  'savitha.k@gmail.com',   '+91-9000000004', 'Mother of Bride', 'bride', 'family', 'attending',     'veg',     'T2'),
(1, 'Arjun',     'Patel',     'arjun.p@gmail.com',     '+91-9000000005', 'Brother of Groom','groom', 'family', 'attending',     'non_veg', 'T3'),
(1, 'Siddharth', 'Krishnan',  'sidd.k@gmail.com',      '+91-9000000006', 'Brother of Bride','bride', 'family', 'attending',     'veg',     'T3'),
(1, 'Nikhil',    'Sharma',    'nikhil.s@gmail.com',    '+91-9000000007', 'College Friend',  'groom', 'friend', 'attending',     'non_veg', 'T5'),
(1, 'Divya',     'Menon',     'divya.m@gmail.com',     '+91-9000000008', 'School Friend',   'bride', 'friend', 'maybe',         'veg',     'T6'),
(1, 'Kiran',     'Nair',      'kiran.n@gmail.com',     '+91-9000000009', 'Colleague',       'mutual','colleague','not_attending',NULL,      NULL),
(1, 'Pooja',     'Rajan',     'pooja.r@gmail.com',     '+91-9000000010', 'Cousin',          'bride', 'family', 'attending',     'vegan',   'T4');

-- Expenses
INSERT INTO expenses (company_id, event_id, category, description, amount, expense_date, payment_method, status, created_by) VALUES
(1, 4, 'Decoration',   'Floral arrangements - Birthday',        15000.00, '2025-10-18', 'cash',         'paid', 3),
(1, 4, 'Catering',     'Advance to Star Catering',              50000.00, '2025-10-15', 'bank_transfer','paid', 3),
(1, 4, 'DJ & Music',   'Beat Masters DJ booking advance',       10000.00, '2025-10-16', 'upi',          'paid', 4),
(1, 4, 'Miscellaneous','Stationery and printing',                2500.00, '2025-10-18', 'cash',         'paid', 4),
(1, 1, 'Venue',        'Grand Palace advance payment',          75000.00, '2025-09-05', 'bank_transfer','paid', 3),
(1, 1, 'Marketing',    'Digital invitation design',              5000.00, '2025-09-10', 'upi',          'paid', 4);

-- Vendor Reviews
INSERT INTO vendor_reviews (vendor_id, customer_id, booking_id, rating, title, review, is_approved) VALUES
(1, 6, 7, 5, 'Outstanding catering!',        'Star Catering served 150 guests excellently. The food quality and variety was superb.',  1),
(8, 6, 8, 4, 'Great DJ performance',         'Beat Masters kept the energy high throughout the party. Very professional.',             1),
(3, 1, 2, 5, 'Best photographers in Chennai','Arun and team captured every beautiful moment. The cinematic video was breathtaking.',   1);

-- Notifications
INSERT INTO notifications (company_id, user_id, title, message, type, channel, is_read) VALUES
(1, 3, 'New Booking Confirmed',   'Booking BK-2025-0001 for Star Catering has been confirmed for Vikram & Priya Wedding.', 'booking',  'app', 0),
(1, 3, 'Payment Received',        'Payment of ₹3,00,000 received from Vikram Patel for INV-2025-00001.',                  'payment',  'app', 1),
(1, 5, 'Invoice Sent',            'Invoice INV-2025-00001 has been sent to your email. Amount due: ₹1,34,240.',           'payment',  'email', 1),
(1, 4, 'Task Due Tomorrow',       'Task "Arrange mehendi artist" for Vikram & Priya Wedding is due tomorrow.',            'task',     'app', 0),
(1, 3, 'Event Date Approaching',  'Deepika & Rahul Engagement is in 3 days. Please review final checklist.',              'reminder', 'app', 0);
