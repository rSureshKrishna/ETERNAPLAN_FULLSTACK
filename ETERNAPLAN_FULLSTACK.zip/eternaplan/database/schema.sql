-- ============================================================
-- EternaPlान™ - Wedding & Event Planning Management System
-- MySQL Database Schema v1.0
-- Fully Normalized (3NF), ACID Compliant, Production-Ready
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------
-- DATABASE
-- -----------------------------------------------
CREATE DATABASE IF NOT EXISTS eternaplan_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE eternaplan_db;

-- ============================================================
-- TABLE 1: companies (Multi-tenant SaaS support)
-- ============================================================
CREATE TABLE companies (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(200)  NOT NULL,
  slug          VARCHAR(100)  NOT NULL UNIQUE,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  phone         VARCHAR(20),
  address       TEXT,
  city          VARCHAR(100),
  state         VARCHAR(100),
  country       VARCHAR(100)  DEFAULT 'India',
  pincode       VARCHAR(10),
  logo_url      VARCHAR(500),
  website       VARCHAR(300),
  subscription_plan ENUM('starter','professional','enterprise') DEFAULT 'starter',
  subscription_expires_at DATETIME,
  is_active     TINYINT(1)    DEFAULT 1,
  settings      JSON,
  created_at    DATETIME      DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug),
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 2: roles
-- ============================================================
CREATE TABLE roles (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(50)  NOT NULL UNIQUE,
  display_name VARCHAR(100) NOT NULL,
  permissions JSON,
  is_system   TINYINT(1)  DEFAULT 0,
  created_at  DATETIME    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO roles (name, display_name, permissions, is_system) VALUES
('super_admin',   'Super Administrator', '{"all": true}', 1),
('admin',         'Administrator',       '{"company": true, "events": true, "vendors": true, "customers": true, "finance": true, "reports": true}', 1),
('event_manager', 'Event Manager',       '{"events": true, "vendors": true, "customers": true, "bookings": true}', 1),
('vendor',        'Vendor',              '{"own_profile": true, "bookings_view": true}', 1),
('customer',      'Customer',            '{"own_events": true, "own_bookings": true}', 1);

-- ============================================================
-- TABLE 3: users
-- ============================================================
CREATE TABLE users (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED,
  role_id         INT UNSIGNED NOT NULL DEFAULT 5,
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  email           VARCHAR(150) NOT NULL UNIQUE,
  phone           VARCHAR(20),
  password_hash   VARCHAR(255) NOT NULL,
  avatar_url      VARCHAR(500),
  date_of_birth   DATE,
  gender          ENUM('male','female','other','prefer_not_to_say'),
  address         TEXT,
  city            VARCHAR(100),
  state           VARCHAR(100),
  country         VARCHAR(100) DEFAULT 'India',
  otp_code        VARCHAR(10),
  otp_expires_at  DATETIME,
  email_verified  TINYINT(1)   DEFAULT 0,
  phone_verified  TINYINT(1)   DEFAULT 0,
  status          ENUM('active','inactive','suspended','pending') DEFAULT 'pending',
  last_login      DATETIME,
  failed_attempts INT          DEFAULT 0,
  locked_until    DATETIME,
  refresh_token   TEXT,
  password_reset_token VARCHAR(255),
  password_reset_expires DATETIME,
  preferences     JSON,
  created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT,
  INDEX idx_email (email),
  INDEX idx_company (company_id),
  INDEX idx_role (role_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 4: audit_logs
-- ============================================================
CREATE TABLE audit_logs (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED,
  company_id  INT UNSIGNED,
  action      VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100),
  entity_id   INT UNSIGNED,
  old_data    JSON,
  new_data    JSON,
  ip_address  VARCHAR(45),
  user_agent  TEXT,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_user (user_id),
  INDEX idx_entity (entity_type, entity_id),
  INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 5: event_categories
-- ============================================================
CREATE TABLE event_categories (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id  INT UNSIGNED,
  name        VARCHAR(100)  NOT NULL,
  slug        VARCHAR(100)  NOT NULL,
  icon        VARCHAR(100),
  color       VARCHAR(20),
  description TEXT,
  is_active   TINYINT(1) DEFAULT 1,
  sort_order  INT DEFAULT 0,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  UNIQUE KEY uq_category_slug (company_id, slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO event_categories (name, slug, icon, color) VALUES
('Wedding',           'wedding',           'rings',       '#C9A96E'),
('Reception',         'reception',         'champagne',   '#8B5CF6'),
('Engagement',        'engagement',        'heart',       '#EC4899'),
('Birthday Party',    'birthday-party',    'cake',        '#F59E0B'),
('Corporate Event',   'corporate-event',   'briefcase',   '#3B82F6'),
('Baby Shower',       'baby-shower',       'baby',        '#10B981'),
('Anniversary',       'anniversary',       'anniversary', '#EF4444'),
('Conference',        'conference',        'mic',         '#6366F1');

-- ============================================================
-- TABLE 6: venues
-- ============================================================
CREATE TABLE venues (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED,
  name            VARCHAR(200) NOT NULL,
  description     TEXT,
  address         TEXT NOT NULL,
  city            VARCHAR(100),
  state           VARCHAR(100),
  pincode         VARCHAR(10),
  google_maps_url VARCHAR(500),
  latitude        DECIMAL(10,8),
  longitude       DECIMAL(11,8),
  capacity_min    INT,
  capacity_max    INT NOT NULL,
  indoor_outdoor  ENUM('indoor','outdoor','both') DEFAULT 'indoor',
  amenities       JSON,
  images          JSON,
  base_price      DECIMAL(12,2) DEFAULT 0.00,
  price_per_hour  DECIMAL(10,2),
  price_per_day   DECIMAL(12,2),
  is_available    TINYINT(1) DEFAULT 1,
  rules           TEXT,
  contact_name    VARCHAR(200),
  contact_phone   VARCHAR(20),
  contact_email   VARCHAR(150),
  rating          DECIMAL(3,2) DEFAULT 0.00,
  total_reviews   INT DEFAULT 0,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  INDEX idx_city (city),
  INDEX idx_capacity (capacity_max),
  INDEX idx_available (is_available)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 7: customers
-- ============================================================
CREATE TABLE customers (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED NOT NULL,
  user_id         INT UNSIGNED,
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  email           VARCHAR(150),
  phone           VARCHAR(20) NOT NULL,
  whatsapp        VARCHAR(20),
  date_of_birth   DATE,
  anniversary_date DATE,
  address         TEXT,
  city            VARCHAR(100),
  state           VARCHAR(100),
  country         VARCHAR(100) DEFAULT 'India',
  source          ENUM('walk_in','referral','website','social_media','phone','other') DEFAULT 'walk_in',
  referred_by     INT UNSIGNED,
  lead_status     ENUM('new','contacted','qualified','proposal_sent','negotiation','won','lost','dormant') DEFAULT 'new',
  priority        ENUM('low','medium','high','vip') DEFAULT 'medium',
  tags            JSON,
  notes           TEXT,
  total_events    INT DEFAULT 0,
  total_revenue   DECIMAL(14,2) DEFAULT 0.00,
  is_active       TINYINT(1) DEFAULT 1,
  assigned_to     INT UNSIGNED,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (referred_by) REFERENCES customers(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_company (company_id),
  INDEX idx_phone (phone),
  INDEX idx_lead_status (lead_status),
  INDEX idx_priority (priority),
  FULLTEXT INDEX ft_customer_search (first_name, last_name, email, phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 8: customer_notes
-- ============================================================
CREATE TABLE customer_notes (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_id INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  note        TEXT NOT NULL,
  note_type   ENUM('general','followup','complaint','meeting','call','other') DEFAULT 'general',
  followup_at DATETIME,
  is_private  TINYINT(1) DEFAULT 0,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_customer (customer_id),
  INDEX idx_followup (followup_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 9: events
-- ============================================================
CREATE TABLE events (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED NOT NULL,
  customer_id     INT UNSIGNED NOT NULL,
  category_id     INT UNSIGNED,
  venue_id        INT UNSIGNED,
  assigned_to     INT UNSIGNED,
  event_name      VARCHAR(300) NOT NULL,
  event_code      VARCHAR(20) NOT NULL UNIQUE,
  description     TEXT,
  event_date      DATE NOT NULL,
  event_time      TIME,
  end_date        DATE,
  end_time        TIME,
  guest_count_estimate INT DEFAULT 0,
  guest_count_actual   INT DEFAULT 0,
  theme           VARCHAR(200),
  color_scheme    VARCHAR(200),
  dress_code      VARCHAR(200),
  special_requirements TEXT,
  status          ENUM('inquiry','planning','confirmed','in_progress','completed','cancelled','postponed') DEFAULT 'inquiry',
  budget_total    DECIMAL(14,2) DEFAULT 0.00,
  budget_spent    DECIMAL(14,2) DEFAULT 0.00,
  advance_paid    DECIMAL(14,2) DEFAULT 0.00,
  balance_due     DECIMAL(14,2) DEFAULT 0.00,
  contract_url    VARCHAR(500),
  images          JSON,
  checklist       JSON,
  timeline        JSON,
  notes           TEXT,
  internal_notes  TEXT,
  metadata        JSON,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES event_categories(id) ON DELETE SET NULL,
  FOREIGN KEY (venue_id) REFERENCES venues(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_company (company_id),
  INDEX idx_customer (customer_id),
  INDEX idx_date (event_date),
  INDEX idx_status (status),
  INDEX idx_code (event_code),
  FULLTEXT INDEX ft_event_search (event_name, theme)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 10: event_tasks
-- ============================================================
CREATE TABLE event_tasks (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id        INT UNSIGNED NOT NULL,
  parent_task_id  INT UNSIGNED,
  assigned_to     INT UNSIGNED,
  title           VARCHAR(300) NOT NULL,
  description     TEXT,
  category        VARCHAR(100),
  priority        ENUM('low','medium','high','critical') DEFAULT 'medium',
  status          ENUM('pending','in_progress','completed','blocked','cancelled') DEFAULT 'pending',
  due_date        DATE,
  due_time        TIME,
  completed_at    DATETIME,
  sort_order      INT DEFAULT 0,
  created_by      INT UNSIGNED,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_task_id) REFERENCES event_tasks(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_event (event_id),
  INDEX idx_assigned (assigned_to),
  INDEX idx_status (status),
  INDEX idx_due_date (due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 11: vendor_categories
-- ============================================================
CREATE TABLE vendor_categories (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL UNIQUE,
  slug        VARCHAR(100) NOT NULL UNIQUE,
  icon        VARCHAR(100),
  description TEXT,
  is_active   TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO vendor_categories (name, slug, icon) VALUES
('Catering',        'catering',        'utensils'),
('Photography',     'photography',     'camera'),
('Videography',     'videography',     'video'),
('Decoration',      'decoration',      'sparkles'),
('Makeup & Beauty', 'makeup-beauty',   'paintbrush'),
('DJ & Music',      'dj-music',        'music'),
('Flower Supplier', 'flower-supplier', 'flower'),
('Wedding Cake',    'wedding-cake',    'cake'),
('Transportation',  'transportation',  'car'),
('Lighting',        'lighting',        'bulb'),
('Invitations',     'invitations',     'mail'),
('Security',        'security',        'shield'),
('Tent & Canopy',   'tent-canopy',     'tent'),
('Sound System',    'sound-system',    'speaker');

-- ============================================================
-- TABLE 12: vendors
-- ============================================================
CREATE TABLE vendors (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED,
  user_id         INT UNSIGNED,
  category_id     INT UNSIGNED NOT NULL,
  business_name   VARCHAR(200) NOT NULL,
  contact_name    VARCHAR(200),
  email           VARCHAR(150),
  phone           VARCHAR(20) NOT NULL,
  whatsapp        VARCHAR(20),
  address         TEXT,
  city            VARCHAR(100),
  state           VARCHAR(100),
  website         VARCHAR(300),
  social_media    JSON,
  description     TEXT,
  specializations JSON,
  service_areas   JSON,
  min_price       DECIMAL(10,2),
  max_price       DECIMAL(10,2),
  currency        VARCHAR(5) DEFAULT 'INR',
  portfolio_images JSON,
  documents       JSON,
  bank_details    JSON,
  gst_number      VARCHAR(20),
  pan_number      VARCHAR(20),
  approval_status ENUM('pending','approved','rejected','suspended') DEFAULT 'pending',
  is_featured     TINYINT(1) DEFAULT 0,
  rating          DECIMAL(3,2) DEFAULT 0.00,
  total_reviews   INT DEFAULT 0,
  total_events    INT DEFAULT 0,
  total_revenue   DECIMAL(14,2) DEFAULT 0.00,
  notes           TEXT,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (category_id) REFERENCES vendor_categories(id) ON DELETE RESTRICT,
  INDEX idx_category (category_id),
  INDEX idx_city (city),
  INDEX idx_status (approval_status),
  INDEX idx_rating (rating),
  FULLTEXT INDEX ft_vendor_search (business_name, contact_name, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 13: vendor_packages
-- ============================================================
CREATE TABLE vendor_packages (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  vendor_id   INT UNSIGNED NOT NULL,
  name        VARCHAR(200) NOT NULL,
  description TEXT,
  inclusions  JSON,
  exclusions  JSON,
  price       DECIMAL(12,2) NOT NULL,
  price_type  ENUM('fixed','per_hour','per_day','per_person','negotiable') DEFAULT 'fixed',
  min_guests  INT,
  max_guests  INT,
  duration_hours INT,
  is_popular  TINYINT(1) DEFAULT 0,
  is_active   TINYINT(1) DEFAULT 1,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE,
  INDEX idx_vendor (vendor_id),
  INDEX idx_price (price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 14: bookings
-- ============================================================
CREATE TABLE bookings (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED NOT NULL,
  event_id        INT UNSIGNED NOT NULL,
  vendor_id       INT UNSIGNED,
  venue_id        INT UNSIGNED,
  package_id      INT UNSIGNED,
  booking_code    VARCHAR(30) NOT NULL UNIQUE,
  booking_type    ENUM('vendor','venue') NOT NULL DEFAULT 'vendor',
  booking_date    DATE NOT NULL,
  start_time      TIME,
  end_time        TIME,
  end_date        DATE,
  quoted_price    DECIMAL(12,2) DEFAULT 0.00,
  agreed_price    DECIMAL(12,2) DEFAULT 0.00,
  advance_amount  DECIMAL(12,2) DEFAULT 0.00,
  balance_amount  DECIMAL(12,2) DEFAULT 0.00,
  status          ENUM('pending','confirmed','in_progress','completed','cancelled','no_show') DEFAULT 'pending',
  approval_status ENUM('pending','approved','rejected') DEFAULT 'pending',
  approved_by     INT UNSIGNED,
  approved_at     DATETIME,
  cancellation_reason TEXT,
  cancelled_at    DATETIME,
  special_requirements TEXT,
  contract_url    VARCHAR(500),
  notes           TEXT,
  created_by      INT UNSIGNED,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
  FOREIGN KEY (venue_id) REFERENCES venues(id) ON DELETE SET NULL,
  FOREIGN KEY (package_id) REFERENCES vendor_packages(id) ON DELETE SET NULL,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_event (event_id),
  INDEX idx_vendor (vendor_id),
  INDEX idx_date (booking_date),
  INDEX idx_status (status),
  INDEX idx_code (booking_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 15: vendor_reviews
-- ============================================================
CREATE TABLE vendor_reviews (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  vendor_id   INT UNSIGNED NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  booking_id  INT UNSIGNED,
  rating      TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title       VARCHAR(200),
  review      TEXT,
  response    TEXT,
  responded_at DATETIME,
  is_approved TINYINT(1) DEFAULT 0,
  is_featured TINYINT(1) DEFAULT 0,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
  UNIQUE KEY uq_review (vendor_id, customer_id, booking_id),
  INDEX idx_vendor (vendor_id),
  INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 16: invoices
-- ============================================================
CREATE TABLE invoices (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED NOT NULL,
  event_id        INT UNSIGNED NOT NULL,
  customer_id     INT UNSIGNED NOT NULL,
  invoice_number  VARCHAR(50) NOT NULL UNIQUE,
  invoice_date    DATE NOT NULL,
  due_date        DATE NOT NULL,
  subtotal        DECIMAL(14,2) DEFAULT 0.00,
  discount_type   ENUM('percentage','fixed') DEFAULT 'fixed',
  discount_value  DECIMAL(10,2) DEFAULT 0.00,
  discount_amount DECIMAL(12,2) DEFAULT 0.00,
  tax_rate        DECIMAL(5,2) DEFAULT 18.00,
  tax_amount      DECIMAL(12,2) DEFAULT 0.00,
  grand_total     DECIMAL(14,2) DEFAULT 0.00,
  amount_paid     DECIMAL(14,2) DEFAULT 0.00,
  balance_due     DECIMAL(14,2) DEFAULT 0.00,
  currency        VARCHAR(5) DEFAULT 'INR',
  status          ENUM('draft','sent','viewed','partial','paid','overdue','cancelled') DEFAULT 'draft',
  notes           TEXT,
  terms           TEXT,
  pdf_url         VARCHAR(500),
  sent_at         DATETIME,
  paid_at         DATETIME,
  created_by      INT UNSIGNED,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  INDEX idx_event (event_id),
  INDEX idx_customer (customer_id),
  INDEX idx_status (status),
  INDEX idx_due_date (due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 17: invoice_items
-- ============================================================
CREATE TABLE invoice_items (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice_id    INT UNSIGNED NOT NULL,
  booking_id    INT UNSIGNED,
  description   VARCHAR(500) NOT NULL,
  category      VARCHAR(100),
  quantity      DECIMAL(10,2) DEFAULT 1.00,
  unit          VARCHAR(50) DEFAULT 'unit',
  unit_price    DECIMAL(12,2) NOT NULL,
  subtotal      DECIMAL(14,2) NOT NULL,
  tax_rate      DECIMAL(5,2) DEFAULT 0.00,
  tax_amount    DECIMAL(12,2) DEFAULT 0.00,
  total         DECIMAL(14,2) NOT NULL,
  sort_order    INT DEFAULT 0,

  FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
  INDEX idx_invoice (invoice_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 18: payments
-- ============================================================
CREATE TABLE payments (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id      INT UNSIGNED NOT NULL,
  invoice_id      INT UNSIGNED,
  booking_id      INT UNSIGNED,
  customer_id     INT UNSIGNED NOT NULL,
  payment_code    VARCHAR(50) NOT NULL UNIQUE,
  amount          DECIMAL(14,2) NOT NULL,
  currency        VARCHAR(5) DEFAULT 'INR',
  payment_date    DATE NOT NULL,
  payment_method  ENUM('cash','upi','bank_transfer','cheque','card','online','other') NOT NULL,
  payment_ref     VARCHAR(200),
  gateway_txn_id  VARCHAR(200),
  gateway_name    VARCHAR(100),
  status          ENUM('pending','processing','completed','failed','refunded','partial_refund') DEFAULT 'pending',
  payment_type    ENUM('advance','installment','full','refund','partial') DEFAULT 'full',
  notes           TEXT,
  receipt_url     VARCHAR(500),
  verified_by     INT UNSIGNED,
  verified_at     DATETIME,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  INDEX idx_invoice (invoice_id),
  INDEX idx_customer (customer_id),
  INDEX idx_date (payment_date),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 19: expenses
-- ============================================================
CREATE TABLE expenses (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id    INT UNSIGNED NOT NULL,
  event_id      INT UNSIGNED,
  booking_id    INT UNSIGNED,
  vendor_id     INT UNSIGNED,
  category      VARCHAR(100) NOT NULL,
  description   VARCHAR(500) NOT NULL,
  amount        DECIMAL(14,2) NOT NULL,
  currency      VARCHAR(5) DEFAULT 'INR',
  expense_date  DATE NOT NULL,
  payment_method ENUM('cash','upi','bank_transfer','cheque','card','other') DEFAULT 'cash',
  receipt_url   VARCHAR(500),
  status        ENUM('pending','approved','rejected','paid') DEFAULT 'pending',
  approved_by   INT UNSIGNED,
  approved_at   DATETIME,
  notes         TEXT,
  created_by    INT UNSIGNED,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
  INDEX idx_event (event_id),
  INDEX idx_date (expense_date),
  INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 20: guests
-- ============================================================
CREATE TABLE guests (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id        INT UNSIGNED NOT NULL,
  group_id        INT UNSIGNED,
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100),
  email           VARCHAR(150),
  phone           VARCHAR(20),
  relation        VARCHAR(100),
  side            ENUM('bride','groom','mutual','other') DEFAULT 'mutual',
  category        ENUM('family','friend','colleague','vip','other') DEFAULT 'friend',
  invitation_code VARCHAR(30) UNIQUE,
  qr_code         VARCHAR(500),
  rsvp_status     ENUM('pending','attending','not_attending','maybe') DEFAULT 'pending',
  rsvp_date       DATETIME,
  meal_preference ENUM('veg','non_veg','vegan','jain','no_preference') DEFAULT 'no_preference',
  table_number    VARCHAR(20),
  seat_number     VARCHAR(20),
  dietary_notes   TEXT,
  has_plus_one    TINYINT(1) DEFAULT 0,
  plus_one_name   VARCHAR(200),
  checked_in      TINYINT(1) DEFAULT 0,
  checked_in_at   DATETIME,
  gift_received   TEXT,
  notes           TEXT,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  INDEX idx_event (event_id),
  INDEX idx_rsvp (rsvp_status),
  INDEX idx_code (invitation_code),
  FULLTEXT INDEX ft_guest_search (first_name, last_name, email, phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 21: guest_groups
-- ============================================================
CREATE TABLE guest_groups (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id    INT UNSIGNED NOT NULL,
  name        VARCHAR(200) NOT NULL,
  description TEXT,
  color       VARCHAR(20),
  table_number VARCHAR(20),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  INDEX idx_event (event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE guests ADD CONSTRAINT fk_guest_group 
  FOREIGN KEY (group_id) REFERENCES guest_groups(id) ON DELETE SET NULL;

-- ============================================================
-- TABLE 22: notifications
-- ============================================================
CREATE TABLE notifications (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id  INT UNSIGNED,
  user_id     INT UNSIGNED,
  title       VARCHAR(300) NOT NULL,
  message     TEXT NOT NULL,
  type        ENUM('booking','payment','event','task','system','reminder','alert') DEFAULT 'system',
  channel     ENUM('app','email','sms','whatsapp','push') DEFAULT 'app',
  entity_type VARCHAR(100),
  entity_id   INT UNSIGNED,
  is_read     TINYINT(1) DEFAULT 0,
  read_at     DATETIME,
  sent_at     DATETIME,
  scheduled_at DATETIME,
  metadata    JSON,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_read (is_read),
  INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 23: venue_bookings (Conflict tracking)
-- ============================================================
CREATE TABLE venue_bookings (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  venue_id    INT UNSIGNED NOT NULL,
  event_id    INT UNSIGNED NOT NULL,
  booking_id  INT UNSIGNED,
  booked_date DATE NOT NULL,
  start_time  TIME,
  end_time    TIME,
  status      ENUM('reserved','confirmed','cancelled') DEFAULT 'reserved',
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (venue_id) REFERENCES venues(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  UNIQUE KEY uq_venue_date_time (venue_id, booked_date, start_time),
  INDEX idx_venue_date (venue_id, booked_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TABLE 24: subscription_plans
-- ============================================================
CREATE TABLE subscription_plans (
  id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name                VARCHAR(100) NOT NULL,
  slug                VARCHAR(50) NOT NULL UNIQUE,
  description         TEXT,
  price_monthly       DECIMAL(10,2) NOT NULL,
  price_yearly        DECIMAL(10,2) NOT NULL,
  max_events_per_month INT,
  max_users           INT,
  max_vendors         INT,
  max_storage_gb      INT,
  features            JSON,
  is_active           TINYINT(1) DEFAULT 1,
  created_at          DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO subscription_plans (name, slug, price_monthly, price_yearly, max_events_per_month, max_users, max_vendors, max_storage_gb, features) VALUES
('Starter',      'starter',      999,  9990,  5,   3,   10, 5,   '{"analytics": false, "ai_suggestions": false, "whatsapp": false}'),
('Professional', 'professional', 2999, 29990, 25,  10,  50, 25,  '{"analytics": true, "ai_suggestions": false, "whatsapp": true}'),
('Enterprise',   'enterprise',   7999, 79990, NULL, NULL, NULL, 100, '{"analytics": true, "ai_suggestions": true, "whatsapp": true, "custom_domain": true}');

-- ============================================================
-- TABLE 25: activity_feed
-- ============================================================
CREATE TABLE activity_feed (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id  INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED,
  event_id    INT UNSIGNED,
  entity_type VARCHAR(100),
  entity_id   INT UNSIGNED,
  action      VARCHAR(100) NOT NULL,
  description TEXT,
  metadata    JSON,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  INDEX idx_company (company_id),
  INDEX idx_event (event_id),
  INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- VIEWS
-- ============================================================

-- View: Event Summary with Customer and Venue
CREATE OR REPLACE VIEW vw_event_summary AS
SELECT
  e.id,
  e.event_code,
  e.event_name,
  e.event_date,
  e.event_time,
  e.status,
  e.guest_count_estimate,
  e.budget_total,
  e.budget_spent,
  e.advance_paid,
  e.balance_due,
  CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
  c.phone AS customer_phone,
  c.email AS customer_email,
  ec.name AS category_name,
  ec.color AS category_color,
  v.name AS venue_name,
  v.city AS venue_city,
  CONCAT(u.first_name, ' ', u.last_name) AS assigned_to_name,
  e.company_id,
  e.created_at
FROM events e
LEFT JOIN customers c ON e.customer_id = c.id
LEFT JOIN event_categories ec ON e.category_id = ec.id
LEFT JOIN venues v ON e.venue_id = v.id
LEFT JOIN users u ON e.assigned_to = u.id;

-- View: Vendor Performance
CREATE OR REPLACE VIEW vw_vendor_performance AS
SELECT
  v.id,
  v.business_name,
  vc.name AS category,
  v.city,
  v.rating,
  v.total_reviews,
  v.total_events,
  v.total_revenue,
  COUNT(b.id) AS total_bookings,
  COUNT(CASE WHEN b.status = 'completed' THEN 1 END) AS completed_bookings,
  COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) AS cancelled_bookings,
  AVG(b.agreed_price) AS avg_booking_value
FROM vendors v
LEFT JOIN vendor_categories vc ON v.category_id = vc.id
LEFT JOIN bookings b ON v.id = b.vendor_id
GROUP BY v.id;

-- View: Financial Summary by Event
CREATE OR REPLACE VIEW vw_event_financials AS
SELECT
  e.id AS event_id,
  e.event_code,
  e.event_name,
  e.event_date,
  e.budget_total,
  COALESCE(SUM(CASE WHEN p.status = 'completed' THEN p.amount ELSE 0 END), 0) AS total_received,
  COALESCE(SUM(exp.amount), 0) AS total_expenses,
  e.budget_total - COALESCE(SUM(exp.amount), 0) AS remaining_budget,
  COALESCE(SUM(CASE WHEN p.status = 'completed' THEN p.amount ELSE 0 END), 0)
    - COALESCE(SUM(exp.amount), 0) AS net_profit
FROM events e
LEFT JOIN invoices i ON e.id = i.event_id
LEFT JOIN payments p ON i.id = p.invoice_id
LEFT JOIN expenses exp ON e.id = exp.event_id
GROUP BY e.id;

-- View: Customer 360
CREATE OR REPLACE VIEW vw_customer_360 AS
SELECT
  c.id,
  CONCAT(c.first_name, ' ', c.last_name) AS full_name,
  c.email,
  c.phone,
  c.lead_status,
  c.priority,
  c.source,
  c.total_events,
  c.total_revenue,
  COUNT(e.id) AS event_count,
  MAX(e.event_date) AS last_event_date,
  COALESCE(SUM(CASE WHEN p.status='completed' THEN p.amount END), 0) AS lifetime_value,
  CONCAT(u.first_name, ' ', u.last_name) AS assigned_manager
FROM customers c
LEFT JOIN events e ON c.id = e.customer_id
LEFT JOIN invoices i ON e.id = i.event_id
LEFT JOIN payments p ON i.id = p.invoice_id
LEFT JOIN users u ON c.assigned_to = u.id
GROUP BY c.id;

-- View: Revenue Dashboard
CREATE OR REPLACE VIEW vw_revenue_dashboard AS
SELECT
  DATE_FORMAT(p.payment_date, '%Y-%m') AS month,
  COUNT(DISTINCT p.id) AS payment_count,
  SUM(p.amount) AS total_revenue,
  COUNT(DISTINCT p.customer_id) AS unique_customers,
  AVG(p.amount) AS avg_payment,
  SUM(CASE WHEN p.payment_method = 'cash' THEN p.amount ELSE 0 END) AS cash_revenue,
  SUM(CASE WHEN p.payment_method = 'upi' THEN p.amount ELSE 0 END) AS upi_revenue,
  SUM(CASE WHEN p.payment_method = 'bank_transfer' THEN p.amount ELSE 0 END) AS bank_revenue
FROM payments p
WHERE p.status = 'completed'
GROUP BY DATE_FORMAT(p.payment_date, '%Y-%m');

-- ============================================================
-- STORED PROCEDURES
-- ============================================================

DELIMITER //

-- Procedure: Generate Unique Event Code
CREATE PROCEDURE sp_generate_event_code(
  IN p_company_id INT,
  OUT p_event_code VARCHAR(20)
)
BEGIN
  DECLARE v_year VARCHAR(4);
  DECLARE v_count INT;
  SET v_year = YEAR(CURDATE());
  SELECT COUNT(*) + 1 INTO v_count
  FROM events WHERE company_id = p_company_id
  AND YEAR(created_at) = v_year;
  SET p_event_code = CONCAT('EVT-', v_year, '-', LPAD(v_count, 4, '0'));
END //

-- Procedure: Create Invoice with Items
CREATE PROCEDURE sp_create_invoice(
  IN p_company_id INT,
  IN p_event_id INT,
  IN p_customer_id INT,
  IN p_discount_percentage DECIMAL(5,2),
  IN p_tax_rate DECIMAL(5,2)
)
BEGIN
  DECLARE v_subtotal DECIMAL(14,2);
  DECLARE v_discount DECIMAL(12,2);
  DECLARE v_tax DECIMAL(12,2);
  DECLARE v_total DECIMAL(14,2);
  DECLARE v_invoice_num VARCHAR(50);

  -- Calculate subtotal from bookings
  SELECT COALESCE(SUM(agreed_price), 0) INTO v_subtotal
  FROM bookings WHERE event_id = p_event_id AND status != 'cancelled';

  SET v_discount = v_subtotal * (p_discount_percentage / 100);
  SET v_tax = (v_subtotal - v_discount) * (p_tax_rate / 100);
  SET v_total = v_subtotal - v_discount + v_tax;
  SET v_invoice_num = CONCAT('INV-', YEAR(CURDATE()), '-', LPAD(
    (SELECT COUNT(*) + 1 FROM invoices WHERE company_id = p_company_id), 5, '0'
  ));

  INSERT INTO invoices (
    company_id, event_id, customer_id, invoice_number, invoice_date, due_date,
    subtotal, discount_value, discount_amount, tax_rate, tax_amount, grand_total, balance_due
  ) VALUES (
    p_company_id, p_event_id, p_customer_id, v_invoice_num, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 15 DAY),
    v_subtotal, p_discount_percentage, v_discount, p_tax_rate, v_tax, v_total, v_total
  );
END //

-- Procedure: Get Dashboard Analytics
CREATE PROCEDURE sp_dashboard_analytics(IN p_company_id INT, IN p_year INT)
BEGIN
  -- Monthly revenue
  SELECT
    MONTH(p.payment_date) AS month_num,
    MONTHNAME(p.payment_date) AS month_name,
    SUM(p.amount) AS revenue,
    COUNT(DISTINCT p.id) AS transactions
  FROM payments p
  JOIN invoices i ON p.invoice_id = i.id
  WHERE i.company_id = p_company_id
    AND YEAR(p.payment_date) = p_year
    AND p.status = 'completed'
  GROUP BY MONTH(p.payment_date)
  ORDER BY month_num;

  -- Event status distribution
  SELECT status, COUNT(*) AS count
  FROM events
  WHERE company_id = p_company_id
  GROUP BY status;

  -- Top vendors by revenue
  SELECT v.business_name, vc.name AS category, SUM(b.agreed_price) AS revenue
  FROM bookings b
  JOIN vendors v ON b.vendor_id = v.id
  JOIN vendor_categories vc ON v.category_id = vc.id
  WHERE b.company_id = p_company_id AND b.status = 'completed'
  GROUP BY v.id ORDER BY revenue DESC LIMIT 5;
END //

-- Procedure: Check Venue Availability
CREATE PROCEDURE sp_check_venue_availability(
  IN p_venue_id INT,
  IN p_date DATE,
  IN p_start_time TIME,
  IN p_end_time TIME,
  OUT p_is_available TINYINT
)
BEGIN
  DECLARE v_conflict_count INT;
  SELECT COUNT(*) INTO v_conflict_count
  FROM venue_bookings
  WHERE venue_id = p_venue_id
    AND booked_date = p_date
    AND status IN ('reserved','confirmed')
    AND (
      (start_time < p_end_time AND end_time > p_start_time)
    );
  SET p_is_available = IF(v_conflict_count = 0, 1, 0);
END //

-- Procedure: Update Event Financials
CREATE PROCEDURE sp_update_event_financials(IN p_event_id INT)
BEGIN
  DECLARE v_budget_spent DECIMAL(14,2);
  DECLARE v_advance_paid DECIMAL(14,2);
  DECLARE v_balance DECIMAL(14,2);

  SELECT COALESCE(SUM(amount), 0) INTO v_budget_spent
  FROM expenses WHERE event_id = p_event_id;

  SELECT COALESCE(SUM(p.amount), 0) INTO v_advance_paid
  FROM payments p
  JOIN invoices i ON p.invoice_id = i.id
  WHERE i.event_id = p_event_id AND p.status = 'completed';

  SELECT (COALESCE(SUM(grand_total), 0) - v_advance_paid) INTO v_balance
  FROM invoices WHERE event_id = p_event_id;

  UPDATE events
  SET budget_spent = v_budget_spent,
      advance_paid = v_advance_paid,
      balance_due = GREATEST(v_balance, 0)
  WHERE id = p_event_id;
END //

DELIMITER ;

-- ============================================================
-- FUNCTIONS
-- ============================================================

DELIMITER //

CREATE FUNCTION fn_get_customer_ltv(p_customer_id INT)
RETURNS DECIMAL(14,2)
READS SQL DATA
DETERMINISTIC
BEGIN
  DECLARE v_ltv DECIMAL(14,2);
  SELECT COALESCE(SUM(p.amount), 0) INTO v_ltv
  FROM payments p
  JOIN invoices i ON p.invoice_id = i.id
  JOIN events e ON i.event_id = e.id
  WHERE e.customer_id = p_customer_id AND p.status = 'completed';
  RETURN v_ltv;
END //

CREATE FUNCTION fn_event_completion_pct(p_event_id INT)
RETURNS DECIMAL(5,2)
READS SQL DATA
DETERMINISTIC
BEGIN
  DECLARE v_total INT;
  DECLARE v_completed INT;
  SELECT COUNT(*) INTO v_total FROM event_tasks WHERE event_id = p_event_id;
  SELECT COUNT(*) INTO v_completed FROM event_tasks
  WHERE event_id = p_event_id AND status = 'completed';
  IF v_total = 0 THEN RETURN 0; END IF;
  RETURN ROUND((v_completed / v_total) * 100, 2);
END //

DELIMITER ;

-- ============================================================
-- TRIGGERS
-- ============================================================

DELIMITER //

-- Trigger: Auto-update invoice balance after payment
CREATE TRIGGER tr_payment_after_insert
AFTER INSERT ON payments
FOR EACH ROW
BEGIN
  IF NEW.status = 'completed' AND NEW.invoice_id IS NOT NULL THEN
    UPDATE invoices
    SET amount_paid = amount_paid + NEW.amount,
        balance_due = GREATEST(balance_due - NEW.amount, 0),
        status = CASE
          WHEN (balance_due - NEW.amount) <= 0 THEN 'paid'
          WHEN (balance_due - NEW.amount) < grand_total THEN 'partial'
          ELSE status
        END,
        paid_at = CASE WHEN (balance_due - NEW.amount) <= 0 THEN NOW() ELSE paid_at END
    WHERE id = NEW.invoice_id;
    -- Update event financials
    CALL sp_update_event_financials(
      (SELECT event_id FROM invoices WHERE id = NEW.invoice_id)
    );
  END IF;
END //

-- Trigger: Auto-update vendor stats on booking completion
CREATE TRIGGER tr_booking_after_update
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
  IF NEW.status = 'completed' AND OLD.status != 'completed' AND NEW.vendor_id IS NOT NULL THEN
    UPDATE vendors
    SET total_events = total_events + 1,
        total_revenue = total_revenue + NEW.agreed_price
    WHERE id = NEW.vendor_id;
  END IF;
END //

-- Trigger: Log customer total events on new event
CREATE TRIGGER tr_event_after_insert
AFTER INSERT ON events
FOR EACH ROW
BEGIN
  UPDATE customers SET total_events = total_events + 1
  WHERE id = NEW.customer_id;
  INSERT INTO activity_feed (company_id, user_id, event_id, entity_type, entity_id, action, description)
  VALUES (NEW.company_id, NEW.assigned_to, NEW.id, 'event', NEW.id, 'event_created',
          CONCAT('New event created: ', NEW.event_name));
END //

-- Trigger: Update vendor rating after review
CREATE TRIGGER tr_review_after_insert
AFTER INSERT ON vendor_reviews
FOR EACH ROW
BEGIN
  IF NEW.is_approved = 1 THEN
    UPDATE vendors
    SET rating = (SELECT AVG(rating) FROM vendor_reviews WHERE vendor_id = NEW.vendor_id AND is_approved = 1),
        total_reviews = total_reviews + 1
    WHERE id = NEW.vendor_id;
  END IF;
END //

DELIMITER ;

-- ============================================================
-- INDEXES FOR PERFORMANCE OPTIMIZATION
-- ============================================================

-- Composite indexes for common queries
CREATE INDEX idx_events_company_date ON events(company_id, event_date);
CREATE INDEX idx_events_company_status ON events(company_id, status);
CREATE INDEX idx_bookings_company_date ON bookings(company_id, booking_date);
CREATE INDEX idx_payments_company_date ON payments(company_id, payment_date);
CREATE INDEX idx_expenses_company_date ON expenses(company_id, expense_date);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read);
CREATE INDEX idx_guests_event_rsvp ON guests(event_id, rsvp_status);

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- ADVANCED QUERIES DOCUMENTATION
-- ============================================================

/*
-- CTE: Upcoming events with task completion percentage
WITH EventProgress AS (
  SELECT e.id, e.event_name, e.event_date,
    ROUND(COUNT(CASE WHEN et.status = 'completed' THEN 1 END) * 100.0 / NULLIF(COUNT(et.id), 0), 2) AS completion_pct
  FROM events e LEFT JOIN event_tasks et ON e.id = et.event_id
  WHERE e.event_date >= CURDATE()
  GROUP BY e.id
),
CustomerRevenue AS (
  SELECT e.id AS event_id, SUM(p.amount) AS total_paid
  FROM events e JOIN invoices i ON e.id = i.event_id JOIN payments p ON i.id = p.invoice_id
  WHERE p.status = 'completed' GROUP BY e.id
)
SELECT ep.*, cr.total_paid, CONCAT(c.first_name, ' ', c.last_name) AS customer
FROM EventProgress ep
JOIN events e ON ep.id = e.id
JOIN customers c ON e.customer_id = c.id
LEFT JOIN CustomerRevenue cr ON ep.id = cr.event_id
ORDER BY e.event_date;

-- Window Function: Running revenue total by month
SELECT
  month, total_revenue,
  SUM(total_revenue) OVER (ORDER BY month ROWS UNBOUNDED PRECEDING) AS running_total,
  LAG(total_revenue) OVER (ORDER BY month) AS prev_month,
  ROUND((total_revenue - LAG(total_revenue) OVER (ORDER BY month)) / LAG(total_revenue) OVER (ORDER BY month) * 100, 2) AS growth_pct
FROM vw_revenue_dashboard;

-- Correlated Subquery: Customers with above-average event count
SELECT c.id, CONCAT(c.first_name, ' ', c.last_name) AS name, c.total_events
FROM customers c
WHERE c.total_events > (SELECT AVG(total_events) FROM customers WHERE company_id = c.company_id)
ORDER BY c.total_events DESC;

-- FULL JOIN simulation: All vendors and their booking status
SELECT v.business_name, b.booking_code, b.status, b.agreed_price
FROM vendors v LEFT JOIN bookings b ON v.id = b.vendor_id
UNION
SELECT v.business_name, b.booking_code, b.status, b.agreed_price
FROM vendors v RIGHT JOIN bookings b ON v.id = b.vendor_id
WHERE v.id IS NULL;
*/
